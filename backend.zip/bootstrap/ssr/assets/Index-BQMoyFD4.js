import { ref, reactive, onMounted, createApp, h, resolveComponent, withCtx, unref, createVNode, openBlock, createBlock, createTextVNode, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { router, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1, i as i18n, a as _sfc_main$2, u as useHelper } from "./useHelper--dYazn8l.js";
import _sfc_main$4 from "./AddOrEdit-DiMi8g4W.js";
import { _ as _sfc_main$3 } from "./DefaultLayout-ClKnt0rX.js";
import { useEventBus } from "@vueuse/core";
import { useI18n } from "vue-i18n";
import "./InputError-fLcttu_2.js";
import "pinia";
import "./main-Cd76l1X8.js";
import "particlesjs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
function useCarBrands() {
  ref([]);
  ref(false);
  const message = ref("");
  const deleteBrand = async (item, action = "delete") => {
    if (action === "delete-selected") {
      var routeName = route("cars.brands.destroy.selected", { ids: item });
      router.post(routeName, {
        preserveScroll: true,
        onSuccess: () => {
          message.value = "car.brand.deleted";
        },
        onFinish: () => {
          console.log("Deleted");
        }
      });
    } else {
      router.delete(route("cars.brands.destroy", item.id), {
        preserveScroll: true,
        onSuccess: () => {
          message.value = "car.brand.deleted";
        },
        onFinish: () => {
          console.log("Deleted");
        }
      });
    }
  };
  return {
    deleteBrand,
    message
  };
}
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    const { statusFormat } = useHelper();
    const { t } = useI18n();
    const tableData = ref(false);
    const selectedRows = ref([]);
    const checkAll = ref(false);
    const { on: actionConfirmed } = useEventBus("action:confirmed");
    const { emit: openConfirmPopUp } = useEventBus("confirm:open");
    const { emit: closePopup } = useEventBus("popup:close");
    const { emit: emitOpenModal } = useEventBus("open:car:brand:modal");
    const { on: onCloseModal } = useEventBus("close:car:brand:modal");
    const breadcrumbs = reactive([
      { label: "Home", url: route("dashboard") },
      { label: t("cars"), url: "/cars" },
      { label: t("brands"), url: null }
    ]);
    const openModalFormAdd = (action = "add", item = false) => {
      emitOpenModal(action, item);
    };
    const btnEdit = (item) => {
      emitOpenModal("edit", item);
    };
    const onModalSuccess = (arg) => {
      tableData.value.ajax.reload();
    };
    const closeModal = (arg) => {
      console.log({ arg });
    };
    onCloseModal(() => {
      console.log("Closing Modal");
    });
    onMounted(() => {
      tableData.value = $("#car-brand").DataTable({
        processing: true,
        serverSide: true,
        pageLength: 10,
        order: [[1, "desc"]],
        aLengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 100, "All"]],
        ajax: {
          url: route("cars.brands.list"),
          type: "GET"
        },
        columns: [
          {
            data: "id",
            orderable: false,
            searchable: false,
            className: "checkbox-col",
            render: function(data, type, row, meta) {
              const checkBoxHtml = `<div id="checkbox-${row.id}"></div>`;
              setTimeout(() => {
                const container = document.getElementById(`checkbox-${row.id}`);
                if (container.__vueApp__) {
                  container.__vueApp__.unmount();
                }
                const checkBoxApp = createApp({
                  render() {
                    return h(_sfc_main$1, {
                      modelValue: false,
                      class: "check-row",
                      value: parseInt(row.id),
                      "onUpdate:modelValue": (checked) => onCheckboxChange(checked, parseInt(row.id))
                    });
                  }
                });
                container.__vueApp__ = checkBoxApp;
                checkBoxApp.use(i18n).mount(container);
              }, 0);
              return checkBoxHtml;
            }
          },
          { data: "name", name: "name" },
          {
            data: "status",
            className: "action-col",
            sorderable: false,
            searchable: false,
            render: function(data, type, row, meta) {
              return statusFormat(data);
            }
          },
          {
            data: "action",
            orderable: false,
            searchable: false,
            className: "action-col",
            render: function(data, type, row, meta) {
              const actionsHtml = `<div id="actions-${row.id}"></div>`;
              setTimeout(() => {
                const container = document.getElementById(`actions-${row.id}`);
                if (container.__vueApp__) {
                  container.__vueApp__.unmount();
                }
                const actionsApp = createApp({
                  render() {
                    return h(_sfc_main$2, { item: row }, {
                      "action-buttons": () => [
                        h("div", {
                          class: "cursor-pointer border-t border-stroke dark:border-gray-200 inline-flex justify-start items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-100 w-full text-left --hover:bg-gray-200",
                          onClick: () => btnEdit(row)
                        }, [
                          h("i", { class: "fa fa-pencil mr-2" }),
                          t("edit")
                        ]),
                        h("div", {
                          class: "cursor-pointer border-t border-stroke dark:border-gray-200 inline-flex justify-start items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-100 w-full text-left --hover:bg-gray-200",
                          onClick: () => btnDelete(row)
                        }, [
                          h("i", { class: "fa fa-trash mr-2" }),
                          t("delete")
                        ])
                      ]
                    });
                  }
                });
                container.__vueApp__ = actionsApp;
                actionsApp.use(i18n).mount(container);
              }, 0);
              return actionsHtml;
            }
          }
        ]
      });
      actionConfirmed((item, action) => {
        deleteBrand(item, action);
        closePopup();
        tableData.value.ajax.reload();
        selectedRows.value = [];
        checkAll.value = false;
      });
    });
    const {
      deleteBrand
    } = useCarBrands();
    const onHandleCheckAll = () => {
      checkAll.value = !checkAll.value;
      const checkboxes = document.querySelectorAll(".check-row");
      checkboxes.forEach(function(checkbox) {
        checkbox.checked = checkAll.value;
        const id = checkbox.value;
        if (checkAll.value) {
          if (!selectedRows.value.includes(id)) {
            selectedRows.value.push(id);
          }
        } else {
          selectedRows.value = [];
        }
      });
    };
    const onCheckboxChange = (checked, id) => {
      if (checked) {
        if (!selectedRows.value.includes(id)) {
          selectedRows.value.push(id);
        }
      } else {
        selectedRows.value = selectedRows.value.filter((val) => parseInt(val) !== parseInt(id));
      }
      const totalCheckboxes = document.querySelectorAll(".check-row").length;
      const checkedCheckboxes = document.querySelectorAll(".check-row:checked").length;
      checkAll.value = checkedCheckboxes === totalCheckboxes && totalCheckboxes > 0;
      console.log("checked row", selectedRows.value);
    };
    function btnDelete(item) {
      openConfirmPopUp({
        data: item,
        action: "delete"
      });
    }
    const btnDeleteSelected = () => {
      openConfirmPopUp({
        data: selectedRows.value.length > 0 ? selectedRows : false,
        action: t("delete-selected")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Bc = resolveComponent("Bc");
      _push(ssrRenderComponent(_sfc_main$3, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: _ctx.$t("brands")
            }, null, _parent2, _scopeId));
            _push2(`<div class="container"${_scopeId}><div class="content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Bc, { crumbs: breadcrumbs }, null, _parent2, _scopeId));
            _push2(`<div class="flex items-center gap-2 justify-center"${_scopeId}>`);
            if (selectedRows.value.length) {
              _push2(`<button class="text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"${_scopeId}><i class="fi fi-rr-trash w-4 h-4 me-2"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("delete"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<button class="text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"${_scopeId}><i class="fi fi-rr-plus w-4 h-4 me-2"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("add"))}</button></div></div><div class="content-body p-5"${_scopeId}><div class="relative"${_scopeId}><table id="car-brand" class="table w-full text-sm text-left rtl:text-right"${_scopeId}><thead class="text-center bg-white dark:bg-boxdark"${_scopeId}><tr${_scopeId}><th class="w-[5%]"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(checkAll.value) ? " checked" : ""} class="check-all-row w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"${_scopeId}></th><th class="w-[70%]"${_scopeId}>${ssrInterpolate(_ctx.$t("name"))}</th><th class="w-[10%]"${_scopeId}>${ssrInterpolate(_ctx.$t("status"))}</th><th class="w-[10%] action-col"${_scopeId}>${ssrInterpolate(_ctx.$t("actions"))}</th></tr></thead><tbody class="text-gray-700 dark:text-gray-100 bg-white dark:bg-boxdark"${_scopeId}></tbody></table></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              onClose: closeModal,
              onSuccess: onModalSuccess
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: _ctx.$t("brands")
              }, null, 8, ["title"]),
              createVNode("div", { class: "container" }, [
                createVNode("div", { class: "content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between" }, [
                  createVNode(_component_Bc, { crumbs: breadcrumbs }, null, 8, ["crumbs"]),
                  createVNode("div", { class: "flex items-center gap-2 justify-center" }, [
                    selectedRows.value.length ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: btnDeleteSelected,
                      class: "text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"
                    }, [
                      createVNode("i", { class: "fi fi-rr-trash w-4 h-4 me-2" }),
                      createTextVNode(" " + toDisplayString(_ctx.$t("delete")), 1)
                    ])) : createCommentVNode("", true),
                    createVNode("button", {
                      onClick: ($event) => openModalFormAdd("add", false),
                      class: "text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"
                    }, [
                      createVNode("i", { class: "fi fi-rr-plus w-4 h-4 me-2" }),
                      createTextVNode(" " + toDisplayString(_ctx.$t("add")), 1)
                    ], 8, ["onClick"])
                  ])
                ]),
                createVNode("div", { class: "content-body p-5" }, [
                  createVNode("div", { class: "relative" }, [
                    createVNode("table", {
                      id: "car-brand",
                      class: "table w-full text-sm text-left rtl:text-right"
                    }, [
                      createVNode("thead", { class: "text-center bg-white dark:bg-boxdark" }, [
                        createVNode("tr", null, [
                          createVNode("th", { class: "w-[5%]" }, [
                            createVNode("input", {
                              type: "checkbox",
                              checked: checkAll.value,
                              onChange: onHandleCheckAll,
                              class: "check-all-row w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                            }, null, 40, ["checked"])
                          ]),
                          createVNode("th", { class: "w-[70%]" }, toDisplayString(_ctx.$t("name")), 1),
                          createVNode("th", { class: "w-[10%]" }, toDisplayString(_ctx.$t("status")), 1),
                          createVNode("th", { class: "w-[10%] action-col" }, toDisplayString(_ctx.$t("actions")), 1)
                        ])
                      ]),
                      createVNode("tbody", { class: "text-gray-700 dark:text-gray-100 bg-white dark:bg-boxdark" })
                    ])
                  ])
                ])
              ]),
              createVNode(_sfc_main$4, {
                onClose: closeModal,
                onSuccess: onModalSuccess
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Cars/Brands/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
