import { mergeProps, useSSRContext, ref } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderClass, ssrRenderSlot } from "vue/server-renderer";
import { onClickOutside } from "@vueuse/core";
import { createI18n } from "vue-i18n";
const _sfc_main$1 = {
  __name: "CheckBox",
  __ssrInlineRender: true,
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    modelValue: {
      type: Boolean,
      required: true
    }
  },
  emits: ["update:modelValue", "change"],
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<input${ssrRenderAttrs(mergeProps({
        type: "checkbox",
        checked: __props.modelValue,
        class: "w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
      }, _attrs))}>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/CheckBox.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "ActionButtons",
  __ssrInlineRender: true,
  props: {
    item: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const dropdownOpen = ref(false);
    const target = ref(null);
    onClickOutside(target, () => {
      dropdownOpen.value = false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "relative inline-block text-left text-black dark:text-white",
        ref_key: "target",
        ref: target
      }, _attrs))}><div><button type="button" class="inline-flex justify-center items-center w-full rounded-md bg-purple-700 hover:bg-purple-800 shadow-sm px-4 py-2 text-sm font-medium text-white focus:outline-none">${ssrInterpolate(_ctx.$t("actions"))} <svg class="${ssrRenderClass([{ "transform rotate-180": dropdownOpen.value }, "transition ease-in-out duration-300 -mr-1 ml-2 h-5 w-5"])}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 011.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg></button></div>`);
      if (dropdownOpen.value) {
        _push(`<div class="absolute z-10 -right-0 mt-2 flex w-full flex-col rounded-sm border border-gray-200 bg-white shadow-default dark:border-gray-300 sm:right-0 sm:w-40"><div>`);
        ssrRenderSlot(_ctx.$slots, "action-buttons", {}, null, _push, _parent);
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/ActionButtons.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const welcome$1 = "Welcome";
const yes_iam_sure$1 = "Yes, I'm sure";
const cancel$1 = "Cancel";
const close = "Close";
const a_u_sure$1 = "Are you sure?";
const lang$1 = {
  en: "English",
  kh: "Khmer"
};
const item_not_found$1 = "Item not found!";
const please_try_again$1 = "Please try again!";
const actions$1 = "Actions";
const view$1 = "View";
const add = "Add";
const edit$1 = "Edit";
const save$1 = "Save";
const car = "Car";
const cars = "Cars";
const categories = "Categories";
const category = {
  text: "Category",
  name: "Category Name",
  add: "Add Category",
  edit: "Edit Category",
  update: "Update Category",
  "delete": "Delete Category",
  deleted: "Category successfully deleted.",
  updated: "Category successfully updated.",
  select: "Select Categories",
  cannotdelete: "Category cannot be deleted."
};
const conditions = "Conditions";
const condition = {
  text: "Condition",
  name: "Condition Name",
  add: "Add Condition",
  edit: "Edit Condition",
  update: "Update Condition",
  "delete": "Delete Condition",
  deleted: "Condition successfully deleted.",
  updated: "Condition successfully updated.",
  select: "Select Categories",
  cannotdelete: "Condition cannot be deleted."
};
const image = "Image";
const title = "Title";
const description = "Description";
const price = "Price";
const stock = "Stock";
const add_new = "Add New";
const name = "Name";
const inactive = "Inactive";
const active = "Active";
const status = "Status";
const en = {
  welcome: welcome$1,
  yes_iam_sure: yes_iam_sure$1,
  cancel: cancel$1,
  close,
  a_u_sure: a_u_sure$1,
  "delete": "Delete",
  lang: lang$1,
  item_not_found: item_not_found$1,
  please_try_again: please_try_again$1,
  actions: actions$1,
  view: view$1,
  add,
  edit: edit$1,
  save: save$1,
  car,
  cars,
  categories,
  category,
  conditions,
  condition,
  image,
  title,
  description,
  price,
  stock,
  add_new,
  name,
  inactive,
  active,
  status
};
const welcome = "ស្វាគមន៍";
const yes_iam_sure = "បាទ ខ្ញុំ​ប្រាកដ";
const cancel = "បោះបង់";
const a_u_sure = "តើអ្នកប្រាកដទេ?";
const lang = {
  en: "ភាសាអង់គ្លេស",
  kh: "ភាសារខ្មែរ"
};
const item_not_found = "រកមិនឃើញធាតុទេ!";
const please_try_again = "សូមព្យាយាមម្តងទៀត";
const actions = "សកម្មភាព";
const view = "មើល";
const edit = "កែប្រែ";
const save = "រក្សាទុក";
const kh = {
  welcome,
  yes_iam_sure,
  cancel,
  a_u_sure,
  "delete": "លុប",
  lang,
  item_not_found,
  please_try_again,
  actions,
  view,
  edit,
  save
};
const i18n = createI18n({
  locale: "en",
  fallbackLocale: "en",
  messages: { en, kh }
});
function useHelper() {
  const statusFormat = (status2) => {
    if (status2 === "active") {
      return `<div class="capitalize text-xs text-center row-status font-semibold inline-block py-1 px-2 rounded bg-success text-white">
                ${status2}
            </div>`;
    } else if (status2 === "inactive") {
      return `<div class="capitalize text-xs text-center row-status font-semibold inline-block py-1 px-2 rounded bg-red-600 text-white">
                ${status2}
            </div>`;
    } else {
      return `<div class="capitalize text-xs text-center row-status font-semibold inline-block py-1 px-2 rounded-full bg-gray-600 text-white">
                ${status2}
            </div>`;
    }
  };
  const imageFormat = (src) => {
    return `
            <div class="image flex items-center justify-center">
                <img src="/storage/${src}" alt="Slider Image" class="w-10 h-10 object-cover rounded-lg" />
            </div>
        `;
  };
  return {
    statusFormat,
    imageFormat
  };
}
export {
  _sfc_main$1 as _,
  _sfc_main as a,
  i18n as i,
  useHelper as u
};
