import { ref, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderStyle, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./InputError-fLcttu_2.js";
import { useForm } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { useEventBus } from "@vueuse/core";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {
  __name: "AddOrEdit",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  emits: ["open", "close", "success"],
  setup(__props, { emit: __emit }) {
    const { t } = useI18n();
    const { on: onOpenModal } = useEventBus("open:slider:modal");
    const { emit: emitCloseModal } = useEventBus("close:slider:modal");
    const emit = __emit;
    const isVisible = ref(false);
    const action_label = ref("add");
    const selectedImage = ref(null);
    const title = ref(null);
    const form = useForm({
      id: null,
      title: "",
      description: "",
      is_active: 1,
      image_path: ""
    });
    const handleFileChange = (event) => {
      const file = event.target.files[0];
      if (file) {
        selectedImage.value = URL.createObjectURL(file);
      }
      console.log({ form });
    };
    const removeImage = () => {
      selectedImage.value = null;
      const input = document.getElementById("upload_file");
      if (input) {
        input.value = "";
      }
    };
    const closeModal = () => {
      emitCloseModal();
      isVisible.value = false;
      form.title = "";
      form.description = "";
      form.is_active = "1";
      form.image_path = "";
      selectedImage.value = null;
    };
    onOpenModal((action, item) => {
      isVisible.value = true;
      action_label.value = action;
      nextTick(() => {
        title.value.focus();
      });
      form.errors = {};
      if (item) {
        nextTick(() => {
          form.id = item.id;
          form.title = item.title;
          form.description = item.description;
          form.is_active = item.is_active;
          selectedImage.value = `/storage/${item.image_path}`;
        });
      } else {
        form.title = "";
        form.description = "";
        form.is_active = "1";
        form.image_path = "";
        selectedImage.value = null;
      }
      console.log({ item });
    });
    const sliderFormSubmit = () => {
      if (action_label.value === "edit") {
        form.post(route("frontend.homepage.sliders.update", form), {
          onSuccess: () => {
            nextTick(() => {
              form.reset();
              isVisible.value = false;
              emit("close", "emit close modal");
              emit("success", "emit success modal");
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      } else {
        form.post(route("frontend.homepage.sliders.store"), {
          onSuccess: () => {
            nextTick(() => {
              form.title = "";
              form.description = "";
              form.is_active = "1";
              form.image_path = "";
              selectedImage.value = null;
              isVisible.value = false;
              emit("close", "emit close modal");
              emit("success", "emit success modal");
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(action_label.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(action_label.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form enctype="multipart/form-data" data-v-64788875${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-2" data-v-64788875${_scopeId}><div data-v-64788875${_scopeId}><label for="title" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white" data-v-64788875${_scopeId}>${ssrInterpolate(_ctx.$t("title"))}</label><input type="text"${ssrRenderAttr("value", unref(form).title)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("slider.title"))} data-v-64788875${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.title,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-64788875${_scopeId}><label for="description" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white" data-v-64788875${_scopeId}>${ssrInterpolate(_ctx.$t("description"))}</label><input type="text"${ssrRenderAttr("value", unref(form).description)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("slider.description"))} data-v-64788875${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.description,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="grid gap-6 mb-6 md:grid-cols-1" data-v-64788875${_scopeId}><div data-v-64788875${_scopeId}><label for="countries" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white" data-v-64788875${_scopeId}>Select status</label><select class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500" data-v-64788875${_scopeId}><option selected data-v-64788875${_scopeId}>Choose a status</option><option value="1" data-v-64788875${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, "1") : ssrLooseEqual(unref(form).is_active, "1")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("active"))}</option><option value="0" data-v-64788875${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, "0") : ssrLooseEqual(unref(form).is_active, "0")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("inactive"))}</option></select>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.is_active,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="gap-6 mb-6 relative" data-v-64788875${_scopeId}><label for="upload_file" style="${ssrRenderStyle({ "background-image": selectedImage.value ? "url(" + selectedImage.value + ")" : "", "background-size": "contain", "background-position": "center", "background-repeat": "no-repeat" })}" class="${ssrRenderClass([{ "h-[200px] selected-image": selectedImage.value, "h-52": !selectedImage.value }, "bg-white dark:bg-meta-2 dark:text-white text-gray-500 font-semibold text-base rounded flex flex-col items-center justify-center cursor-pointer border-2 border-dashed border-gray-400 mx-auto font-[sans-serif]"])}" data-v-64788875${_scopeId}>`);
              if (!selectedImage.value) {
                _push3(`<svg xmlns="http://www.w3.org/2000/svg" class="w-[100px] mb-2 fill-gray-500" viewBox="0 0 32 32" data-v-64788875${_scopeId}><path d="M23.75 11.044a7.99 7.99 0 0 0-15.5-.009A8 8 0 0 0 9 27h3a1 1 0 0 0 0-2H9a6 6 0 0 1-.035-12 1.038 1.038 0 0 0 1.1-.854 5.991 5.991 0 0 1 11.862 0A1.08 1.08 0 0 0 23 13a6 6 0 0 1 0 12h-3a1 1 0 0 0 0 2h3a8 8 0 0 0 .75-15.956z" data-original="#000000" data-v-64788875${_scopeId}></path><path d="M20.293 19.707a1 1 0 0 0 1.414-1.414l-5-5a1 1 0 0 0-1.414 0l-5 5a1 1 0 0 0 1.414 1.414L15 16.414V29a1 1 0 0 0 2 0V16.414z" data-original="#000000" data-v-64788875${_scopeId}></path></svg>`);
              } else {
                _push3(`<!---->`);
              }
              if (!selectedImage.value) {
                _push3(`<span data-v-64788875${_scopeId}>Upload file</span>`);
              } else {
                _push3(`<!---->`);
              }
              _push3(`<input type="file" id="upload_file" class="hidden" data-v-64788875${_scopeId}><p class="text-xs font-medium text-gray-400 mt-2" data-v-64788875${_scopeId}>PNG, JPG SVG, WEBP, and GIF are Allowed.</p></label>`);
              if (selectedImage.value) {
                _push3(`<button type="button" class="absolute right-0 top-0 z-2 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="static-modal" data-v-64788875${_scopeId}><svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14" data-v-64788875${_scopeId}><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" data-v-64788875${_scopeId}></path></svg><span class="sr-only" data-v-64788875${_scopeId}>Close modal</span></button>`);
              } else {
                _push3(`<!---->`);
              }
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.image_path,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div class="modal-footer" data-v-64788875${_scopeId}><div class="flex justify-center gap-5 items-center" data-v-64788875${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900" data-v-64788875${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" data-v-64788875${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(sliderFormSubmit, ["prevent"]),
                  enctype: "multipart/form-data"
                }, [
                  createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "title",
                        class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                      }, toDisplayString(_ctx.$t("title")), 1),
                      withDirectives(createVNode("input", {
                        type: "text",
                        ref_key: "title",
                        ref: title,
                        "onUpdate:modelValue": ($event) => unref(form).title = $event,
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                        placeholder: _ctx.$t("slider.title")
                      }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                        [vModelText, unref(form).title]
                      ]),
                      createVNode(_sfc_main$1, {
                        message: unref(form).errors.title,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "description",
                        class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                      }, toDisplayString(_ctx.$t("description")), 1),
                      withDirectives(createVNode("input", {
                        type: "text",
                        ref: "description",
                        "onUpdate:modelValue": ($event) => unref(form).description = $event,
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                        placeholder: _ctx.$t("slider.description")
                      }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                        [vModelText, unref(form).description]
                      ]),
                      createVNode(_sfc_main$1, {
                        message: unref(form).errors.description,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-1" }, [
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "countries",
                        class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      }, "Select status"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                      }, [
                        createVNode("option", { selected: "" }, "Choose a status"),
                        createVNode("option", { value: "1" }, toDisplayString(_ctx.$t("active")), 1),
                        createVNode("option", { value: "0" }, toDisplayString(_ctx.$t("inactive")), 1)
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, unref(form).is_active]
                      ]),
                      createVNode(_sfc_main$1, {
                        message: unref(form).errors.is_active,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "gap-6 mb-6 relative" }, [
                    createVNode("label", {
                      for: "upload_file",
                      style: { "background-image": selectedImage.value ? "url(" + selectedImage.value + ")" : "", "background-size": "contain", "background-position": "center", "background-repeat": "no-repeat" },
                      class: [{ "h-[200px] selected-image": selectedImage.value, "h-52": !selectedImage.value }, "bg-white dark:bg-meta-2 dark:text-white text-gray-500 font-semibold text-base rounded flex flex-col items-center justify-center cursor-pointer border-2 border-dashed border-gray-400 mx-auto font-[sans-serif]"]
                    }, [
                      !selectedImage.value ? (openBlock(), createBlock("svg", {
                        key: 0,
                        xmlns: "http://www.w3.org/2000/svg",
                        class: "w-[100px] mb-2 fill-gray-500",
                        viewBox: "0 0 32 32"
                      }, [
                        createVNode("path", {
                          d: "M23.75 11.044a7.99 7.99 0 0 0-15.5-.009A8 8 0 0 0 9 27h3a1 1 0 0 0 0-2H9a6 6 0 0 1-.035-12 1.038 1.038 0 0 0 1.1-.854 5.991 5.991 0 0 1 11.862 0A1.08 1.08 0 0 0 23 13a6 6 0 0 1 0 12h-3a1 1 0 0 0 0 2h3a8 8 0 0 0 .75-15.956z",
                          "data-original": "#000000"
                        }),
                        createVNode("path", {
                          d: "M20.293 19.707a1 1 0 0 0 1.414-1.414l-5-5a1 1 0 0 0-1.414 0l-5 5a1 1 0 0 0 1.414 1.414L15 16.414V29a1 1 0 0 0 2 0V16.414z",
                          "data-original": "#000000"
                        })
                      ])) : createCommentVNode("", true),
                      !selectedImage.value ? (openBlock(), createBlock("span", { key: 1 }, "Upload file")) : createCommentVNode("", true),
                      createVNode("input", {
                        type: "file",
                        id: "upload_file",
                        onInput: ($event) => unref(form).image_path = $event.target.files[0],
                        class: "hidden",
                        onChange: handleFileChange
                      }, null, 40, ["onInput"]),
                      createVNode("p", { class: "text-xs font-medium text-gray-400 mt-2" }, "PNG, JPG SVG, WEBP, and GIF are Allowed.")
                    ], 6),
                    selectedImage.value ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: removeImage,
                      type: "button",
                      class: "absolute right-0 top-0 z-2 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white",
                      "data-modal-hide": "static-modal"
                    }, [
                      (openBlock(), createBlock("svg", {
                        class: "w-3 h-3",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 14 14"
                      }, [
                        createVNode("path", {
                          stroke: "currentColor",
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          "stroke-width": "2",
                          d: "m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                        })
                      ])),
                      createVNode("span", { class: "sr-only" }, "Close modal")
                    ])) : createCommentVNode("", true),
                    createVNode(_sfc_main$1, {
                      message: unref(form).errors.image_path,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "modal-footer" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 9, ["onClick"]),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 40, ["onSubmit"])
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Frontend/HomePage/Sliders/AddOrEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AddOrEditForm = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-64788875"]]);
export {
  AddOrEditForm as default
};
