import { ref, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./InputError-fLcttu_2.js";
import { useForm } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { useEventBus } from "@vueuse/core";
const _sfc_main = {
  __name: "AddOrEdit",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  emits: ["open", "close", "success"],
  setup(__props, { emit: __emit }) {
    const { t } = useI18n();
    const { on: onOpenModal } = useEventBus("open:car:brand:modal");
    const { emit: emitCloseModal } = useEventBus("close:car:brand:modal");
    const emit = __emit;
    const isVisible = ref(false);
    const name = ref(null);
    const action_label = ref("add");
    const form = useForm({
      id: null,
      name: "",
      status: "active"
    });
    const closeModal = () => {
      emitCloseModal();
      isVisible.value = false;
      form.reset();
    };
    onOpenModal((action, item) => {
      isVisible.value = true;
      action_label.value = action;
      nextTick(() => {
        form.name = "";
        name.value.focus();
      });
      if (item) {
        nextTick(() => {
          form.id = item.id;
          form.name = item.name;
          form.status = item.status;
        });
        if (name.value) {
          name.value.focus();
        }
      }
      console.log({ item });
    });
    const brandFormSubmit = () => {
      if (action_label.value === "edit") {
        form.put(route("cars.brands.update", form.id), {
          onSuccess: () => {
            nextTick(() => {
              form.reset();
              isVisible.value = false;
              emit("close", "emit close modal");
              emit("success", "emit success modal");
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      } else {
        form.post(route("cars.brands.store"), {
          onSuccess: () => {
            nextTick(() => {
              form.reset("name");
              isVisible.value = false;
              emit("close", "emit close modal");
              emit("success", "emit success modal");
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(action_label.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(action_label.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-2"${_scopeId}><div${_scopeId}><label for="first_name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("name"))}</label><input type="text"${ssrRenderAttr("value", unref(form).name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("brand.name"))}${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.name,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div${_scopeId}><label for="countries" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>Select an option</label><select class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option selected${_scopeId}>Choose a status</option><option value="active"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "active") : ssrLooseEqual(unref(form).status, "active")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("active"))}</option><option value="inactive"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "inactive") : ssrLooseEqual(unref(form).status, "inactive")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("inactive"))}</option></select></div></div><div class="modal-footer"${_scopeId}><div class="flex justify-center gap-5 items-center"${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(brandFormSubmit, ["prevent"])
                }, [
                  createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "first_name",
                        class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                      }, toDisplayString(_ctx.$t("name")), 1),
                      withDirectives(createVNode("input", {
                        type: "text",
                        ref_key: "name",
                        ref: name,
                        "onUpdate:modelValue": ($event) => unref(form).name = $event,
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                        placeholder: _ctx.$t("brand.name")
                      }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                        [vModelText, unref(form).name]
                      ]),
                      createVNode(_sfc_main$1, {
                        message: unref(form).errors.name,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "countries",
                        class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      }, "Select an option"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => unref(form).status = $event,
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                      }, [
                        createVNode("option", { selected: "" }, "Choose a status"),
                        createVNode("option", { value: "active" }, toDisplayString(_ctx.$t("active")), 1),
                        createVNode("option", { value: "inactive" }, toDisplayString(_ctx.$t("inactive")), 1)
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, unref(form).status]
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 9, ["onClick"]),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 40, ["onSubmit"])
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Cars/Brands/AddOrEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
