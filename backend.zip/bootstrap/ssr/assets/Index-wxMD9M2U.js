import { reactive, resolveComponent, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, withModifiers, unref, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./DefaultLayout-ClKnt0rX.js";
import { useForm } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import "@vueuse/core";
import "pinia";
import "./main-Cd76l1X8.js";
import "particlesjs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    login_logo: {
      type: String,
      required: true,
      default: "/assets/images/login.png"
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const breadcrumbs = reactive([
      { label: "Home", url: route("dashboard") },
      { label: t("admin"), url: null },
      { label: t("Frontend"), url: null },
      { label: t("Home Page"), url: null }
    ]);
    const form = useForm({
      login_logo: null
    });
    const uploadLogo = () => {
      form.post(route("settings.upload"), {
        onFinish: () => {
          console.log("Logo uploaded successfully");
          form.reset("login_logo");
        },
        onError: (errors) => {
          console.log(errors);
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Bc = resolveComponent("Bc");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><div class="content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Bc, { crumbs: breadcrumbs }, null, _parent2, _scopeId));
            _push2(`<div class="flex items-center gap-2 justify-center"${_scopeId}><button class="text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"${_scopeId}><i class="fi fi-rr-plus w-4 h-4 me-2"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("add"))}</button></div></div><div class="content-body p-5"${_scopeId}><div class="relative"${_scopeId}>`);
            if (__props.login_logo) {
              _push2(`<div${_scopeId}><h2${_scopeId}>Current Logo</h2><img${ssrRenderAttr("src", `/storage/${__props.login_logo}`)} alt="Login Logo" width="200"${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<form enctype="multipart/form-data"${_scopeId}><input type="file"${_scopeId}><button type="submit"${_scopeId}>Submit</button></form></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("div", { class: "content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between" }, [
                  createVNode(_component_Bc, { crumbs: breadcrumbs }, null, 8, ["crumbs"]),
                  createVNode("div", { class: "flex items-center gap-2 justify-center" }, [
                    createVNode("button", {
                      onClick: ($event) => _ctx.openModalFormAdd("add", false),
                      class: "text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"
                    }, [
                      createVNode("i", { class: "fi fi-rr-plus w-4 h-4 me-2" }),
                      createTextVNode(" " + toDisplayString(_ctx.$t("add")), 1)
                    ], 8, ["onClick"])
                  ])
                ]),
                createVNode("div", { class: "content-body p-5" }, [
                  createVNode("div", { class: "relative" }, [
                    __props.login_logo ? (openBlock(), createBlock("div", { key: 0 }, [
                      createVNode("h2", null, "Current Logo"),
                      createVNode("img", {
                        src: `/storage/${__props.login_logo}`,
                        alt: "Login Logo",
                        width: "200"
                      }, null, 8, ["src"])
                    ])) : createCommentVNode("", true),
                    createVNode("form", {
                      onSubmit: withModifiers(uploadLogo, ["prevent"]),
                      enctype: "multipart/form-data"
                    }, [
                      createVNode("input", {
                        type: "file",
                        onInput: ($event) => unref(form).login_logo = $event.target.files[0]
                      }, null, 40, ["onInput"]),
                      createVNode("button", { type: "submit" }, "Submit")
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Settings/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
