<template>
    <Teleport to="body">
        <modal size="md" :show=" isVisible " :show-footer=" false " :show-confirm-button=" true " button-confirm-label="save" @close="closeModal">
          <template #title>
            {{ t(action_label) }}
          </template>
          <template #body>
            <form @submit.prevent=" brandFormSubmit ">
              <div class="grid gap-6 mb-6 md:grid-cols-2">
                <div>
                  <label for="first_name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white">{{
                    $t('name') }}</label>
                  <input type="text" ref="name" v-model=" form.name "
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"
                    :placeholder=" $t('brand.name') " />
                  <InputError :message=" form.errors.name " class="mt-2" />
                </div>

                <div>
                  <label for="countries" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Select an
                    option</label>
                  <select v-model=" form.status "
                    class="bg-gray-50 border   border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500">
                    <option selected>Choose a status</option>
                    <option value="active">{{ $t('active') }}</option>
                    <option value="inactive">{{ $t('inactive') }}</option>
                  </select>
                </div>
              </div>
              <div class="modal-footer">
                <div class="flex justify-center gap-5 items-center">
                  <button @click=" closeModal " type="button"
                    class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900">{{
                    $t('close') }}</button>
                  <button
                    class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900">{{
                    $t('save') }}</button>
                  
                </div>
              </div>
            </form>

          </template>
        </modal>
      </Teleport>
</template>

<script setup>
  import InputError from '@/Components/InputError.vue';
  import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue'
  import { useForm } from '@inertiajs/vue3'
  import { useI18n } from 'vue-i18n';
  import { useEventBus } from '@vueuse/core';
  const { t } = useI18n();


  const { on: onOpenModal } = useEventBus('open:car:brand:modal')
  const { emit: emitCloseModal } = useEventBus('close:car:brand:modal');
  const emit = defineEmits(['open', 'close', 'success'])

  const isVisible = ref(false)
  const name = ref(null)
  const action_label = ref('add')
  const form = useForm({
    id: null,
    name: '',
    status: 'active',
  })
  
  const closeModal = () => {
    emitCloseModal()
    isVisible.value = false
    form.reset()
  }
  onOpenModal((action, item) => {
    isVisible.value = true  
    action_label.value = action
    nextTick(() => {
      form.name = ''
      name.value.focus();
    })
    if(item) {
      nextTick(() => {
        form.id = item.id
        form.name = item.name
        form.status = item.status
      })
      if (name.value) {
        name.value.focus();
      }
    }
    console.log({item})
  })

  const props = defineProps({
      showModal: {
        type: Boolean,
        default: false,
      }
  })

  const brandFormSubmit = () => {
    if(action_label.value === "edit") {
      form.put(route('cars.brands.update', form.id), {
        onSuccess: () => {
          nextTick(() => {
            form.reset()
            isVisible.value = false
            emit('close', 'emit close modal')
            emit('success', 'emit success modal')
          })
        },
        onError: () => {
          isVisible.value = true
        }
      })
    } else {
      form.post(route('cars.brands.store'), {
        onSuccess: () => {
          nextTick(() => {
            form.reset('name')
            isVisible.value = false
            emit('close', 'emit close modal')
            emit('success', 'emit success modal')
          })
        },
        onError: () => {
          isVisible.value = true
        }
      })
    }
    
  }

    
</script>
