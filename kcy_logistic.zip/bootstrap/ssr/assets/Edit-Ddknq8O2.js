import { getCurrentInstance, resolveComponent, unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, withModifiers, createCommentVNode, useSSRContext, nextTick } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./DefaultLayout-e-iQ3dSt.js";
import _sfc_main$5 from "./DeleteUserForm-DLhEH3T3.js";
import _sfc_main$4 from "./UpdatePasswordForm-CycY3z9Y.js";
import _sfc_main$2 from "./UpdateProfileInformationForm-BIvkmsUC.js";
import { usePage, useForm, Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$3 } from "./Label-Dtk55Z_1.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { useI18n } from "vue-i18n";
import "./events-Tj9gV-xT.js";
import { u as useHelpers } from "./useHelpers-CWP_u-9_.js";
import "@vueuse/core";
import "pinia";
import "./main-C8iUTWAB.js";
import "particlesjs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
/* empty css                                                                  */
import "./SecondaryButton-C_2e8ovy.js";
import "./InputError-fLcttu_2.js";
import "./InputLabel-DdVWtGcy.js";
import "./TextInput-BvV7qmwO.js";
import "./PrimaryButton-ceuNs1YK.js";
import "mitt";
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: {
      type: Boolean
    },
    status: {
      type: String
    }
  },
  setup(__props) {
    useI18n();
    getCurrentInstance();
    const { isRole, isPermission } = useHelpers();
    const user = usePage().props.auth.user;
    const form = useForm({
      avatar: null
    });
    const handleSubmit = () => {
      form.post(route("users.update-avatar", user.id), {
        preserveScroll: true,
        onSuccess: (res) => {
          nextTick(() => {
            router.get(route("profile.edit"));
          });
        },
        onError: () => {
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_InputError = resolveComponent("InputError");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(unref(Head), { title: "Profile" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>Profile</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, "Profile")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6"${_scopeId}><div class="p-4 sm:p-8 shadow sm:rounded-lg"${_scopeId}><div class="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-4"${_scopeId}><div${_scopeId}>`);
            if (unref(isRole)("owner")) {
              _push2(ssrRenderComponent(_sfc_main$2, {
                "must-verify-email": __props.mustVerifyEmail,
                status: __props.status,
                class: "max-w-xl"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<div${_scopeId}><h3 class="text-lg font-medium text-gray-600 dark:text-gray-200 mb-4"${_scopeId}>${ssrInterpolate(_ctx.$t("profile_information"))}</h3><table class="no-bg-tr table w-full text-sm text-left rtl:text-right"${_scopeId}><tbody class="text-gray-700 dark:text-gray-100 bg-white dark:bg-boxdark"${_scopeId}><tr${_scopeId}><td class="py-2 px-4 font-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("first_name"))}:</td><td class="py-2 px-4"${_scopeId}>${ssrInterpolate(unref(user).first_name)}</td></tr><tr${_scopeId}><td class="py-2 px-4 font-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("last_name"))}:</td><td class="py-2 px-4"${_scopeId}>${ssrInterpolate(unref(user).last_name)}</td></tr><tr${_scopeId}><td class="py-2 px-4 font-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("email"))}:</td><td class="py-2 px-4"${_scopeId}>${ssrInterpolate(unref(user).email)}</td></tr><tr${_scopeId}><td class="py-2 px-4 font-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("phone"))}:</td><td class="py-2 px-4"${_scopeId}>${ssrInterpolate(unref(user).phone)}</td></tr><tr${_scopeId}><td class="py-2 px-4 font-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("facebook_link"))}:</td><td class="py-2 px-4"${_scopeId}><a${ssrRenderAttr("href", unref(user).facebook_link)} class="hover:underline text-blue-700" target="_blank"${_scopeId}><i class="fi fi-rr-link text-[12px]"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("open"))}</a></td></tr><tr${_scopeId}><td class="py-2 px-4 font-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("telegram_link"))}:</td><td class="py-2 px-4"${_scopeId}><a${ssrRenderAttr("href", unref(user).telegram_link)} class="hover:underline text-blue-700" target="_blank"${_scopeId}><i class="fi fi-rr-link text-[12px]"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("open"))}</a></td></tr><tr${_scopeId}><td class="py-2 px-4 font-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("whatapp_link"))}:</td><td class="py-2 px-4"${_scopeId}><a${ssrRenderAttr("href", unref(user).whatapp_link)} class="hover:underline text-blue-700" target="_blank"${_scopeId}><i class="fi fi-rr-link text-[12px]"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("open"))}</a></td></tr></tbody></table></div>`);
            }
            _push2(`</div><div${_scopeId}><form enctype="multipart/form-data"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for_id: "avatar",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("avatar"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("avatar")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(FileUpload, {
              modelValue: unref(form).avatar,
              "onUpdate:modelValue": ($event) => unref(form).avatar = $event,
              target_input: "avatar",
              selectedFile: unref(user).avatar
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.avatar,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="button-group mt-4"${_scopeId}><div class="flex justify-start gap-5 items-center"${_scopeId}><input type="submit"${ssrRenderAttr("value", _ctx.$t("update"))} class="focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId}></div></div></form></div></div></div>`);
            if (unref(isRole)("owner")) {
              _push2(`<div class="p-4 sm:p-8 shadow sm:rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$4, { class: "max-w-xl" }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref(isRole)("owner")) {
              _push2(`<div class="p-4 sm:p-8 shadow sm:rounded-lg"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$5, { class: "max-w-xl" }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6" }, [
                  createVNode("div", { class: "p-4 sm:p-8 shadow sm:rounded-lg" }, [
                    createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-4" }, [
                      createVNode("div", null, [
                        unref(isRole)("owner") ? (openBlock(), createBlock(_sfc_main$2, {
                          key: 0,
                          "must-verify-email": __props.mustVerifyEmail,
                          status: __props.status,
                          class: "max-w-xl"
                        }, null, 8, ["must-verify-email", "status"])) : (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("h3", { class: "text-lg font-medium text-gray-600 dark:text-gray-200 mb-4" }, toDisplayString(_ctx.$t("profile_information")), 1),
                          createVNode("table", { class: "no-bg-tr table w-full text-sm text-left rtl:text-right" }, [
                            createVNode("tbody", { class: "text-gray-700 dark:text-gray-100 bg-white dark:bg-boxdark" }, [
                              createVNode("tr", null, [
                                createVNode("td", { class: "py-2 px-4 font-sm" }, toDisplayString(_ctx.$t("first_name")) + ":", 1),
                                createVNode("td", { class: "py-2 px-4" }, toDisplayString(unref(user).first_name), 1)
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { class: "py-2 px-4 font-sm" }, toDisplayString(_ctx.$t("last_name")) + ":", 1),
                                createVNode("td", { class: "py-2 px-4" }, toDisplayString(unref(user).last_name), 1)
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { class: "py-2 px-4 font-sm" }, toDisplayString(_ctx.$t("email")) + ":", 1),
                                createVNode("td", { class: "py-2 px-4" }, toDisplayString(unref(user).email), 1)
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { class: "py-2 px-4 font-sm" }, toDisplayString(_ctx.$t("phone")) + ":", 1),
                                createVNode("td", { class: "py-2 px-4" }, toDisplayString(unref(user).phone), 1)
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { class: "py-2 px-4 font-sm" }, toDisplayString(_ctx.$t("facebook_link")) + ":", 1),
                                createVNode("td", { class: "py-2 px-4" }, [
                                  createVNode("a", {
                                    href: unref(user).facebook_link,
                                    class: "hover:underline text-blue-700",
                                    target: "_blank"
                                  }, [
                                    createVNode("i", { class: "fi fi-rr-link text-[12px]" }),
                                    createTextVNode(" " + toDisplayString(_ctx.$t("open")), 1)
                                  ], 8, ["href"])
                                ])
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { class: "py-2 px-4 font-sm" }, toDisplayString(_ctx.$t("telegram_link")) + ":", 1),
                                createVNode("td", { class: "py-2 px-4" }, [
                                  createVNode("a", {
                                    href: unref(user).telegram_link,
                                    class: "hover:underline text-blue-700",
                                    target: "_blank"
                                  }, [
                                    createVNode("i", { class: "fi fi-rr-link text-[12px]" }),
                                    createTextVNode(" " + toDisplayString(_ctx.$t("open")), 1)
                                  ], 8, ["href"])
                                ])
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { class: "py-2 px-4 font-sm" }, toDisplayString(_ctx.$t("whatapp_link")) + ":", 1),
                                createVNode("td", { class: "py-2 px-4" }, [
                                  createVNode("a", {
                                    href: unref(user).whatapp_link,
                                    class: "hover:underline text-blue-700",
                                    target: "_blank"
                                  }, [
                                    createVNode("i", { class: "fi fi-rr-link text-[12px]" }),
                                    createTextVNode(" " + toDisplayString(_ctx.$t("open")), 1)
                                  ], 8, ["href"])
                                ])
                              ])
                            ])
                          ])
                        ]))
                      ]),
                      createVNode("div", null, [
                        createVNode("form", {
                          onSubmit: withModifiers(handleSubmit, ["prevent"]),
                          enctype: "multipart/form-data"
                        }, [
                          createVNode("div", null, [
                            createVNode(_sfc_main$3, {
                              for_id: "avatar",
                              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(_ctx.$t("avatar")), 1)
                              ]),
                              _: 1
                            }),
                            createVNode(FileUpload, {
                              modelValue: unref(form).avatar,
                              "onUpdate:modelValue": ($event) => unref(form).avatar = $event,
                              target_input: "avatar",
                              selectedFile: unref(user).avatar
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "selectedFile"]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.avatar,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "button-group mt-4" }, [
                            createVNode("div", { class: "flex justify-start gap-5 items-center" }, [
                              createVNode("input", {
                                type: "submit",
                                value: _ctx.$t("update"),
                                class: "focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"
                              }, null, 8, ["value"])
                            ])
                          ])
                        ], 32)
                      ])
                    ])
                  ]),
                  unref(isRole)("owner") ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "p-4 sm:p-8 shadow sm:rounded-lg"
                  }, [
                    createVNode(_sfc_main$4, { class: "max-w-xl" })
                  ])) : createCommentVNode("", true),
                  unref(isRole)("owner") ? (openBlock(), createBlock("div", {
                    key: 1,
                    class: "p-4 sm:p-8 shadow sm:rounded-lg"
                  }, [
                    createVNode(_sfc_main$5, { class: "max-w-xl" })
                  ])) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Users/Profile/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
