import { ref, reactive, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./Label-Dtk55Z_1.js";
import { _ as _sfc_main$2 } from "./InputError-fLcttu_2.js";
import { useForm } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { e as events } from "./events-Tj9gV-xT.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import "mitt";
const _sfc_main = {
  __name: "AddOrEdit",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const isVisible = ref(false);
    const modal_title = ref("slider.add");
    const event_type = ref("add");
    reactive([{ name: "" }]);
    const name = ref(null);
    const form = useForm({
      id: null,
      name: ""
    });
    const closeModal = () => {
      isVisible.value = false;
      form.name = "";
      events.emit("modal:close");
    };
    events.on("modal:open", (data) => {
      modal_title.value = data.modal_title || "group.add";
      event_type.value = data.event_type;
      isVisible.value = true;
      nextTick(() => {
        name.value.focus();
      });
      form.errors = {};
      if (event_type.value === "edit" && data.item) {
        nextTick(() => {
          form.id = data.item.id;
          form.name = data.item.name;
        });
      } else {
        form.id = null;
        form.name = "";
      }
    });
    const optionTypeFormSubmit = () => {
      if (event_type.value === "edit") {
        form.post(route("optionGroups.update", form), {
          onSuccess: () => {
            nextTick(() => {
              form.reset();
              isVisible.value = false;
              events.emit("modal:success");
              events.emit("toaster", {
                type: "success",
                action: "update",
                message: `${t("option_group")} [${form.name}] ${t("successfully_updated")}`
              });
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      } else {
        form.post(route("optionGroups.store"), {
          onSuccess: () => {
            nextTick(() => {
              events.emit("modal:success");
              events.emit("toaster", {
                type: "success",
                action: "create",
                message: `${t("option_group")} [${form.name}] ${t("successfully_added")}`
              });
              form.id = null;
              form.name = "";
              isVisible.value = true;
              name.value.focus();
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      }
    };
    events.on("delete-items", (ids) => {
      var routeName = route("optionGroups.destroy.selected", {
        ids
      });
      form.post(routeName, {
        preserveScroll: true,
        onSuccess: () => {
          events.emit("confirm:cancel");
          events.emit("confirm:success");
          events.emit("toaster", {
            type: "success",
            action: "delete",
            message: `${t("item.count", ids.length)} ${t("successfully_deleted")}`
          });
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "xs",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form enctype="multipart/form-data" data-v-1ef74b50${_scopeId}><div class="p-4 md:p-5" data-v-1ef74b50${_scopeId}><div data-v-1ef74b50${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                isRequired: true,
                for_id: "name",
                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("name"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("name")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(`<input type="text" id="name"${ssrRenderAttr("value", unref(form).name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("name"))} data-v-1ef74b50${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.name,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" data-v-1ef74b50${_scopeId}><div class="flex justify-center gap-5 items-center" data-v-1ef74b50${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900" data-v-1ef74b50${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" data-v-1ef74b50${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(optionTypeFormSubmit, ["prevent"]),
                  enctype: "multipart/form-data"
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", null, [
                      createVNode(_sfc_main$1, {
                        isRequired: true,
                        for_id: "name",
                        class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("name")), 1)
                        ]),
                        _: 1
                      }),
                      withDirectives(createVNode("input", {
                        type: "text",
                        id: "name",
                        ref_key: "name",
                        ref: name,
                        "onUpdate:modelValue": ($event) => unref(form).name = $event,
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                        placeholder: _ctx.$t("name")
                      }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                        [vModelText, unref(form).name]
                      ]),
                      createVNode(_sfc_main$2, {
                        message: unref(form).errors.name,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 9, ["onClick"]),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 40, ["onSubmit"])
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/OtherOptions/Pages/OptionGroups/AddOrEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AddOrEdit = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-1ef74b50"]]);
export {
  AddOrEdit as default
};
