import { reactive, ref, watch, onMounted, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./Textarea-tXXc-i0G.js";
/* empty css                         */
import "summernote/dist/summernote-lite.js";
import "./SummernoteEditor-B1pJsGJ1.js";
import { _ as _sfc_main$2 } from "./Label-Dtk55Z_1.js";
import { _ as _sfc_main$1 } from "./DefaultLayout-e-iQ3dSt.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import "moment";
import { e as events } from "./events-Tj9gV-xT.js";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import { u as useCar } from "./car-j73Ni-JN.js";
import "jquery";
import "@vueuse/core";
import "pinia";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./useHelpers-CWP_u-9_.js";
/* empty css                                                                  */
import "mitt";
import "particlesjs";
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    car: {
      type: Object,
      required: true
    },
    categories: {
      type: Array,
      required: true
    },
    brands: {
      type: Array,
      required: true
    },
    // models: {
    //   type: Array,
    //   required: true,
    // },
    conditions: {
      type: Array,
      required: true
    },
    fuel_types: {
      type: Array,
      required: true
    },
    transmission_types: {
      type: Array,
      required: true
    },
    colors: {
      type: Array,
      required: true
    },
    drive_types: {
      type: Array,
      required: true
    },
    passengers: {
      type: Array,
      required: true
    },
    steerings: {
      type: Array,
      required: true
    },
    hot_marks: {
      type: Array,
      required: true
    },
    options: {
      type: Array,
      required: true
    },
    group_options: {
      type: Array,
      required: true
    },
    car_model_options: {
      type: Array,
      required: true
    },
    locations: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const mainStore = useMainStore();
    const carStore = useCar();
    const breadcrumbs = reactive([
      { label: "Home", url: route("dashboard") },
      { label: t("cars"), url: "/admin/cars" },
      { label: t("create"), url: null, is_active: true }
    ]);
    const models = ref([]);
    const props = __props;
    const statuses = ["available", "requesting", "booked", "sold"];
    const form = useForm({
      sourced_link: props.car.sourced_link,
      listing_date: props.car.listing_date,
      code: props.car.code,
      name: props.car.name,
      slug: props.car.slug,
      plate_number: props.car.plate_number,
      total_price: props.car.total_price,
      car_price: props.car.car_price,
      year: props.car.year,
      mileage: props.car.mileage,
      description: props.car.description ?? "",
      featured_image: null,
      gallery_images: null,
      is_featured: props.car.is_featured,
      is_active: props.car.is_active,
      engine_volume: props.car.engine_volume,
      door: props.car.door,
      cylinder: props.car.cylinder,
      engine_power: props.car.engine_power,
      odometer_reading: props.car.odometer_reading,
      water_flood_damaged: props.car.water_flood_damaged,
      former_rental_car: props.car.former_rental_car,
      former_taxi: props.car.former_taxi,
      recovered_theft: props.car.recovered_theft,
      police_car: props.car.police_car,
      salvage_record: props.car.salvage_record,
      fuel_conversion: props.car.fuel_conversion,
      modified_seats: props.car.modified_seats,
      first_registered_date: props.car.first_registered_date,
      // Foreign keys
      category: props.car.category,
      condition: props.car.condition,
      brand: props.car.brand,
      model: props.car.model,
      fuel_type: props.car.fuel_type,
      transmission_type: props.car.transmission_type,
      color: props.car.color,
      steering: props.car.steering,
      drive_type: props.car.drive_type,
      passenger: props.car.passenger,
      location: props.car.location,
      hot_marks: props.car.hot_marks,
      options: props.car.options,
      size: props.car.size,
      status: props.car.status,
      youtube_link: props.car.youtube_link,
      towing_export_document: props.car.towing_export_document,
      shipping: props.car.shipping,
      tax_import: props.car.tax_import,
      clearance: props.car.clearance,
      service: props.car.service,
      first_payment: props.car.first_payment,
      second_payment: props.car.second_payment,
      third_payment: props.car.third_payment
    });
    let options_form = ref({});
    const total_price = ref(0);
    const sl_form = useForm({
      sourced_link: ""
    });
    const handleSourcedLinkChange = (e) => {
      sl_form.sourced_link = form.sourced_link;
      sl_form.post(route("cars.handle-source-link-edit", props.car.id), {
        preserveScroll: true,
        onSuccess: (res) => {
          form.clearErrors("sourced_link");
        },
        onError: () => {
          form.setError("sourced_link", sl_form.errors.sourced_link);
        }
      });
    };
    watch(
      [
        () => form.car_price,
        () => form.towing_export_document,
        () => form.shipping,
        () => form.tax_import,
        () => form.clearance,
        () => form.service
      ],
      ([car_price, towing_export_document, shipping, tax_import, clearance, service]) => {
        total_price.value = Number(car_price) + Number(towing_export_document) + Number(shipping) + Number(tax_import) + Number(clearance) + Number(service);
        form.total_price = total_price.value;
        form.first_payment = Number(car_price) + Number(towing_export_document) + Number(shipping);
        form.second_payment = Number(tax_import) + Number(clearance);
        form.third_payment = Number(service);
      }
    );
    const handleBrandChange = (brand) => {
      models.value = [];
      form.model = [];
      if (brand) {
        axios.get(route("models.by.brand", { ids: [brand.id] })).then((res) => {
          models.value = res == null ? void 0 : res.data.models;
          for (const model of models.value) {
            if (model.id === props.car.model.id) {
              form.model = model;
            }
          }
        });
      }
    };
    const handleModelChange = (model) => {
      form.options = [];
      if (model) {
        axios.get(route("models.options", { model_id: model.id })).then((res) => {
          carStore.setGroupOptions(res.data.group_options);
          if (carStore.groupOptions) {
            carStore.groupOptions.forEach((group_option) => {
              options_form.value[`options_group_${group_option.group_id}`] = group_option.items;
            });
          }
        });
      }
    };
    const handleModelRemove = (model) => {
      form.options = [];
      carStore.getGroupOptions();
      if (props.group_options) {
        options_form.value = props.group_options.map(
          (group_option) => options_form.value[`options_group_${group_option.group_id}`] = []
        );
      }
    };
    const handleBrandRemove = (brand) => {
      models.value = [];
      form.model = [];
    };
    onMounted(() => {
      nextTick(() => {
        Array.from(document.querySelectorAll(".multiselect__tags")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
        Array.from(document.querySelectorAll(".multiselect__input")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
        if (props.car.model_id) {
          axios.get(route("models.options", { model_id: props.car.model_id })).then((res) => {
            carStore.setGroupOptions(res.data.group_options);
          });
        }
        form.hot_marks = props.car.hot_marks;
        if (props.group_options) {
          props.car_model_options.forEach((group_option) => {
            options_form.value[`options_group_${group_option.group_id}`] = group_option.items;
          });
        }
        console.log({ options_form }, props.car_model_options);
        if (props.car.brand) {
          handleBrandChange(props.car.brand);
        }
      });
    });
    const handleSubmit = () => {
      var pg = carStore.groupOptions.map(
        (group_option) => options_form.value["options_group_" + group_option.group_id] ? options_form.value["options_group_" + group_option.group_id] : []
      );
      console.log({ pg }, { options_form });
      var op = pg.flat();
      form.options = op;
      form.post(route("cars.update", props.car.id), {
        preserveScroll: true,
        onSuccess: (res) => {
          events.emit("toaster", {
            type: "success",
            action: "create",
            message: `${t("car")} [${form.name}] ${t("successfully_updated")}`
          });
          form.reset("code", "name");
        },
        onError: () => {
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Bc = resolveComponent("Bc");
      const _component_InputError = resolveComponent("InputError");
      const _component_MultiSelect = resolveComponent("MultiSelect");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: _ctx.$t("car.edit")
            }, null, _parent2, _scopeId));
            _push2(`<div class="container"${_scopeId}><div class="content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Bc, { crumbs: breadcrumbs }, null, _parent2, _scopeId));
            _push2(`</div><div class="content-body p-5"${_scopeId}><div class="relative"${_scopeId}><form enctype="multipart/form-data"${_scopeId}><div class="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "sourced_link",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("sourced_link"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("sourced_link")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="sourced_link"${ssrRenderAttr("value", unref(form).sourced_link)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("sourced_link"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.sourced_link,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "listing_date",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("listing_date"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("listing_date")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="date" id="listing_date"${ssrRenderAttr("value", unref(form).listing_date)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("listing_date"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.listing_date,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "code",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("code"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("code")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input autofocus type="text" id="code"${ssrRenderAttr("value", unref(form).code)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("code"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.code,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "name",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("name"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("name")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="name"${ssrRenderAttr("value", unref(form).name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("name"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.name,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mb-6"${_scopeId}><fieldset class="border border-gray-300 dark:border-gray-400 p-4 rounded-lg"${_scopeId}><legend class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("basic_info"))}</legend><div class="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "year",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("year"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("year")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="number" id="year"${ssrRenderAttr("value", unref(form).year)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("year"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.year,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "mileage",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("mileage"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("mileage")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input autofocus type="text" id="mileage"${ssrRenderAttr("value", unref(form).mileage)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("mileage"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.mileage,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "size",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("vehicle_type"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("vehicle_type")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input autofocus type="text" id="size"${ssrRenderAttr("value", unref(form).size)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("vehicle_type"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.size,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class=""${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "engine_volume",
              isRequired: true,
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("engine_volume"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("engine_volume")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input autofocus type="number" id="engine_volume"${ssrRenderAttr("value", unref(form).engine_volume)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("engine_volume"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.engine_volume,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class=""${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "door",
              isRequired: true,
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("door"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("door")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input autofocus type="number" id="door"${ssrRenderAttr("value", unref(form).door)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("door"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.door,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class=""${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "cylinder",
              isRequired: true,
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("cylinder"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("cylinder")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input autofocus type="number" id="cylinder"${ssrRenderAttr("value", unref(form).cylinder)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("cylinder"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.cylinder,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "water_flood_damaged",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("water_flood_damaged"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("water_flood_damaged")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="water_flood_damaged" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).water_flood_damaged) ? ssrLooseContain(unref(form).water_flood_damaged, false) : ssrLooseEqual(unref(form).water_flood_damaged, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).water_flood_damaged) ? ssrLooseContain(unref(form).water_flood_damaged, true) : ssrLooseEqual(unref(form).water_flood_damaged, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.water_flood_damaged,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "former_rental_car",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("former_rental_car"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("former_rental_car")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="former_rental_car" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).former_rental_car) ? ssrLooseContain(unref(form).former_rental_car, false) : ssrLooseEqual(unref(form).former_rental_car, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).former_rental_car) ? ssrLooseContain(unref(form).former_rental_car, true) : ssrLooseEqual(unref(form).former_rental_car, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.former_rental_car,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "former_taxi",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("former_taxi"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("former_taxi")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="former_taxi" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).former_taxi) ? ssrLooseContain(unref(form).former_taxi, false) : ssrLooseEqual(unref(form).former_taxi, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).former_taxi) ? ssrLooseContain(unref(form).former_taxi, true) : ssrLooseEqual(unref(form).former_taxi, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.former_taxi,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "recovered_theft",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("recovered_theft"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("recovered_theft")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="recovered_theft" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).recovered_theft) ? ssrLooseContain(unref(form).recovered_theft, false) : ssrLooseEqual(unref(form).recovered_theft, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).recovered_theft) ? ssrLooseContain(unref(form).recovered_theft, true) : ssrLooseEqual(unref(form).recovered_theft, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.recovered_theft,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "police_car",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("police_car"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("police_car")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="police_car" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).police_car) ? ssrLooseContain(unref(form).police_car, false) : ssrLooseEqual(unref(form).police_car, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).police_car) ? ssrLooseContain(unref(form).police_car, true) : ssrLooseEqual(unref(form).police_car, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.police_car,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "salvage_record",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("salvage_record"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("salvage_record")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="salvage_record" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).salvage_record) ? ssrLooseContain(unref(form).salvage_record, false) : ssrLooseEqual(unref(form).salvage_record, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).salvage_record) ? ssrLooseContain(unref(form).salvage_record, true) : ssrLooseEqual(unref(form).salvage_record, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.salvage_record,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "fuel_conversion",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("fuel_conversion"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("fuel_conversion")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="fuel_conversion" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).fuel_conversion) ? ssrLooseContain(unref(form).fuel_conversion, false) : ssrLooseEqual(unref(form).fuel_conversion, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).fuel_conversion) ? ssrLooseContain(unref(form).fuel_conversion, true) : ssrLooseEqual(unref(form).fuel_conversion, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.fuel_conversion,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "modified_seats",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("modified_seats"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("modified_seats")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="modified_seats" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).modified_seats) ? ssrLooseContain(unref(form).modified_seats, false) : ssrLooseEqual(unref(form).modified_seats, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).modified_seats) ? ssrLooseContain(unref(form).modified_seats, true) : ssrLooseEqual(unref(form).modified_seats, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.modified_seats,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "is_featured",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("is_featured"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("is_featured")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="is_featured" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_featured) ? ssrLooseContain(unref(form).is_featured, false) : ssrLooseEqual(unref(form).is_featured, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("no"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_featured) ? ssrLooseContain(unref(form).is_featured, true) : ssrLooseEqual(unref(form).is_featured, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("yes"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.is_featured,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "is_active",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("is_active"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("is_active")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="is_active" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, true) : ssrLooseEqual(unref(form).is_active, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("active"))}</option><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, false) : ssrLooseEqual(unref(form).is_active, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("inactive"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.is_active,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></fieldset></div><div class="mb-6"${_scopeId}><fieldset class="border border-gray-300 dark:border-gray-400 p-4 rounded-lg"${_scopeId}><legend class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("specifications"))}</legend><div class="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "category",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("category"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("category")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "category",
              modelValue: unref(form).category,
              "onUpdate:modelValue": ($event) => unref(form).category = $event,
              options: __props.categories,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.category,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "brand",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("brand"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("brand")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "brand",
              modelValue: unref(form).brand,
              "onUpdate:modelValue": ($event) => unref(form).brand = $event,
              options: __props.brands,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`,
              onSelect: handleBrandChange,
              onRemove: handleBrandRemove
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.brand,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "model",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("model"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("model")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "model",
              modelValue: unref(form).model,
              "onUpdate:modelValue": ($event) => unref(form).model = $event,
              options: models.value,
              multiple: false,
              "track-by": "id",
              onSelect: handleModelChange,
              onRemove: handleModelRemove,
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.model,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "condition",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("condition"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("condition")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "condition",
              modelValue: unref(form).condition,
              "onUpdate:modelValue": ($event) => unref(form).condition = $event,
              options: __props.conditions,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.condition,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "fuel_type",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("fuel_type"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("fuel_type")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "fuel_type",
              modelValue: unref(form).fuel_type,
              "onUpdate:modelValue": ($event) => unref(form).fuel_type = $event,
              options: __props.fuel_types,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.fuel_type,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "transmission_type",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("transmission_type"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("transmission_type")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "transmission_type",
              modelValue: unref(form).transmission_type,
              "onUpdate:modelValue": ($event) => unref(form).transmission_type = $event,
              options: __props.transmission_types,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.transmission_type,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "steering",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("steering"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("steering")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "steering",
              modelValue: unref(form).steering,
              "onUpdate:modelValue": ($event) => unref(form).steering = $event,
              options: __props.steerings,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.steering,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "color",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("color"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("color")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "color",
              modelValue: unref(form).color,
              "onUpdate:modelValue": ($event) => unref(form).color = $event,
              options: __props.colors,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.color,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "drive_type",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("drive_type"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("drive_type")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "drive_type",
              modelValue: unref(form).drive_type,
              "onUpdate:modelValue": ($event) => unref(form).drive_type = $event,
              options: __props.drive_types,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.drive_type,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "passengers",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("passengers"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("passengers")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "passenger",
              modelValue: unref(form).passenger,
              "onUpdate:modelValue": ($event) => unref(form).passenger = $event,
              options: __props.passengers,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${unref(t)("seat.count", { count: parseInt(option.name) })}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.passenger,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "location",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("location"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("location")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "location",
              modelValue: unref(form).location,
              "onUpdate:modelValue": ($event) => unref(form).location = $event,
              options: __props.locations,
              multiple: false,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.location,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "status",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("status"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("status")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "status",
              modelValue: unref(form).status,
              "onUpdate:modelValue": ($event) => unref(form).status = $event,
              options: statuses,
              multiple: false,
              "custom-label": (option) => `${_ctx.$t(option)}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.status,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></fieldset></div><div class="mb-6"${_scopeId}><fieldset class="border border-gray-300 dark:border-gray-400 p-4 rounded-lg"${_scopeId}><legend class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("other_options"))}</legend><div class="mb-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "hot_marks",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("hot_marks"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("hot_marks")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_MultiSelect, {
              id: "hot_mark",
              modelValue: unref(form).hot_marks,
              "onUpdate:modelValue": ($event) => unref(form).hot_marks = $event,
              options: __props.hot_marks,
              multiple: true,
              "track-by": "id",
              "custom-label": (option) => `${option.name}`
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.hot_marks,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid gap-6 grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3"${_scopeId}><!--[-->`);
            ssrRenderList(unref(carStore).groupOptions, (group_option, index) => {
              _push2(`<div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                for_id: "options",
                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(group_option.group_name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(group_option.group_name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_MultiSelect, {
                id: "options_group_" + group_option.group_id,
                modelValue: unref(options_form)["options_group_" + group_option.group_id],
                "onUpdate:modelValue": ($event) => unref(options_form)["options_group_" + group_option.group_id] = $event,
                options: group_option.items,
                multiple: true,
                "track-by": "id",
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            });
            _push2(`<!--]--></div></fieldset></div><div class="grid gap-6 grid-cols-1 mb-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "total_price",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("total_price"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("total_price")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="total_price" readonly="readonly"${ssrRenderAttr("value", unref(form).total_price)} class="cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("total_price"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.total_price,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mb-6"${_scopeId}><fieldset class="border border-gray-300 dark:border-gray-400 p-4 rounded-lg"${_scopeId}><legend class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("payment_details"))}</legend><div class="grid gap-6 grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "car_price",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("car_price"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("car_price")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="car_price"${ssrRenderAttr("value", unref(form).car_price)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("car_price"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.car_price,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "towing_export_document",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("export_license"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("export_license")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="towing_export_document"${ssrRenderAttr("value", unref(form).towing_export_document)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("export_license"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.towing_export_document,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "shipping",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("shipping"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("shipping")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="shipping"${ssrRenderAttr("value", unref(form).shipping)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("shipping"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.shipping,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "tax_import",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("tax_import"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("tax_import")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="tax_import"${ssrRenderAttr("value", unref(form).tax_import)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("tax_import"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.tax_import,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "clearance",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("clearance"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("clearance")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="clearance"${ssrRenderAttr("value", unref(form).clearance)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("clearance"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.clearance,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "service",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("service"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("service")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="service"${ssrRenderAttr("value", unref(form).service)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("service"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.service,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></fieldset></div><div class="mb-6"${_scopeId}><fieldset class="border border-gray-300 dark:border-gray-400 p-4 rounded-lg"${_scopeId}><legend class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("payment_terms"))}</legend><div class="grid gap-6 grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "first_payment",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("first_payment"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("first_payment")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="first_payment" readonly="readonly"${ssrRenderAttr("value", unref(form).first_payment)} class="cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("first_payment"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.first_payment,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "second_payment",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("second_payment"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("second_payment")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="second_payment" readonly="readonly"${ssrRenderAttr("value", unref(form).second_payment)} class="cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("second_payment"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.second_payment,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "third_payment",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("third_payment"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("third_payment")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="third_payment" readonly="readonly"${ssrRenderAttr("value", unref(form).third_payment)} class="cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("third_payment"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.third_payment,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></fieldset></div><div class="mb-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "youtube_link",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("youtube_link"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("youtube_link")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="youtube_link"${ssrRenderAttr("value", unref(form).youtube_link)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11" placeholder="https://www.youtube.com/watch?v=_FTDev"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.youtube_link,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mb-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "description",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("description"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("description")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              rows: "8",
              id: "description",
              modelValue: unref(form).description,
              "onUpdate:modelValue": ($event) => unref(form).description = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.description,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid gap-6 md:grid-cols-2"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "featured_image",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("featured_image"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("featured_image")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(FileUpload, {
              modelValue: unref(form).featured_image,
              "onUpdate:modelValue": ($event) => unref(form).featured_image = $event,
              target_input: "featured_image"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.featured_image,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "gallery_images",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("gallery_images"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("gallery_images")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(FileUpload, {
              multiple: true,
              target_input: "gallery_images",
              modelValue: unref(form).gallery_images,
              "onUpdate:modelValue": ($event) => unref(form).gallery_images = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.gallery_images,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="button-group"${_scopeId}><div class="flex justify-start gap-5 items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("cars.index"),
              class: "focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("cancel"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="submit"${ssrRenderAttr("value", _ctx.$t("update"))} class="focus:outline-none text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-1 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 dark:focus:ring-emerald-900"${_scopeId}></div></div></form></div></div></div>`);
          } else {
            return [
              createVNode(unref(Head), {
                title: _ctx.$t("car.edit")
              }, null, 8, ["title"]),
              createVNode("div", { class: "container" }, [
                createVNode("div", { class: "content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between" }, [
                  createVNode(_component_Bc, { crumbs: breadcrumbs }, null, 8, ["crumbs"])
                ]),
                createVNode("div", { class: "content-body p-5" }, [
                  createVNode("div", { class: "relative" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(handleSubmit, ["prevent"]),
                      enctype: "multipart/form-data"
                    }, [
                      createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-6" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for_id: "sourced_link",
                            class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("sourced_link")), 1)
                            ]),
                            _: 1
                          }),
                          withDirectives(createVNode("input", {
                            type: "text",
                            ref: "sourced_link",
                            id: "sourced_link",
                            "onUpdate:modelValue": ($event) => unref(form).sourced_link = $event,
                            onChange: handleSourcedLinkChange,
                            class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                            placeholder: _ctx.$t("sourced_link")
                          }, null, 40, ["onUpdate:modelValue", "placeholder"]), [
                            [vModelText, unref(form).sourced_link]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.sourced_link,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for_id: "listing_date",
                            class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("listing_date")), 1)
                            ]),
                            _: 1
                          }),
                          withDirectives(createVNode("input", {
                            type: "date",
                            ref: "listing_date",
                            id: "listing_date",
                            "onUpdate:modelValue": ($event) => unref(form).listing_date = $event,
                            class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                            placeholder: _ctx.$t("listing_date")
                          }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                            [vModelText, unref(form).listing_date]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.listing_date,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            isRequired: true,
                            for_id: "code",
                            class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("code")), 1)
                            ]),
                            _: 1
                          }),
                          withDirectives(createVNode("input", {
                            autofocus: "",
                            type: "text",
                            ref: "code",
                            id: "code",
                            "onUpdate:modelValue": ($event) => unref(form).code = $event,
                            class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                            placeholder: _ctx.$t("code")
                          }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                            [vModelText, unref(form).code]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.code,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            isRequired: true,
                            for_id: "name",
                            class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("name")), 1)
                            ]),
                            _: 1
                          }),
                          withDirectives(createVNode("input", {
                            type: "text",
                            ref: "name",
                            id: "name",
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                            placeholder: _ctx.$t("name")
                          }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                            [vModelText, unref(form).name]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.name,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("fieldset", { class: "border border-gray-300 dark:border-gray-400 p-4 rounded-lg" }, [
                          createVNode("legend", { class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(_ctx.$t("basic_info")), 1),
                          createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4" }, [
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "year",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("year")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "number",
                                ref: "year",
                                id: "year",
                                "onUpdate:modelValue": ($event) => unref(form).year = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("year")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).year]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.year,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "mileage",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("mileage")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                autofocus: "",
                                type: "text",
                                ref: "mileage",
                                id: "mileage",
                                "onUpdate:modelValue": ($event) => unref(form).mileage = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("mileage")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).mileage]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.mileage,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode("div", null, [
                                createVNode(_sfc_main$2, {
                                  for_id: "size",
                                  class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(_ctx.$t("vehicle_type")), 1)
                                  ]),
                                  _: 1
                                }),
                                withDirectives(createVNode("input", {
                                  autofocus: "",
                                  type: "text",
                                  ref: "size",
                                  id: "size",
                                  "onUpdate:modelValue": ($event) => unref(form).size = $event,
                                  class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                  placeholder: _ctx.$t("vehicle_type")
                                }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                  [vModelText, unref(form).size]
                                ]),
                                createVNode(_component_InputError, {
                                  message: unref(form).errors.size,
                                  class: "mt-2"
                                }, null, 8, ["message"])
                              ])
                            ]),
                            createVNode("div", { class: "" }, [
                              createVNode(_sfc_main$2, {
                                for_id: "engine_volume",
                                isRequired: true,
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("engine_volume")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                autofocus: "",
                                type: "number",
                                ref: "engine_volume",
                                id: "engine_volume",
                                "onUpdate:modelValue": ($event) => unref(form).engine_volume = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("engine_volume")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).engine_volume]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.engine_volume,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "" }, [
                              createVNode(_sfc_main$2, {
                                for_id: "door",
                                isRequired: true,
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("door")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                autofocus: "",
                                type: "number",
                                ref: "door",
                                id: "door",
                                "onUpdate:modelValue": ($event) => unref(form).door = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("door")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).door]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.door,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", { class: "" }, [
                              createVNode(_sfc_main$2, {
                                for_id: "cylinder",
                                isRequired: true,
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("cylinder")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                autofocus: "",
                                type: "number",
                                ref: "cylinder",
                                id: "cylinder",
                                "onUpdate:modelValue": ($event) => unref(form).cylinder = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("cylinder")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).cylinder]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.cylinder,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "water_flood_damaged",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("water_flood_damaged")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).water_flood_damaged = $event,
                                id: "water_flood_damaged",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).water_flood_damaged]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.water_flood_damaged,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "former_rental_car",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("former_rental_car")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).former_rental_car = $event,
                                id: "former_rental_car",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).former_rental_car]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.former_rental_car,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "former_taxi",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("former_taxi")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).former_taxi = $event,
                                id: "former_taxi",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).former_taxi]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.former_taxi,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "recovered_theft",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("recovered_theft")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).recovered_theft = $event,
                                id: "recovered_theft",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).recovered_theft]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.recovered_theft,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "police_car",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("police_car")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).police_car = $event,
                                id: "police_car",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).police_car]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.police_car,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "salvage_record",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("salvage_record")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).salvage_record = $event,
                                id: "salvage_record",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).salvage_record]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.salvage_record,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "fuel_conversion",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("fuel_conversion")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).fuel_conversion = $event,
                                id: "fuel_conversion",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).fuel_conversion]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.fuel_conversion,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "modified_seats",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("modified_seats")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).modified_seats = $event,
                                id: "modified_seats",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).modified_seats]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.modified_seats,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "is_featured",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("is_featured")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).is_featured = $event,
                                id: "is_featured",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("no")), 1),
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("yes")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).is_featured]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.is_featured,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "is_active",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("is_active")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("select", {
                                "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                                id: "is_active",
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                              }, [
                                createVNode("option", { value: true }, toDisplayString(_ctx.$t("active")), 1),
                                createVNode("option", { value: false }, toDisplayString(_ctx.$t("inactive")), 1)
                              ], 8, ["onUpdate:modelValue"]), [
                                [vModelSelect, unref(form).is_active]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.is_active,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("fieldset", { class: "border border-gray-300 dark:border-gray-400 p-4 rounded-lg" }, [
                          createVNode("legend", { class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(_ctx.$t("specifications")), 1),
                          createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4" }, [
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "category",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("category")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "category",
                                modelValue: unref(form).category,
                                "onUpdate:modelValue": ($event) => unref(form).category = $event,
                                options: __props.categories,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.category,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "brand",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("brand")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "brand",
                                modelValue: unref(form).brand,
                                "onUpdate:modelValue": ($event) => unref(form).brand = $event,
                                options: __props.brands,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`,
                                onSelect: handleBrandChange,
                                onRemove: handleBrandRemove
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.brand,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "model",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("model")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "model",
                                modelValue: unref(form).model,
                                "onUpdate:modelValue": ($event) => unref(form).model = $event,
                                options: models.value,
                                multiple: false,
                                "track-by": "id",
                                onSelect: handleModelChange,
                                onRemove: handleModelRemove,
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.model,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "condition",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("condition")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "condition",
                                modelValue: unref(form).condition,
                                "onUpdate:modelValue": ($event) => unref(form).condition = $event,
                                options: __props.conditions,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.condition,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "fuel_type",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("fuel_type")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "fuel_type",
                                modelValue: unref(form).fuel_type,
                                "onUpdate:modelValue": ($event) => unref(form).fuel_type = $event,
                                options: __props.fuel_types,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.fuel_type,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "transmission_type",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("transmission_type")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "transmission_type",
                                modelValue: unref(form).transmission_type,
                                "onUpdate:modelValue": ($event) => unref(form).transmission_type = $event,
                                options: __props.transmission_types,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.transmission_type,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "steering",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("steering")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "steering",
                                modelValue: unref(form).steering,
                                "onUpdate:modelValue": ($event) => unref(form).steering = $event,
                                options: __props.steerings,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.steering,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "color",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("color")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "color",
                                modelValue: unref(form).color,
                                "onUpdate:modelValue": ($event) => unref(form).color = $event,
                                options: __props.colors,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.color,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "drive_type",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("drive_type")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "drive_type",
                                modelValue: unref(form).drive_type,
                                "onUpdate:modelValue": ($event) => unref(form).drive_type = $event,
                                options: __props.drive_types,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.drive_type,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "passengers",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("passengers")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "passenger",
                                modelValue: unref(form).passenger,
                                "onUpdate:modelValue": ($event) => unref(form).passenger = $event,
                                options: __props.passengers,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${unref(t)("seat.count", { count: parseInt(option.name) })}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.passenger,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "location",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("location")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "location",
                                modelValue: unref(form).location,
                                "onUpdate:modelValue": ($event) => unref(form).location = $event,
                                options: __props.locations,
                                multiple: false,
                                "track-by": "id",
                                "custom-label": (option) => `${option.name}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.location,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "status",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("status")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_MultiSelect, {
                                id: "status",
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                options: statuses,
                                multiple: false,
                                "custom-label": (option) => `${_ctx.$t(option)}`
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "custom-label"]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.status,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("fieldset", { class: "border border-gray-300 dark:border-gray-400 p-4 rounded-lg" }, [
                          createVNode("legend", { class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(_ctx.$t("other_options")), 1),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode(_sfc_main$2, {
                              for_id: "hot_marks",
                              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(_ctx.$t("hot_marks")), 1)
                              ]),
                              _: 1
                            }),
                            createVNode(_component_MultiSelect, {
                              id: "hot_mark",
                              modelValue: unref(form).hot_marks,
                              "onUpdate:modelValue": ($event) => unref(form).hot_marks = $event,
                              options: __props.hot_marks,
                              multiple: true,
                              "track-by": "id",
                              "custom-label": (option) => `${option.name}`
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.hot_marks,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(carStore).groupOptions, (group_option, index) => {
                              return openBlock(), createBlock("div", { key: index }, [
                                createVNode(_sfc_main$2, {
                                  for_id: "options",
                                  class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(group_option.group_name), 1)
                                  ]),
                                  _: 2
                                }, 1024),
                                createVNode(_component_MultiSelect, {
                                  id: "options_group_" + group_option.group_id,
                                  modelValue: unref(options_form)["options_group_" + group_option.group_id],
                                  "onUpdate:modelValue": ($event) => unref(options_form)["options_group_" + group_option.group_id] = $event,
                                  options: group_option.items,
                                  multiple: true,
                                  "track-by": "id",
                                  "custom-label": (option) => `${option.name}`
                                }, null, 8, ["id", "modelValue", "onUpdate:modelValue", "options", "custom-label"])
                              ]);
                            }), 128))
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "grid gap-6 grid-cols-1 mb-6" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            isRequired: true,
                            for_id: "total_price",
                            class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("total_price")), 1)
                            ]),
                            _: 1
                          }),
                          withDirectives(createVNode("input", {
                            type: "text",
                            ref_key: "total_price",
                            ref: total_price,
                            id: "total_price",
                            readonly: "readonly",
                            "onUpdate:modelValue": ($event) => unref(form).total_price = $event,
                            class: "cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                            placeholder: _ctx.$t("total_price")
                          }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                            [vModelText, unref(form).total_price]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.total_price,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("fieldset", { class: "border border-gray-300 dark:border-gray-400 p-4 rounded-lg" }, [
                          createVNode("legend", { class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(_ctx.$t("payment_details")), 1),
                          createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-6" }, [
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "car_price",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("car_price")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "car_price",
                                id: "car_price",
                                "onUpdate:modelValue": ($event) => unref(form).car_price = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("car_price")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).car_price]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.car_price,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "towing_export_document",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("export_license")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "towing_export_document",
                                id: "towing_export_document",
                                "onUpdate:modelValue": ($event) => unref(form).towing_export_document = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("export_license")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).towing_export_document]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.towing_export_document,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "shipping",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("shipping")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "shipping",
                                id: "shipping",
                                "onUpdate:modelValue": ($event) => unref(form).shipping = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("shipping")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).shipping]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.shipping,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "tax_import",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("tax_import")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "tax_import",
                                id: "tax_import",
                                "onUpdate:modelValue": ($event) => unref(form).tax_import = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("tax_import")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).tax_import]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.tax_import,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "clearance",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("clearance")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "clearance",
                                id: "clearance",
                                "onUpdate:modelValue": ($event) => unref(form).clearance = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("clearance")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).clearance]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.clearance,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "service",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("service")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "service",
                                id: "service",
                                "onUpdate:modelValue": ($event) => unref(form).service = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("service")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).service]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.service,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("fieldset", { class: "border border-gray-300 dark:border-gray-400 p-4 rounded-lg" }, [
                          createVNode("legend", { class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(_ctx.$t("payment_terms")), 1),
                          createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3" }, [
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "first_payment",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("first_payment")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "first_payment",
                                id: "first_payment",
                                readonly: "readonly",
                                "onUpdate:modelValue": ($event) => unref(form).first_payment = $event,
                                class: "cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("first_payment")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).first_payment]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.first_payment,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "second_payment",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("second_payment")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "second_payment",
                                id: "second_payment",
                                readonly: "readonly",
                                "onUpdate:modelValue": ($event) => unref(form).second_payment = $event,
                                class: "cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("second_payment")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).second_payment]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.second_payment,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "third_payment",
                                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("third_payment")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "third_payment",
                                id: "third_payment",
                                readonly: "readonly",
                                "onUpdate:modelValue": ($event) => unref(form).third_payment = $event,
                                class: "cursor-not-allowed bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("third_payment")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).third_payment]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.third_payment,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode(_sfc_main$2, {
                          for_id: "youtube_link",
                          class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("youtube_link")), 1)
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode("input", {
                          type: "text",
                          ref: "youtube_link",
                          id: "youtube_link",
                          "onUpdate:modelValue": ($event) => unref(form).youtube_link = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                          placeholder: "https://www.youtube.com/watch?v=_FTDev"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).youtube_link]
                        ]),
                        createVNode(_component_InputError, {
                          message: unref(form).errors.youtube_link,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode(_sfc_main$2, {
                          for_id: "description",
                          class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("description")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$3, {
                          rows: "8",
                          id: "description",
                          modelValue: unref(form).description,
                          "onUpdate:modelValue": ($event) => unref(form).description = $event
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_InputError, {
                          message: unref(form).errors.description,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "grid gap-6 md:grid-cols-2" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for_id: "featured_image",
                            class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("featured_image")), 1)
                            ]),
                            _: 1
                          }),
                          createVNode(FileUpload, {
                            modelValue: unref(form).featured_image,
                            "onUpdate:modelValue": ($event) => unref(form).featured_image = $event,
                            target_input: "featured_image"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.featured_image,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$2, {
                            for_id: "gallery_images",
                            class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("gallery_images")), 1)
                            ]),
                            _: 1
                          }),
                          createVNode(FileUpload, {
                            multiple: true,
                            target_input: "gallery_images",
                            modelValue: unref(form).gallery_images,
                            "onUpdate:modelValue": ($event) => unref(form).gallery_images = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.gallery_images,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "button-group" }, [
                        createVNode("div", { class: "flex justify-start gap-5 items-center" }, [
                          createVNode(unref(Link), {
                            href: _ctx.route("cars.index"),
                            class: "focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode("input", {
                            type: "submit",
                            value: _ctx.$t("update"),
                            class: "focus:outline-none text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-1 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 dark:focus:ring-emerald-900"
                          }, null, 8, ["value"])
                        ])
                      ])
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Cars/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
