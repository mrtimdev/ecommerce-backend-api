import { ref, watch, onMounted, nextTick, resolveComponent, withCtx, unref, createVNode, toDisplayString, createTextVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, Teleport, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderTeleport, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$2 } from "./Label-Dtk55Z_1.js";
import { _ as _sfc_main$3 } from "./Textarea-tXXc-i0G.js";
import { useForm, Head, router } from "@inertiajs/vue3";
import { e as events } from "./events-Tj9gV-xT.js";
import _sfc_main$1 from "./Index-DvZYYD-O.js";
import { useI18n } from "vue-i18n";
import "mitt";
import "lodash";
import "./CheckBox-lIrETTMV.js";
import "./ActionButtons-BV8h13o9.js";
import "@vueuse/core";
import "./main-C8iUTWAB.js";
import "pinia";
import "particlesjs";
import "./DefaultLayout-e-iQ3dSt.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./useHelpers-CWP_u-9_.js";
/* empty css                                                                  */
import "./index-BxwVbOST.js";
const _sfc_main = {
  __name: "CreateOrUpdate",
  __ssrInlineRender: true,
  props: {
    show_modal: {
      type: Boolean,
      default: false
    },
    role: {
      type: Object,
      default: false
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const props = __props;
    const isModalVisible = ref(props.show_modal);
    const page_title = ref(t("role.create"));
    const button_name = ref(t("save"));
    const name = ref(null);
    const form = useForm({
      id: props.role ? props.role.id ? props.role.id : null : null,
      name: props.role ? props.role.name ? props.role.name : "" : "",
      display_name: props.role ? props.role.display_name ? props.role.display_name : "" : "",
      description: props.role ? props.role.description ? props.role.description : "" : ""
    });
    const submitForm = () => {
      if (props.role.id) {
        form.post(route("roles.update", form), {
          preserveScroll: true,
          onSuccess: () => {
            events.emit("toaster", {
              type: "success",
              action: "create",
              message: `${t("role")} [${form.name}] ${t("successfully_updated")}`
            });
            form.reset();
          }
        });
      } else {
        form.post(route("roles.store"), {
          preserveScroll: true,
          onSuccess: () => {
            events.emit("toaster", {
              type: "success",
              action: "create",
              message: `${t("role")} [${form.name}] ${t("successfully_added")}`
            });
            form.reset();
          }
        });
      }
    };
    watch(
      () => form.name,
      (newValue) => {
        form.name = newValue.toLowerCase();
      }
    );
    onMounted(() => {
      nextTick(() => {
        name.value.focus();
        if (props.role.id) {
          page_title.value = t("role.update");
          button_name.value = t("update");
        }
      });
    });
    const closeModal = () => {
      isModalVisible.value = false;
      router.get(route("roles.index"));
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      const _component_InputError = resolveComponent("InputError");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        detail: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: page_title.value }, null, _parent2, _scopeId));
            ssrRenderTeleport(_push2, (_push3) => {
              _push3(ssrRenderComponent(_component_modal, {
                size: "md",
                show: isModalVisible.value,
                "show-footer": false,
                "show-confirm-button": true,
                "button-confirm-label": "save",
                onClose: closeModal
              }, {
                title: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`<span class="!text-purple-600"${_scopeId2}>${ssrInterpolate(page_title.value)}</span>`);
                  } else {
                    return [
                      createVNode("span", { class: "!text-purple-600" }, toDisplayString(page_title.value), 1)
                    ];
                  }
                }),
                body: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`<form${_scopeId2}><div class="p-4 md:p-5"${_scopeId2}><div class="grid gap-6 mb-6 md:grid-cols-2"${_scopeId2}><div${_scopeId2}><label for="name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId2}>${ssrInterpolate(_ctx.$t("name"))}</label><input type="text" id="name"${ssrRenderAttr("value", unref(form).name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("name"))}${_scopeId2}>`);
                    _push4(ssrRenderComponent(_component_InputError, {
                      message: unref(form).errors.name,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push4(`</div><div${_scopeId2}><label for="display_name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId2}>${ssrInterpolate(_ctx.$t("display_name"))}</label><input type="text" id="display_name"${ssrRenderAttr("value", unref(form).display_name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("display_name"))}${_scopeId2}>`);
                    _push4(ssrRenderComponent(_component_InputError, {
                      message: unref(form).errors.display_name,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push4(`</div></div><div class="mb-6"${_scopeId2}>`);
                    _push4(ssrRenderComponent(_sfc_main$2, {
                      for_id: "description",
                      class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    }, {
                      default: withCtx((_3, _push5, _parent4, _scopeId3) => {
                        if (_push5) {
                          _push5(`${ssrInterpolate(_ctx.$t("description"))}`);
                        } else {
                          return [
                            createTextVNode(toDisplayString(_ctx.$t("description")), 1)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push4(ssrRenderComponent(_sfc_main$3, {
                      rows: "5",
                      id: "description",
                      modelValue: unref(form).description,
                      "onUpdate:modelValue": ($event) => unref(form).description = $event
                    }, null, _parent3, _scopeId2));
                    _push4(ssrRenderComponent(_component_InputError, {
                      message: unref(form).errors.description,
                      class: "mt-2"
                    }, null, _parent3, _scopeId2));
                    _push4(`</div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400"${_scopeId2}><div class="flex justify-center gap-5 items-center"${_scopeId2}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"${_scopeId2}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId2}>${ssrInterpolate(button_name.value)}</button></div></div></form>`);
                  } else {
                    return [
                      createVNode("form", {
                        onSubmit: withModifiers(submitForm, ["prevent"])
                      }, [
                        createVNode("div", { class: "p-4 md:p-5" }, [
                          createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                            createVNode("div", null, [
                              createVNode("label", {
                                for: "name",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, toDisplayString(_ctx.$t("name")), 1),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref_key: "name",
                                ref: name,
                                id: "name",
                                "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("name")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).name]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.name,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode("label", {
                                for: "display_name",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, toDisplayString(_ctx.$t("display_name")), 1),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "display_name",
                                id: "display_name",
                                "onUpdate:modelValue": ($event) => unref(form).display_name = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("display_name")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).display_name]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.display_name,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ])
                          ]),
                          createVNode("div", { class: "mb-6" }, [
                            createVNode(_sfc_main$2, {
                              for_id: "description",
                              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(_ctx.$t("description")), 1)
                              ]),
                              _: 1
                            }),
                            createVNode(_sfc_main$3, {
                              rows: "5",
                              id: "description",
                              modelValue: unref(form).description,
                              "onUpdate:modelValue": ($event) => unref(form).description = $event
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.description,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ])
                        ]),
                        createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                          createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                            createVNode("button", {
                              onClick: closeModal,
                              type: "button",
                              class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                            }, toDisplayString(_ctx.$t("close")), 1),
                            createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(button_name.value), 1)
                          ])
                        ])
                      ], 32)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            }, "body", false, _parent2);
          } else {
            return [
              createVNode(unref(Head), { title: page_title.value }, null, 8, ["title"]),
              (openBlock(), createBlock(Teleport, { to: "body" }, [
                createVNode(_component_modal, {
                  size: "md",
                  show: isModalVisible.value,
                  "show-footer": false,
                  "show-confirm-button": true,
                  "button-confirm-label": "save",
                  onClose: closeModal
                }, {
                  title: withCtx(() => [
                    createVNode("span", { class: "!text-purple-600" }, toDisplayString(page_title.value), 1)
                  ]),
                  body: withCtx(() => [
                    createVNode("form", {
                      onSubmit: withModifiers(submitForm, ["prevent"])
                    }, [
                      createVNode("div", { class: "p-4 md:p-5" }, [
                        createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "name",
                              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                            }, toDisplayString(_ctx.$t("name")), 1),
                            withDirectives(createVNode("input", {
                              type: "text",
                              ref_key: "name",
                              ref: name,
                              id: "name",
                              "onUpdate:modelValue": ($event) => unref(form).name = $event,
                              class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                              placeholder: _ctx.$t("name")
                            }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                              [vModelText, unref(form).name]
                            ]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.name,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "display_name",
                              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                            }, toDisplayString(_ctx.$t("display_name")), 1),
                            withDirectives(createVNode("input", {
                              type: "text",
                              ref: "display_name",
                              id: "display_name",
                              "onUpdate:modelValue": ($event) => unref(form).display_name = $event,
                              class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                              placeholder: _ctx.$t("display_name")
                            }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                              [vModelText, unref(form).display_name]
                            ]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.display_name,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ])
                        ]),
                        createVNode("div", { class: "mb-6" }, [
                          createVNode(_sfc_main$2, {
                            for_id: "description",
                            class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("description")), 1)
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$3, {
                            rows: "5",
                            id: "description",
                            modelValue: unref(form).description,
                            "onUpdate:modelValue": ($event) => unref(form).description = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_InputError, {
                            message: unref(form).errors.description,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                        createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                          createVNode("button", {
                            onClick: closeModal,
                            type: "button",
                            class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                          }, toDisplayString(_ctx.$t("close")), 1),
                          createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(button_name.value), 1)
                        ])
                      ])
                    ], 32)
                  ]),
                  _: 1
                }, 8, ["show"])
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Roles/CreateOrUpdate.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
