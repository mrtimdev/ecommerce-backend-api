import { getCurrentInstance, ref, reactive, onMounted, nextTick, createApp, h, resolveComponent, withCtx, unref, createVNode, openBlock, createBlock, withModifiers, createTextVNode, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { useForm, router, Head } from "@inertiajs/vue3";
import _sfc_main$5 from "./ChangeFeaturedImage-C_-jyng8.js";
import _sfc_main$4 from "./ChangeGalleryImages-UBvLpD2_.js";
import _sfc_main$3 from "./ModalView-BzoDWxaf.js";
import AddFeatured from "./AddFeatured-P7JtyPj8.js";
import { _ as _sfc_main$1 } from "./ActionButtons-BV8h13o9.js";
import { _ as _sfc_main$2 } from "./DefaultLayout-e-iQ3dSt.js";
import { u as useCar } from "./car-j73Ni-JN.js";
import { i as i18n } from "./index-BxwVbOST.js";
import { useI18n } from "vue-i18n";
import { u as useHelper } from "./useHelper-D2FmxUD5.js";
import { e as events } from "./events-Tj9gV-xT.js";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import { u as useHelpers } from "./useHelpers-CWP_u-9_.js";
import "./InputError-fLcttu_2.js";
import "./FileUpload-B0kSA2rb.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./Label-Dtk55Z_1.js";
import "lodash";
import "swiper/modules";
import "swiper/vue";
/* empty css                  */
import "@vueuse/core";
import "pinia";
/* empty css                                                                  */
import "moment";
import "mitt";
import "particlesjs";
const _sfc_main = {
  __name: "Featured",
  __ssrInlineRender: true,
  props: {
    cars: Array,
    featured_count: Number
  },
  setup(__props) {
    const { statusFormat, imageFormat, formatMoney, formatDate, formatNumber } = useHelper();
    const { proxy } = getCurrentInstance();
    const mainStore = useMainStore();
    const { isRole, isPermission } = useHelpers();
    const { t } = useI18n();
    const tableData = ref(false);
    useCar();
    ref(false);
    ref(false);
    const form = useForm({
      id: []
    });
    const breadcrumbs = reactive([
      { label: "Home", url: route("dashboard") },
      { label: t("cars"), url: route("cars.index") },
      { label: t("featured"), url: null, is_active: true }
    ]);
    const openModalForm = () => {
      events.emit("modal:carFeatured:open", {
        modal_title: "featured.add",
        event_type: "add"
      });
    };
    onMounted(() => {
      tableData.value = $("#cars").DataTable({
        processing: true,
        serverSide: true,
        pageLength: 10,
        order: [[4, "asc"]],
        aLengthMenu: [
          [5, 10, 25, 50, -1],
          [5, 10, 25, 50, 100, "All"]
        ],
        stateSave: true,
        stateSaveCallback: function(settings, data) {
          localStorage.setItem("DataTables_" + settings.sInstance, JSON.stringify(data));
        },
        stateLoadCallback: function(settings) {
          return JSON.parse(localStorage.getItem("DataTables_" + settings.sInstance));
        },
        ajax: {
          url: route("cars.featured.list"),
          type: "GET"
        },
        columns: [
          {
            data: "id",
            orderable: false,
            searchable: false,
            className: "checkbox-col",
            render: function(data, type, row, meta) {
              return row.DT_RowIndex;
            }
          },
          {
            data: "featured_image_full_path",
            orderable: false,
            searchable: false,
            className: "action-col text-center",
            render: function(data, type, row, meta) {
              return imageFormat(data);
            }
          },
          { data: "code", name: "code" },
          { data: "name", name: "name" },
          {
            data: "listing_date",
            name: "listing_date",
            render: (data, type, row, meta) => {
              return formatDate(data);
            }
          },
          {
            data: "total_price",
            name: "total_price",
            render: (data, type, row, meta) => {
              return formatMoney(data);
            }
          },
          { data: "year", name: "year", className: "text-center" },
          {
            data: "status",
            name: "status",
            className: "text-center",
            render: function(data, type, row, meta) {
              return statusFormat(data);
            }
          },
          {
            data: "action",
            orderable: false,
            searchable: false,
            className: "action-col",
            render: function(data, type, row, meta) {
              const actionsHtml = `<div id="actions-${row.id}"></div>`;
              nextTick(() => {
                const container = document.getElementById(`actions-${row.id}`);
                if (container.__vueApp__) {
                  container.__vueApp__.unmount();
                }
                const actionsApp = createApp({
                  render() {
                    return h(
                      _sfc_main$1,
                      {},
                      {
                        default: () => [
                          h(
                            "div",
                            {
                              class: "cursor-pointer border-t border-stroke dark:border-gray-200 inline-flex justify-start items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-100 w-full text-left --hover:bg-gray-200",
                              onClick: (e) => {
                                e.preventDefault();
                                events.emit("modal:modalview:open", {
                                  modal_title: "car.details",
                                  event_type: "view",
                                  item: row
                                });
                              }
                            },
                            [h("i", { class: "fa fa-eye mr-2" }), t("view")]
                          ),
                          h(
                            "div",
                            {
                              class: "cursor-pointer border-t border-stroke dark:border-gray-200 inline-flex justify-start items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-100 w-full text-left --hover:bg-gray-200",
                              onClick: (e) => {
                                e.preventDefault();
                                events.emit("modal:featuredimage:open", {
                                  modal_title: "featured_image",
                                  event_type: "change_featured_image",
                                  item: row
                                });
                              }
                            },
                            [h("i", { class: "fa fa-image mr-2" }), t("featured_image")]
                          ),
                          h(
                            "div",
                            {
                              class: "cursor-pointer border-t border-stroke dark:border-gray-200 inline-flex justify-start items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-100 w-full text-left --hover:bg-gray-200",
                              onClick: (e) => {
                                e.preventDefault();
                                events.emit("modal:changgallery:open", {
                                  modal_title: "gallery_images",
                                  event_type: "change_gallery_images",
                                  item: row
                                });
                              }
                            },
                            [h("i", { class: "fa fa-image mr-2" }), t("change_gallery")]
                          ),
                          isRole("owner") && isRole("admin") || isPermission(["car-edit"]) && h(
                            "div",
                            {
                              class: "cursor-pointer border-t border-stroke dark:border-gray-200 inline-flex justify-start items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-100 w-full text-left --hover:bg-gray-200",
                              onClick: (e) => {
                                router.get(route("cars.edit", row.id));
                              }
                            },
                            [h("i", { class: "fa fa-pencil mr-2" }), t("edit")]
                          ),
                          isRole("owner") && isRole("admin") || isPermission(["car-delete"]) && h(
                            "div",
                            {
                              class: "cursor-pointer border-t border-stroke dark:border-gray-200 inline-flex justify-start items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-100 w-full text-left --hover:bg-gray-200",
                              onClick: (e) => {
                                e.preventDefault();
                                openConfirmPopup(row);
                              }
                            },
                            [h("i", { class: "fa fa-trash mr-2" }), t("remove")]
                          )
                        ]
                      }
                    );
                  }
                });
                container.__vueApp__ = actionsApp;
                actionsApp.use(i18n).mount(container);
              });
              return actionsHtml;
            }
          }
        ],
        rowCallback: function(row, data, index) {
          const _row = $(row);
          $(_row).find("td:not(:first-child):not(:last-child)").addClass("cursor-pointer");
          $(_row).find("td:not(:first-child):not(:last-child)").on("click", function(e) {
            e.preventDefault();
            events.emit("modal:modalview:open", {
              modal_title: "car.details",
              event_type: "view",
              item: data
            });
          });
        },
        language: {
          // paginate: {
          //   first: "First",
          //   last: "Last",
          //   next: "Next",
          //   previous: "Previous"
          // },
          // search: "Filter records:",
          // // lengthMenu: "Display _MENU_ records per page",
          // info: "Sowing _START_ to _END_ of _TOTAL_ entries",
          // infoEmpthy: "No entries available",
          // infoFiltered: "(filtered from _MAX_ total records)",
          // zeroRecords: "No matching records found",
          // loadingRecords: "Loading...",
          // emptyTable: "No data available in table"
        }
      });
    });
    events.on("modal:success", () => {
      tableData.value.ajax.reload();
    });
    const openConfirmPopup = async (row) => {
      const result = await proxy.$swal.fire({
        title: "Are you sure?",
        html: `remove <span class="text-rose-600">[${t(row.code)}] - ${row.name}</span> from featured list!`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: t("yes"),
        cancelButtonText: t("no")
      });
      if (result.isConfirmed) {
        form.id = row.id;
        form.post(route("cars.featured.remove"), {
          preserveScroll: true,
          onSuccess: () => {
            const Toast = proxy.$swal.mixin({
              toast: true,
              position: "top-end",
              showConfirmButton: false,
              timer: 3e3,
              timerProgressBar: true,
              didOpen: (toast) => {
                toast.onmouseenter = proxy.$swal.stopTimer;
                toast.onmouseleave = proxy.$swal.resumeTimer;
              }
            });
            Toast.fire({
              icon: "success",
              title: `<span class="text-rose-600">[${t(row.code)}] - ${row.name}</span> was removed from featured list!`
            });
            form.reset();
            tableData.value.ajax.reload();
          },
          onError: () => {
          }
        });
      } else {
        console.log("Item not deleted.");
      }
    };
    events.on("confirm:confirmed", (data) => {
      const items = mainStore.selectedRows.length > 0 ? mainStore.selectedRows : data;
      form.ids = items;
      form.post(route("cars.destroy.selected"), {
        preserveScroll: true,
        onSuccess: () => {
          const Toast = proxy.$swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3e3,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.onmouseenter = proxy.$swal.stopTimer;
              toast.onmouseleave = proxy.$swal.resumeTimer;
            }
          });
          Toast.fire({
            icon: "success",
            title: `${t("item.count", items.length)} ${t("successfully_deleted")}`
          });
          form.reset();
          events.emit("confirm:cancel");
          events.emit("confirm:success");
          tableData.value.ajax.reload();
          router.get(route("cars.featured"));
        },
        onError: () => {
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Bc = resolveComponent("Bc");
      _push(ssrRenderComponent(_sfc_main$2, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: _ctx.$t("cars.featured")
            }, null, _parent2, _scopeId));
            _push2(`<div class="container"${_scopeId}><div class="content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Bc, { crumbs: breadcrumbs }, null, _parent2, _scopeId));
            _push2(`<div class="flex items-center gap-2 justify-center"${_scopeId}>`);
            if (__props.featured_count < 20) {
              _push2(`<button class="text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"${_scopeId}><i class="fi fi-rr-plus w-4 h-4 me-2"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("new"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="content-body p-5"${_scopeId}><div class="flex items-center p-4 mb-4 text-sm text-yellow-800 rounded-lg bg-yellow-50 dark:bg-gray-800 dark:text-yellow-300" role="alert"${_scopeId}><svg class="flex-shrink-0 inline w-4 h-4 me-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20"${_scopeId}><path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"${_scopeId}></path></svg><span class="sr-only"${_scopeId}>Info</span><div${_scopeId}><span class="font-medium"${_scopeId}>Note!</span> Cars Featured can create only 20 cars limited. </div></div><div class="relative"${_scopeId}><table id="cars" class="table w-full text-sm text-left rtl:text-right"${_scopeId}><thead class="text-center bg-white dark:bg-boxdark"${_scopeId}><tr${_scopeId}><th class="w-[3%]"${_scopeId}>${ssrInterpolate(_ctx.$t("#"))}</th><th class="w-[5%]"${_scopeId}>${ssrInterpolate(_ctx.$t("image"))}</th><th class="w-[5%]"${_scopeId}>${ssrInterpolate(_ctx.$t("code"))}</th><th class="w-[25%]"${_scopeId}>${ssrInterpolate(_ctx.$t("name"))}</th><th class="w-[5%]"${_scopeId}>${ssrInterpolate(_ctx.$t("listing_date"))}</th><th class="w-[5%]"${_scopeId}>${ssrInterpolate(_ctx.$t("total_price"))}</th><th class="w-[5%]"${_scopeId}>${ssrInterpolate(_ctx.$t("year"))}</th><th class="w-[10%]"${_scopeId}>${ssrInterpolate(_ctx.$t("status"))}</th><th class="w-[10%]"${_scopeId}>${ssrInterpolate(_ctx.$t("actions"))}</th></tr></thead><tbody class="text-gray-700 dark:text-gray-100 bg-white dark:bg-boxdark"${_scopeId}></tbody></table></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$3, { "show-modal": false }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, { "show-modal": false }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, { "show-modal": false }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(AddFeatured, {
              "show-modal": false,
              cars: __props.cars
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), {
                title: _ctx.$t("cars.featured")
              }, null, 8, ["title"]),
              createVNode("div", { class: "container" }, [
                createVNode("div", { class: "content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between" }, [
                  createVNode(_component_Bc, { crumbs: breadcrumbs }, null, 8, ["crumbs"]),
                  createVNode("div", { class: "flex items-center gap-2 justify-center" }, [
                    __props.featured_count < 20 ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: withModifiers(openModalForm, ["prevent"]),
                      class: "text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"
                    }, [
                      createVNode("i", { class: "fi fi-rr-plus w-4 h-4 me-2" }),
                      createTextVNode(" " + toDisplayString(_ctx.$t("new")), 1)
                    ])) : createCommentVNode("", true)
                  ])
                ]),
                createVNode("div", { class: "content-body p-5" }, [
                  createVNode("div", {
                    class: "flex items-center p-4 mb-4 text-sm text-yellow-800 rounded-lg bg-yellow-50 dark:bg-gray-800 dark:text-yellow-300",
                    role: "alert"
                  }, [
                    (openBlock(), createBlock("svg", {
                      class: "flex-shrink-0 inline w-4 h-4 me-3",
                      "aria-hidden": "true",
                      xmlns: "http://www.w3.org/2000/svg",
                      fill: "currentColor",
                      viewBox: "0 0 20 20"
                    }, [
                      createVNode("path", { d: "M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" })
                    ])),
                    createVNode("span", { class: "sr-only" }, "Info"),
                    createVNode("div", null, [
                      createVNode("span", { class: "font-medium" }, "Note!"),
                      createTextVNode(" Cars Featured can create only 20 cars limited. ")
                    ])
                  ]),
                  createVNode("div", { class: "relative" }, [
                    createVNode("table", {
                      id: "cars",
                      class: "table w-full text-sm text-left rtl:text-right"
                    }, [
                      createVNode("thead", { class: "text-center bg-white dark:bg-boxdark" }, [
                        createVNode("tr", null, [
                          createVNode("th", { class: "w-[3%]" }, toDisplayString(_ctx.$t("#")), 1),
                          createVNode("th", { class: "w-[5%]" }, toDisplayString(_ctx.$t("image")), 1),
                          createVNode("th", { class: "w-[5%]" }, toDisplayString(_ctx.$t("code")), 1),
                          createVNode("th", { class: "w-[25%]" }, toDisplayString(_ctx.$t("name")), 1),
                          createVNode("th", { class: "w-[5%]" }, toDisplayString(_ctx.$t("listing_date")), 1),
                          createVNode("th", { class: "w-[5%]" }, toDisplayString(_ctx.$t("total_price")), 1),
                          createVNode("th", { class: "w-[5%]" }, toDisplayString(_ctx.$t("year")), 1),
                          createVNode("th", { class: "w-[10%]" }, toDisplayString(_ctx.$t("status")), 1),
                          createVNode("th", { class: "w-[10%]" }, toDisplayString(_ctx.$t("actions")), 1)
                        ])
                      ]),
                      createVNode("tbody", { class: "text-gray-700 dark:text-gray-100 bg-white dark:bg-boxdark" })
                    ])
                  ])
                ])
              ]),
              createVNode(_sfc_main$3, { "show-modal": false }),
              createVNode(_sfc_main$4, { "show-modal": false }),
              createVNode(_sfc_main$5, { "show-modal": false }),
              createVNode(AddFeatured, {
                "show-modal": false,
                cars: __props.cars
              }, null, 8, ["cars"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Cars/Featured.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
