import { ref, watch, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrRenderClass, ssrInterpolate, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { useI18n } from "vue-i18n";
import { e as events } from "./events-Tj9gV-xT.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {
  __name: "FileUpload",
  __ssrInlineRender: true,
  props: {
    multiple: { type: Boolean, default: false },
    modelValue: { type: [File, Array], default: null },
    selectedFile: { type: String, default: null },
    target_input: { type: String, default: "upload-input" }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const image_path = ref(props.modelValue);
    const selectedImage = ref(null);
    const isDragging = ref(false);
    const { t } = useI18n();
    watch(
      () => props.modelValue,
      (newValue) => image_path.value = newValue
    );
    const removeImage = () => {
      image_path.value = null;
      selectedImage.value = null;
    };
    events.on("clear-selected-file", () => {
      removeImage();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["upload-container gap-6 mb-6 relative border-2 border-dashed border-gray-400 rounded-lg", { "drag-over border-purple-400": isDragging.value }]
      }, _attrs))} data-v-ae7972d1><label${ssrRenderAttr("for", __props.target_input)} style="${ssrRenderStyle({
        "background-image": selectedImage.value ? `url(${selectedImage.value})` : __props.selectedFile ? `url(/storage/${__props.selectedFile})` : "",
        "background-size": "contain",
        "background-position": "center",
        "background-repeat": "no-repeat"
      })}" class="${ssrRenderClass([{ "h-[13rem] selected-image": selectedImage.value, "h-52": !selectedImage.value }, "upload-label dark:bg-meta-4 dark:text-white text-gray-500 font-semibold text-base rounded flex flex-col items-center justify-center cursor-pointer mx-auto"])}" data-v-ae7972d1>`);
      if (!selectedImage.value) {
        _push(`<!--[--><svg xmlns="http://www.w3.org/2000/svg" class="w-[100px] mb-2 fill-gray-500" viewBox="0 0 32 32" data-v-ae7972d1><path d="M23.75 11.044a7.99 7.99 0 0 0-15.5-.009A8 8 0 0 0 9 27h3a1 1 0 0 0 0-2H9a6 6 0 0 1-.035-12 1.038 1.038 0 0 0 1.1-.854 5.991 5.991 0 0 1 11.862 0A1.08 1.08 0 0 0 23 13a6 6 0 0 1 0 12h-3a1 1 0 0 0 0 2h3a8 8 0 0 0 .75-15.956z" data-v-ae7972d1></path><path d="M20.293 19.707a1 1 0 0 0 1.414-1.414l-5-5a1 1 0 0 0-1.414 0l-5 5a1 1 0 0 0 1.414 1.414L15 16.414V29a1 1 0 0 0 2 0V16.414z" data-v-ae7972d1></path></svg><span data-v-ae7972d1>${ssrInterpolate(unref(t)("drop_file_here"))} ${ssrInterpolate(unref(t)("or"))} ${ssrInterpolate(unref(t)("browse_file"))}</span><!--]-->`);
      } else {
        _push(`<!---->`);
      }
      if (__props.multiple && image_path.value) {
        _push(`<span data-v-ae7972d1>${ssrInterpolate(unref(t)("multiple_files_selected"))}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<input type="file"${ssrRenderAttr("id", __props.target_input)}${ssrIncludeBooleanAttr(__props.multiple) ? " multiple" : ""} class="hidden" accept=".png, .jpg, .jpeg" data-v-ae7972d1><p class="text-xs font-medium text-gray-400 mt-2" data-v-ae7972d1> PNG, JPG, JPEG and 2M are allowed. </p></label>`);
      if (image_path.value || selectedImage.value) {
        _push(`<button type="button" class="remove-button absolute right-0 top-0 z-2" data-v-ae7972d1><svg class="w-3 h-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14" data-v-ae7972d1><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" data-v-ae7972d1></path></svg></button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/FileUpload.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const FileUpload = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ae7972d1"]]);
export {
  FileUpload as F
};
