import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "404",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "h-screen bg-purple-100 flex items-center justify-center" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(Head), { title: "Not Found" }, null, _parent));
      _push(`<div class="text-center"><div class="flex justify-center mb-4"><div class="w-[250px] h-[250px] rounded-full flex items-center justify-center"><img src="/assets/images/error/404.png" class="w-full h-full object-cover rounded-lg"></div></div><h1 class="text-5xl font-bold text-purple-700 mb-2">404 Not Found</h1><p class="text-lg text-gray-600 mb-6"> We&#39;re sorry. Something went wrong. </p><div class="flex justify-center items-center gap-2 mb-8"><span class="bg-gray-100 px-4 py-2 rounded-md text-sm"><code>971a4ce1-5e78-4665-805d-77d9a44cd78c</code></span></div><p class="text-sm text-gray-500 mb-4"> Please try again on the previous page, or email the error code to <a href="mailto:ngettim14@gmail.com" class="text-purple-600 underline"> ngettim14@gmail.com </a> if the same error repeats. </p><button class="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-md"> Go back to previous page </button></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Errors/404.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
