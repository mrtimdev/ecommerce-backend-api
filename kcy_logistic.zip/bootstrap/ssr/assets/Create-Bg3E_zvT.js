import { reactive, resolveComponent, withCtx, unref, createVNode, openBlock, createBlock, createTextVNode, toDisplayString, createCommentVNode, withModifiers, withDirectives, vModelText, Fragment, renderList, vModelSelect, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./DefaultLayout-e-iQ3dSt.js";
import { useI18n } from "vue-i18n";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import "@vueuse/core";
import "pinia";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./events-Tj9gV-xT.js";
import "mitt";
import "./useHelpers-CWP_u-9_.js";
/* empty css                                                                  */
import "particlesjs";
const _sfc_main = {
  __name: "Create",
  __ssrInlineRender: true,
  props: {
    categories: Array,
    units: Array
  },
  setup(__props) {
    const { t } = useI18n();
    const mainStore = useMainStore();
    const breadcrumbs = reactive([
      {
        label: "Home",
        url: route("dashboard")
      },
      {
        label: t("products"),
        url: route("products.index")
      },
      {
        label: t("create"),
        url: null,
        is_active: true
      }
    ]);
    const form = useForm({
      code: "",
      name: "",
      category_id: "",
      unit_id: "",
      price: "",
      stock_alert: "",
      description: "",
      is_active: true
    });
    const submit = () => {
      form.post(route("products.store"));
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Bc = resolveComponent("Bc");
      const _component_InputError = resolveComponent("InputError");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Create Product" }, null, _parent2, _scopeId));
            _push2(`<div class="content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Bc, { crumbs: breadcrumbs }, null, _parent2, _scopeId));
            _push2(`<div class="flex items-center gap-2 justify-center"${_scopeId}>`);
            if (unref(mainStore).selectedRows.length) {
              _push2(`<button class="text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"${_scopeId}><i class="fi fi-rr-trash w-4 h-4 me-2"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("delete"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="content-body p-5"${_scopeId}><div class="relative"${_scopeId}><form class="grid grid-cols-1 md:grid-cols-2 gap-6"${_scopeId}><div${_scopeId}><label for="code" class="block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Product Code</label><input id="code"${ssrRenderAttr("value", unref(form).code)} type="text" class="form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out" placeholder="e.g., PROD001"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              class: "mt-2",
              message: unref(form).errors.code
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}><label for="name" class="block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Product Name</label><input id="name"${ssrRenderAttr("value", unref(form).name)} type="text" class="form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out" placeholder="e.g., Wireless Mouse"${_scopeId}></div><div${_scopeId}><label for="category" class="block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Category</label><select id="category" class="form-select w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white appearance-none pr-8 transition duration-200 ease-in-out"${_scopeId}><option disabled value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).category_id) ? ssrLooseContain(unref(form).category_id, "") : ssrLooseEqual(unref(form).category_id, "")) ? " selected" : ""}${_scopeId}>-- Select Category --</option><!--[-->`);
            ssrRenderList(__props.categories, (c) => {
              _push2(`<option${ssrRenderAttr("value", c.id)}${_scopeId}>${ssrInterpolate(c.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div${_scopeId}><label for="unit" class="block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Unit</label><select id="unit" class="form-select w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white appearance-none pr-8 transition duration-200 ease-in-out"${_scopeId}><option disabled value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).unit_id) ? ssrLooseContain(unref(form).unit_id, "") : ssrLooseEqual(unref(form).unit_id, "")) ? " selected" : ""}${_scopeId}>-- Select Unit --</option><!--[-->`);
            ssrRenderList(__props.units, (u) => {
              _push2(`<option${ssrRenderAttr("value", u.id)}${_scopeId}>${ssrInterpolate(u.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div${_scopeId}><label for="price" class="block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Price</label><input id="price"${ssrRenderAttr("value", unref(form).price)} type="number" step="0.01" class="form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out" placeholder="0.00"${_scopeId}></div><div${_scopeId}><label for="stock_alert" class="block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Stock Alert Threshold</label><input id="stock_alert"${ssrRenderAttr("value", unref(form).stock_alert)} type="number" class="form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out" placeholder="e.g., 10"${_scopeId}></div><div class="col-span-full flex items-center gap-3 mt-2"${_scopeId}><input id="is_active"${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, null) : unref(form).is_active) ? " checked" : ""} type="checkbox" class="h-5 w-5 text-purple-600 dark:text-purple-500 rounded border-gray-300 dark:border-gray-600 focus:ring-purple-500 transition duration-200 ease-in-out"${_scopeId}><label for="is_active" class="text-base font-medium text-gray-700 dark:text-gray-300 cursor-pointer"${_scopeId}>Product is Active</label></div><div class="md:col-span-2"${_scopeId}><label for="description" class="block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Description</label><textarea id="description" rows="3" class="form-textarea w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out" placeholder="Product description..."${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            _push2(ssrRenderComponent(_component_InputError, {
              class: "mt-2",
              message: unref(form).errors.description
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="col-span-full flex justify-end mt-4"${_scopeId}><button type="submit" class="bg-purple-600 text-white px-8 py-3 rounded-xl hover:bg-purple-700 dark:hover:bg-purple-500 focus:outline-none focus:ring-4 focus:ring-purple-300 dark:focus:ring-purple-700 font-bold text-lg transition duration-300 ease-in-out transform hover:-translate-y-0.5"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}${_scopeId}>${ssrInterpolate(unref(form).processing ? "Saving..." : "Save Product")}</button></div></form></div></div>`);
          } else {
            return [
              createVNode(unref(Head), { title: "Create Product" }),
              createVNode("div", { class: "content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between" }, [
                createVNode(_component_Bc, { crumbs: breadcrumbs }, null, 8, ["crumbs"]),
                createVNode("div", { class: "flex items-center gap-2 justify-center" }, [
                  unref(mainStore).selectedRows.length ? (openBlock(), createBlock("button", {
                    key: 0,
                    onClick: _ctx.btnDeleteSelected,
                    class: "text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:focus:ring-purple-300"
                  }, [
                    createVNode("i", { class: "fi fi-rr-trash w-4 h-4 me-2" }),
                    createTextVNode(" " + toDisplayString(_ctx.$t("delete")), 1)
                  ], 8, ["onClick"])) : createCommentVNode("", true)
                ])
              ]),
              createVNode("div", { class: "content-body p-5" }, [
                createVNode("div", { class: "relative" }, [
                  createVNode("form", {
                    onSubmit: withModifiers(submit, ["prevent"]),
                    class: "grid grid-cols-1 md:grid-cols-2 gap-6"
                  }, [
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "code",
                        class: "block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"
                      }, "Product Code"),
                      withDirectives(createVNode("input", {
                        id: "code",
                        "onUpdate:modelValue": ($event) => unref(form).code = $event,
                        type: "text",
                        class: "form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out",
                        placeholder: "e.g., PROD001"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).code]
                      ]),
                      createVNode(_component_InputError, {
                        class: "mt-2",
                        message: unref(form).errors.code
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "name",
                        class: "block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"
                      }, "Product Name"),
                      withDirectives(createVNode("input", {
                        id: "name",
                        "onUpdate:modelValue": ($event) => unref(form).name = $event,
                        type: "text",
                        class: "form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out",
                        placeholder: "e.g., Wireless Mouse"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).name]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "category",
                        class: "block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"
                      }, "Category"),
                      withDirectives(createVNode("select", {
                        id: "category",
                        "onUpdate:modelValue": ($event) => unref(form).category_id = $event,
                        class: "form-select w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white appearance-none pr-8 transition duration-200 ease-in-out"
                      }, [
                        createVNode("option", {
                          disabled: "",
                          value: ""
                        }, "-- Select Category --"),
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.categories, (c) => {
                          return openBlock(), createBlock("option", {
                            key: c.id,
                            value: c.id
                          }, toDisplayString(c.name), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, unref(form).category_id]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "unit",
                        class: "block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"
                      }, "Unit"),
                      withDirectives(createVNode("select", {
                        id: "unit",
                        "onUpdate:modelValue": ($event) => unref(form).unit_id = $event,
                        class: "form-select w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white appearance-none pr-8 transition duration-200 ease-in-out"
                      }, [
                        createVNode("option", {
                          disabled: "",
                          value: ""
                        }, "-- Select Unit --"),
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.units, (u) => {
                          return openBlock(), createBlock("option", {
                            key: u.id,
                            value: u.id
                          }, toDisplayString(u.name), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, unref(form).unit_id]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "price",
                        class: "block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"
                      }, "Price"),
                      withDirectives(createVNode("input", {
                        id: "price",
                        "onUpdate:modelValue": ($event) => unref(form).price = $event,
                        type: "number",
                        step: "0.01",
                        class: "form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out",
                        placeholder: "0.00"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).price]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", {
                        for: "stock_alert",
                        class: "block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"
                      }, "Stock Alert Threshold"),
                      withDirectives(createVNode("input", {
                        id: "stock_alert",
                        "onUpdate:modelValue": ($event) => unref(form).stock_alert = $event,
                        type: "number",
                        class: "form-input w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out",
                        placeholder: "e.g., 10"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).stock_alert]
                      ])
                    ]),
                    createVNode("div", { class: "col-span-full flex items-center gap-3 mt-2" }, [
                      withDirectives(createVNode("input", {
                        id: "is_active",
                        "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                        type: "checkbox",
                        class: "h-5 w-5 text-purple-600 dark:text-purple-500 rounded border-gray-300 dark:border-gray-600 focus:ring-purple-500 transition duration-200 ease-in-out"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(form).is_active]
                      ]),
                      createVNode("label", {
                        for: "is_active",
                        class: "text-base font-medium text-gray-700 dark:text-gray-300 cursor-pointer"
                      }, "Product is Active")
                    ]),
                    createVNode("div", { class: "md:col-span-2" }, [
                      createVNode("label", {
                        for: "description",
                        class: "block mb-2 text-sm font-semibold text-gray-700 dark:text-gray-300"
                      }, "Description"),
                      withDirectives(createVNode("textarea", {
                        id: "description",
                        "onUpdate:modelValue": ($event) => unref(form).description = $event,
                        rows: "3",
                        class: "form-textarea w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 ease-in-out",
                        placeholder: "Product description..."
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(form).description]
                      ]),
                      createVNode(_component_InputError, {
                        class: "mt-2",
                        message: unref(form).errors.description
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "col-span-full flex justify-end mt-4" }, [
                      createVNode("button", {
                        type: "submit",
                        class: "bg-purple-600 text-white px-8 py-3 rounded-xl hover:bg-purple-700 dark:hover:bg-purple-500 focus:outline-none focus:ring-4 focus:ring-purple-300 dark:focus:ring-purple-700 font-bold text-lg transition duration-300 ease-in-out transform hover:-translate-y-0.5",
                        disabled: unref(form).processing
                      }, toDisplayString(unref(form).processing ? "Saving..." : "Save Product"), 9, ["disabled"])
                    ])
                  ], 32)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Products/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
