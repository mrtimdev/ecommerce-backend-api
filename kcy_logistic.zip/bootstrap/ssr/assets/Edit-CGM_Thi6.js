import { onMounted, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import _sfc_main$1 from "./Index-CkSklHon.js";
/* empty css                         */
import "summernote/dist/summernote-lite.js";
import { _ as _sfc_main$2 } from "./Label-Dtk55Z_1.js";
import "./DefaultLayout-e-iQ3dSt.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { e as events } from "./events-Tj9gV-xT.js";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import "@vueuse/core";
import "pinia";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./useHelpers-CWP_u-9_.js";
/* empty css                                                                  */
import "mitt";
import "particlesjs";
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    user: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const mainStore = useMainStore();
    const props = __props;
    const form = useForm({
      first_name: "",
      last_name: "",
      username: "",
      email: "",
      phone: "",
      password: "",
      password_confirmation: "",
      avatar: null,
      is_active: true
    });
    form.first_name = props.user.first_name;
    form.last_name = props.user.last_name;
    form.username = props.user.username;
    form.email = props.user.email;
    form.phone = props.user.phone;
    form.is_active = props.user.is_active;
    const handleSubmit = () => {
      form.post(route("clients.update", props.user.id), {
        preserveScroll: true,
        onSuccess: (res) => {
          events.emit("toaster", {
            type: "success",
            action: "create",
            message: `${t("user")} [${form.first_name} ${form.last_name}] ${t(
              "successfully_updated"
            )}`
          });
        },
        onError: () => {
        }
      });
    };
    onMounted(() => {
      nextTick(() => {
        Array.from(document.querySelectorAll(".multiselect__tags")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
        Array.from(document.querySelectorAll(".multiselect__input")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
        form.options = props.options;
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_InputError = resolveComponent("InputError");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: _ctx.$t("user.add")
            }, null, _parent2, _scopeId));
            _push2(`<div class="container"${_scopeId}><div class="content-header rounded-tl-md rounded-tr-md py-4 bg-white dark:bg-boxdark-1 flex flex-grow items-center justify-between"${_scopeId}><div class="flex justify-start items-center gap-1 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}><i class="fa fa-pencil w-4 h-4"${_scopeId}></i> ${ssrInterpolate(_ctx.$t("client.edit"))}</div></div><div class="content-body"${_scopeId}><div class="relative"${_scopeId}><form enctype="multipart/form-data"${_scopeId}><div class="grid grid-cols-12 gap-4"${_scopeId}><div class="col-span-12 md:col-span-8 p-4 border dark:border-gray-700 rounded-lg"${_scopeId}><div class="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "first_name",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("first_name"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("first_name")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="first_name"${ssrRenderAttr("value", unref(form).first_name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("first_name"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.first_name,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "last_name",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("last_name"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("last_name")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="last_name"${ssrRenderAttr("value", unref(form).last_name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("last_name"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.last_name,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="mb-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "username",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("username"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("username")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="username"${ssrRenderAttr("value", unref(form).username)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("username"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.username,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "email",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("email"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("email")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="email"${ssrRenderAttr("value", unref(form).email)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("email"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.email,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "phone",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("phone"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("phone")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="phone"${ssrRenderAttr("value", unref(form).phone)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("phone"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.phone,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "password",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("password"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("password")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="password"${ssrRenderAttr("value", unref(form).password)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("password"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.password,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "password_confirmation",
              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("confirm_password"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("confirm_password")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="text" id="password_confirmation"${ssrRenderAttr("value", unref(form).password_confirmation)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("confirm_password"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.password_confirmation,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div class="col-span-12 md:col-span-4 p-4 border dark:border-gray-700 rounded-lg"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for_id: "avatar",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("avatar"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("avatar")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(FileUpload, {
              modelValue: unref(form).avatar,
              "onUpdate:modelValue": ($event) => unref(form).avatar = $event,
              target_input: "avatar",
              selectedFile: props.user.avatar
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.avatar,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class=""${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              isRequired: true,
              for_id: "is_active",
              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("is_active"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("is_active")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<select id="is_active" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, true) : ssrLooseEqual(unref(form).is_active, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("active"))}</option><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, false) : ssrLooseEqual(unref(form).is_active, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("inactive"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(form).errors.is_active,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div class="button-group mt-4"${_scopeId}><div class="flex justify-start gap-5 items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("clients.index"),
              class: "focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("cancel"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="submit"${ssrRenderAttr("value", _ctx.$t("update"))} class="focus:outline-none text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-1 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 dark:focus:ring-emerald-900"${_scopeId}></div></div></form></div></div></div>`);
          } else {
            return [
              createVNode(unref(Head), {
                title: _ctx.$t("user.add")
              }, null, 8, ["title"]),
              createVNode("div", { class: "container" }, [
                createVNode("div", { class: "content-header rounded-tl-md rounded-tr-md py-4 bg-white dark:bg-boxdark-1 flex flex-grow items-center justify-between" }, [
                  createVNode("div", { class: "flex justify-start items-center gap-1 text-sm font-medium text-gray-700 dark:text-white" }, [
                    createVNode("i", { class: "fa fa-pencil w-4 h-4" }),
                    createTextVNode(" " + toDisplayString(_ctx.$t("client.edit")), 1)
                  ])
                ]),
                createVNode("div", { class: "content-body" }, [
                  createVNode("div", { class: "relative" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(handleSubmit, ["prevent"]),
                      enctype: "multipart/form-data"
                    }, [
                      createVNode("div", { class: "grid grid-cols-12 gap-4" }, [
                        createVNode("div", { class: "col-span-12 md:col-span-8 p-4 border dark:border-gray-700 rounded-lg" }, [
                          createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-4" }, [
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "first_name",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("first_name")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "first_name",
                                id: "first_name",
                                "onUpdate:modelValue": ($event) => unref(form).first_name = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("first_name")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).first_name]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.first_name,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "last_name",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("last_name")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "last_name",
                                id: "last_name",
                                "onUpdate:modelValue": ($event) => unref(form).last_name = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("last_name")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).last_name]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.last_name,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ])
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode(_sfc_main$2, {
                              isRequired: true,
                              for_id: "username",
                              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(_ctx.$t("username")), 1)
                              ]),
                              _: 1
                            }),
                            withDirectives(createVNode("input", {
                              type: "text",
                              ref: "username",
                              id: "username",
                              "onUpdate:modelValue": ($event) => unref(form).username = $event,
                              class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                              placeholder: _ctx.$t("username")
                            }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                              [vModelText, unref(form).username]
                            ]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.username,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 mb-4" }, [
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "email",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("email")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "email",
                                id: "email",
                                "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("email")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).email]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.email,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                for_id: "phone",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("phone")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "phone",
                                id: "phone",
                                "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("phone")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).phone]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.phone,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "password",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("password")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "password",
                                id: "password",
                                "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("password")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).password]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.password,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode("div", null, [
                              createVNode(_sfc_main$2, {
                                isRequired: true,
                                for_id: "password_confirmation",
                                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("confirm_password")), 1)
                                ]),
                                _: 1
                              }),
                              withDirectives(createVNode("input", {
                                type: "text",
                                ref: "password_confirmation",
                                id: "password_confirmation",
                                "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                                class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                                placeholder: _ctx.$t("confirm_password")
                              }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                                [vModelText, unref(form).password_confirmation]
                              ]),
                              createVNode(_component_InputError, {
                                message: unref(form).errors.password_confirmation,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ])
                          ])
                        ]),
                        createVNode("div", { class: "col-span-12 md:col-span-4 p-4 border dark:border-gray-700 rounded-lg" }, [
                          createVNode("div", null, [
                            createVNode(_sfc_main$2, {
                              for_id: "avatar",
                              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(_ctx.$t("avatar")), 1)
                              ]),
                              _: 1
                            }),
                            createVNode(FileUpload, {
                              modelValue: unref(form).avatar,
                              "onUpdate:modelValue": ($event) => unref(form).avatar = $event,
                              target_input: "avatar",
                              selectedFile: props.user.avatar
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "selectedFile"]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.avatar,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "" }, [
                            createVNode(_sfc_main$2, {
                              isRequired: true,
                              for_id: "is_active",
                              class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(_ctx.$t("is_active")), 1)
                              ]),
                              _: 1
                            }),
                            withDirectives(createVNode("select", {
                              "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                              id: "is_active",
                              class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                            }, [
                              createVNode("option", { value: true }, toDisplayString(_ctx.$t("active")), 1),
                              createVNode("option", { value: false }, toDisplayString(_ctx.$t("inactive")), 1)
                            ], 8, ["onUpdate:modelValue"]), [
                              [vModelSelect, unref(form).is_active]
                            ]),
                            createVNode(_component_InputError, {
                              message: unref(form).errors.is_active,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "button-group mt-4" }, [
                        createVNode("div", { class: "flex justify-start gap-5 items-center" }, [
                          createVNode(unref(Link), {
                            href: _ctx.route("clients.index"),
                            class: "focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode("input", {
                            type: "submit",
                            value: _ctx.$t("update"),
                            class: "focus:outline-none text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-1 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 dark:focus:ring-emerald-900"
                          }, null, 8, ["value"])
                        ])
                      ])
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Clients/Users/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
