import mitt from "mitt";
const events = mitt();
export {
  events as e
};
