<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your verification code</title>
</head>
<body>
    <p>Your verification code is <strong>{{ $otp }}</strong>. It will expire in 10 minutes.</p>
</body>
</html>
