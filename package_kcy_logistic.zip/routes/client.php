<?php



// Route::middleware(('auth:api'))->prefix('admin/client/')->group(function () {
//     Route::get('cars/create', [CarController::class, 'create'])->name('cars.create');
//     Route::post('cars/store', [CarController::class, 'store'])->name('cars.store');


// });