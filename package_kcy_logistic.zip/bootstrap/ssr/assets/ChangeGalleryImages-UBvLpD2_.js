import { ref, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$2 } from "./InputError-fLcttu_2.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { _ as _sfc_main$1 } from "./Label-Dtk55Z_1.js";
import { useI18n } from "vue-i18n";
import { u as useCar } from "./car-j73Ni-JN.js";
import { e as events } from "./events-Tj9gV-xT.js";
import { useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "pinia";
import "mitt";
const _sfc_main = {
  __name: "ChangeGalleryImages",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const carStore = useCar();
    const form = useForm({
      gallery_images: null
    });
    const isVisible = ref(false);
    const car_id = ref(null);
    const modal_title = ref("change_gallery_images");
    events.on("modal:changgallery:open", (data) => {
      modal_title.value = data.modal_title || "change_gallery_images";
      isVisible.value = true;
      if (data.item) {
        car_id.value = data.item.id;
        carStore.getCarGalleries(car_id.value);
      }
    });
    const closeModal = () => {
      events.emit("modal:close");
      isVisible.value = false;
      carStore.clearItem();
      car_id.value = null;
    };
    events.on("remove-gallery:success", () => {
    });
    const changeGalleryImages = (e) => {
      axios.post(route("cars.updateGallery", { car: car_id.value }), form, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }).then((res) => {
        carStore.getCarGalleries(car_id.value);
        events.emit("modal:success");
        form.gallery_images = null;
        form.errors = {};
        events.emit("toaster", {
          type: "success",
          action: "update",
          message: `${t("galleries")} ${t("successfully_updated")}`
        });
      }).catch((error) => {
        var _a;
        form.errors.gallery_images = (_a = error.response) == null ? void 0 : _a.data.message;
      });
    };
    const removeGallery = (id) => {
      axios.post(route("cars.removeGallery", { carImage: id })).then((res) => {
        carStore.getCarGalleries(car_id.value);
        events.emit("modal:success");
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form enctype="multipart/form-data"${_scopeId}><div class="p-4 md:p-5"${_scopeId}><div${_scopeId}><div class="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 mb-6"${_scopeId}><!--[-->`);
              ssrRenderList(unref(carStore).galleries, (image, index) => {
                _push3(`<div class="relative"${_scopeId}><div class="cursor-pointer absolute right-0 top-[-15px] z-index-2 text-gray-400 bg-transparent bg-rose-200 hover:bg-rose-300 hover:text-gray-900 rounded-full text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="static-modal"${_scopeId}><svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14"${_scopeId}><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"${_scopeId}></path></svg></div><img${ssrRenderAttr("src", image.image_full_path)} alt="Gallery Image" class="w-32 h-32 object-cover rounded-md"${_scopeId}></div>`);
              });
              _push3(`<!--]--></div></div><div class="grid gap-6 mb-6 md:grid-cols-1"${_scopeId}><div${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                for_id: "gallery_images",
                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("gallery_images"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("gallery_images")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(FileUpload, {
                multiple: true,
                target_input: "gallery_images",
                modelValue: unref(form).gallery_images,
                "onUpdate:modelValue": ($event) => unref(form).gallery_images = $event
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.gallery_images,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400"${_scopeId}><div class="flex justify-center gap-5 items-center"${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(changeGalleryImages, ["prevent"]),
                  enctype: "multipart/form-data"
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", null, [
                      createVNode("div", { class: "grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 mb-6" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(unref(carStore).galleries, (image, index) => {
                          return openBlock(), createBlock("div", {
                            key: index,
                            class: "relative"
                          }, [
                            createVNode("div", {
                              onClick: ($event) => removeGallery(image.id),
                              class: "cursor-pointer absolute right-0 top-[-15px] z-index-2 text-gray-400 bg-transparent bg-rose-200 hover:bg-rose-300 hover:text-gray-900 rounded-full text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white",
                              "data-modal-hide": "static-modal"
                            }, [
                              (openBlock(), createBlock("svg", {
                                class: "w-3 h-3",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "none",
                                viewBox: "0 0 14 14"
                              }, [
                                createVNode("path", {
                                  stroke: "currentColor",
                                  "stroke-linecap": "round",
                                  "stroke-linejoin": "round",
                                  "stroke-width": "2",
                                  d: "m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                                })
                              ]))
                            ], 8, ["onClick"]),
                            createVNode("img", {
                              src: image.image_full_path,
                              alt: "Gallery Image",
                              class: "w-32 h-32 object-cover rounded-md"
                            }, null, 8, ["src"])
                          ]);
                        }), 128))
                      ])
                    ]),
                    createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-1" }, [
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          for_id: "gallery_images",
                          class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("gallery_images")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(FileUpload, {
                          multiple: true,
                          target_input: "gallery_images",
                          modelValue: unref(form).gallery_images,
                          "onUpdate:modelValue": ($event) => unref(form).gallery_images = $event
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.gallery_images,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 1),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 32)
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Cars/ChangeGalleryImages.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
