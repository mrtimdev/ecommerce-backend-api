import { getCurrentInstance, ref, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./Label-Dtk55Z_1.js";
import { _ as _sfc_main$2 } from "./InputError-fLcttu_2.js";
import { useForm } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { e as events } from "./events-Tj9gV-xT.js";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import "mitt";
import "pinia";
import "particlesjs";
import "@vueuse/core";
const _sfc_main = {
  __name: "AddFeatured",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    },
    cars: Array
  },
  setup(__props) {
    const { t } = useI18n();
    const { proxy } = getCurrentInstance();
    const mainStore = useMainStore();
    const isVisible = ref(false);
    const modal_title = ref("featured.add");
    const event_type = ref("add");
    ref(null);
    const form = useForm({
      car: null
    });
    const closeModal = () => {
      isVisible.value = false;
      events.emit("modal:close");
    };
    events.on("modal:carFeatured:open", (data) => {
      modal_title.value = data.modal_title || "featured.add";
      event_type.value = data.event_type;
      isVisible.value = true;
      form.errors = {};
      if (event_type.value === "edit" && data.item) {
        nextTick(() => {
          form.id = data.item.id;
          form.code = data.item.code;
          form.name = data.item.name;
          form.car = data.item.car;
        });
      } else {
        form.id = null;
        form.code = "";
        form.name = "";
        form.car = null;
      }
      nextTick(() => {
        Array.from(document.querySelectorAll(".multiselect__tags")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
        Array.from(document.querySelectorAll(".multiselect__input")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
      });
    });
    const handleSubmit = () => {
      form.post(route("cars.featured.store"), {
        onSuccess: () => {
          const Toast = proxy.$swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3e3,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.onmouseenter = proxy.$swal.stopTimer;
              toast.onmouseleave = proxy.$swal.resumeTimer;
            }
          });
          Toast.fire({
            icon: "success",
            html: `<b>${form.car.code}:</b> added to featured successfully.`
          });
          events.emit("modal:success");
          isVisible.value = false;
        },
        onError: () => {
          isVisible.value = true;
        }
      });
    };
    events.on("delete-items", (ids) => {
      var routeName = route("options.destroy.selected", {
        ids
      });
      form.post(routeName, {
        preserveScroll: true,
        onSuccess: () => {
          events.emit("confirm:cancel");
          events.emit("confirm:success");
          events.emit("toaster", {
            type: "success",
            action: "delete",
            message: `${t("item.count", ids.length)} ${t("successfully_deleted")}`
          });
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      const _component_MultiSelect = resolveComponent("MultiSelect");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form enctype="multipart/form-data" data-v-bc757414${_scopeId}><div class="p-4 md:p-5" data-v-bc757414${_scopeId}><div data-v-bc757414${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "car" }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("select"))} ${ssrInterpolate(_ctx.$t("car"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("select")) + " " + toDisplayString(_ctx.$t("car")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "car",
                modelValue: unref(form).car,
                "onUpdate:modelValue": ($event) => unref(form).car = $event,
                options: __props.cars,
                multiple: false,
                "track-by": "id",
                "custom-label": (option) => `[${option.code}] - ${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.car,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" data-v-bc757414${_scopeId}><div class="flex justify-center gap-5 items-center" data-v-bc757414${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900" data-v-bc757414${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" data-v-bc757414${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(handleSubmit, ["prevent"]),
                  enctype: "multipart/form-data"
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", null, [
                      createVNode(_sfc_main$1, { for_id: "car" }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("select")) + " " + toDisplayString(_ctx.$t("car")), 1)
                        ]),
                        _: 1
                      }),
                      createVNode(_component_MultiSelect, {
                        id: "car",
                        modelValue: unref(form).car,
                        "onUpdate:modelValue": ($event) => unref(form).car = $event,
                        options: __props.cars,
                        multiple: false,
                        "track-by": "id",
                        "custom-label": (option) => `[${option.code}] - ${option.name}`
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                      createVNode(_sfc_main$2, {
                        message: unref(form).errors.car,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 1),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 32)
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Cars/AddFeatured.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AddFeatured = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-bc757414"]]);
export {
  AddFeatured as default
};
