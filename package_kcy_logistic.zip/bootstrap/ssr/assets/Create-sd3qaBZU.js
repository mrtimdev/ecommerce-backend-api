import { onBeforeUnmount, reactive, watch, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./DefaultLayout-e-iQ3dSt.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { Head, Link } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { u as useHelper } from "./useHelper-D2FmxUD5.js";
import { u as useCategory } from "./category-DRYYp0UH.js";
import "@vueuse/core";
import "pinia";
import "./main-C8iUTWAB.js";
import "particlesjs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./events-Tj9gV-xT.js";
import "mitt";
import "./useHelpers-CWP_u-9_.js";
/* empty css                                                                  */
import "moment";
const _sfc_main = {
  __name: "Create",
  __ssrInlineRender: true,
  setup(__props) {
    const { t } = useI18n();
    const store = useCategory();
    onBeforeUnmount(store.resetForm);
    const { generateSlug } = useHelper();
    const breadcrumbs = reactive([
      { label: "Home", url: route("dashboard") },
      { label: t("categories"), url: "/admin/categories" },
      { label: t("create"), url: null, is_active: true }
    ]);
    watch([() => store.form.name, () => store.form.code], ([newName, newCode]) => {
      store.form.slug = generateSlug(newCode, newName);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Bc = resolveComponent("Bc");
      const _component_InputError = resolveComponent("InputError");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: _ctx.$t("category.add")
            }, null, _parent2, _scopeId));
            _push2(`<div class="container"${_scopeId}><div class="content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Bc, { crumbs: breadcrumbs }, null, _parent2, _scopeId));
            _push2(`</div><div class="content-body p-5"${_scopeId}><div class="relative"${_scopeId}><form novalidate enctype="multipart/form-data"${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-2"${_scopeId}><div${_scopeId}><label for="code" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("code"))}</label><input autofocus type="text" id="code"${ssrRenderAttr("value", unref(store).form.code)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("code"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(store).form.errors.code,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}><label for="name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("name"))}</label><input type="text" id="name"${ssrRenderAttr("value", unref(store).form.name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("name"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(store).form.errors.name,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="grid gap-6 mb-6 md:grid-cols-2"${_scopeId}><div${_scopeId}><div${_scopeId}><label for="slug" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("slug"))}</label><input type="text" id="slug"${ssrRenderAttr("value", unref(store).form.slug)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("slug"))}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(store).form.errors.slug,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div${_scopeId}><label for="status" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("select_status"))}</label><select id="status" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option selected${_scopeId}>${ssrInterpolate(_ctx.$t("select_status"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(store).form.is_active) ? ssrLooseContain(unref(store).form.is_active, true) : ssrLooseEqual(unref(store).form.is_active, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("active"))}</option><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(store).form.is_active) ? ssrLooseContain(unref(store).form.is_active, false) : ssrLooseEqual(unref(store).form.is_active, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("inactive"))}</option></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(store).form.errors.is_active,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(FileUpload, {
              multiple: false,
              modelValue: unref(store).form.image_path,
              "onUpdate:modelValue": ($event) => unref(store).form.image_path = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_InputError, {
              message: unref(store).form.errors.image_path,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="modal-footer"${_scopeId}><div class="flex justify-start gap-5 items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("cars.index"),
              class: "focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$t("cancel"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<input type="submit"${ssrRenderAttr("value", _ctx.$t("save"))} class="focus:outline-none text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-1 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 dark:focus:ring-emerald-900"${_scopeId}><input type="submit"${ssrRenderAttr("value", _ctx.$t("save_and_more"))} class="focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId}></div></div></form></div></div></div>`);
          } else {
            return [
              createVNode(unref(Head), {
                title: _ctx.$t("category.add")
              }, null, 8, ["title"]),
              createVNode("div", { class: "container" }, [
                createVNode("div", { class: "content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between" }, [
                  createVNode(_component_Bc, { crumbs: breadcrumbs }, null, 8, ["crumbs"])
                ]),
                createVNode("div", { class: "content-body p-5" }, [
                  createVNode("div", { class: "relative" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(unref(store).storeCategory, ["prevent"]),
                      novalidate: "",
                      enctype: "multipart/form-data"
                    }, [
                      createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                        createVNode("div", null, [
                          createVNode("label", {
                            for: "code",
                            class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                          }, toDisplayString(_ctx.$t("code")), 1),
                          withDirectives(createVNode("input", {
                            autofocus: "",
                            type: "text",
                            ref: "code",
                            id: "code",
                            "onUpdate:modelValue": ($event) => unref(store).form.code = $event,
                            class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                            placeholder: _ctx.$t("code")
                          }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                            [vModelText, unref(store).form.code]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(store).form.errors.code,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode("label", {
                            for: "name",
                            class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                          }, toDisplayString(_ctx.$t("name")), 1),
                          withDirectives(createVNode("input", {
                            type: "text",
                            ref: "name",
                            id: "name",
                            "onUpdate:modelValue": ($event) => unref(store).form.name = $event,
                            class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                            placeholder: _ctx.$t("name")
                          }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                            [vModelText, unref(store).form.name]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(store).form.errors.name,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                        createVNode("div", null, [
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "slug",
                              class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                            }, toDisplayString(_ctx.$t("slug")), 1),
                            withDirectives(createVNode("input", {
                              type: "text",
                              ref: "slug",
                              id: "slug",
                              "onUpdate:modelValue": ($event) => unref(store).form.slug = $event,
                              class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                              placeholder: _ctx.$t("slug")
                            }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                              [vModelText, unref(store).form.slug]
                            ]),
                            createVNode(_component_InputError, {
                              message: unref(store).form.errors.slug,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ])
                        ]),
                        createVNode("div", null, [
                          createVNode("label", {
                            for: "status",
                            class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                          }, toDisplayString(_ctx.$t("select_status")), 1),
                          withDirectives(createVNode("select", {
                            "onUpdate:modelValue": ($event) => unref(store).form.is_active = $event,
                            id: "status",
                            class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                          }, [
                            createVNode("option", { selected: "" }, toDisplayString(_ctx.$t("select_status")), 1),
                            createVNode("option", { value: true }, toDisplayString(_ctx.$t("active")), 1),
                            createVNode("option", { value: false }, toDisplayString(_ctx.$t("inactive")), 1)
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, unref(store).form.is_active]
                          ]),
                          createVNode(_component_InputError, {
                            message: unref(store).form.errors.is_active,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(FileUpload, {
                            multiple: false,
                            modelValue: unref(store).form.image_path,
                            "onUpdate:modelValue": ($event) => unref(store).form.image_path = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_InputError, {
                            message: unref(store).form.errors.image_path,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "modal-footer" }, [
                        createVNode("div", { class: "flex justify-start gap-5 items-center" }, [
                          createVNode(unref(Link), {
                            href: _ctx.route("cars.index"),
                            class: "focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode("input", {
                            type: "submit",
                            value: _ctx.$t("save"),
                            onClick: ($event) => unref(store).form.is_save_and_more = false,
                            class: "focus:outline-none text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-1 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 dark:focus:ring-emerald-900"
                          }, null, 8, ["value", "onClick"]),
                          createVNode("input", {
                            type: "submit",
                            value: _ctx.$t("save_and_more"),
                            onClick: ($event) => unref(store).form.is_save_and_more = true,
                            class: "focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"
                          }, null, 8, ["value", "onClick"])
                        ])
                      ])
                    ], 40, ["onSubmit"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Categories/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
