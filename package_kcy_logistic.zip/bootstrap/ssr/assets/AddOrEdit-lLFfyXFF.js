import { ref, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./InputError-fLcttu_2.js";
import { useI18n } from "vue-i18n";
import { defineStore } from "pinia";
import { useForm } from "@inertiajs/vue3";
import { e as events } from "./events-Tj9gV-xT.js";
const useTransmissionType = defineStore("transmissionType", () => {
  const form = useForm({
    code: "",
    name: "",
    is_active: true
  });
  const modal_title = ref("transmissionType.add");
  const event_type = ref("add");
  const checkEvent = (data) => {
    resetForm();
    modal_title.value = data.modal_title;
    event_type.value = data.event_type;
    if (data.event_type === "edit") {
      form.id = data.item.id;
      form.code = data.item.code;
      form.name = data.item.name;
      form.is_active = data.item.is_active;
    }
  };
  const submitForm = () => {
    const routeName = event_type.value === "edit" ? "transmissionTypes.update" : "transmissionTypes.store";
    const routeParams = event_type.value === "edit" ? form.id : null;
    form.post(route(routeName, routeParams), {
      preserveScroll: true,
      onSuccess: () => {
        events.emit("modal:success");
        resetForm();
      },
      onError: () => {
      }
    });
  };
  const resetForm = () => {
    form.id = null;
    form.code = "";
    form.name = "";
    form.is_active = true;
    form.errors = {};
  };
  const deleteTransmissionTypes = async (item) => {
    var routeName = route("transmissionTypes.destroy.selected", {
      ids: item
    });
    form.post(routeName, {
      preserveScroll: true,
      onSuccess: () => {
        events.emit("confirm:cancel");
        events.emit("confirm:success");
      }
    });
  };
  return {
    form,
    modal_title,
    event_type,
    checkEvent,
    submitForm,
    resetForm,
    deleteTransmissionTypes
  };
});
const _sfc_main = {
  __name: "AddOrEdit",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  emits: ["open", "close", "success"],
  setup(__props, { emit: __emit }) {
    const { t } = useI18n();
    const transmissionTypeStore = useTransmissionType();
    const isVisible = ref(false);
    const name = ref(null);
    const modal_title = ref("transmission_type.add");
    events.on("modal:open", (data) => {
      modal_title.value = data.modal_title || "transmission_type.add";
      isVisible.value = true;
      transmissionTypeStore.isSuccess = false;
      transmissionTypeStore.checkEvent(data);
      nextTick(() => {
        name.value.focus();
      });
    });
    const closeModal = () => {
      events.emit("modal:close");
      isVisible.value = false;
      transmissionTypeStore.resetForm();
    };
    events.on("modal:success", () => {
      isVisible.value = false;
      transmissionTypeStore.resetForm();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form${_scopeId}><div class="p-4 md:p-5"${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-2"${_scopeId}><div${_scopeId}><label for="code" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("code"))}</label><input type="text" id="code"${ssrRenderAttr("value", unref(transmissionTypeStore).form.code)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("code"))}${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(transmissionTypeStore).form.errors.code,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div${_scopeId}><label for="name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("name"))}</label><input type="text" id="name"${ssrRenderAttr("value", unref(transmissionTypeStore).form.name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("name"))}${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(transmissionTypeStore).form.errors.name,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="mb-6"${_scopeId}><label for="status" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("select_status"))}</label><select id="status" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"${_scopeId}><option disabled${ssrIncludeBooleanAttr(Array.isArray(unref(transmissionTypeStore).form.is_active) ? ssrLooseContain(unref(transmissionTypeStore).form.is_active, null) : ssrLooseEqual(unref(transmissionTypeStore).form.is_active, null)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("select_status"))}</option><option${ssrRenderAttr("value", true)}${ssrIncludeBooleanAttr(Array.isArray(unref(transmissionTypeStore).form.is_active) ? ssrLooseContain(unref(transmissionTypeStore).form.is_active, true) : ssrLooseEqual(unref(transmissionTypeStore).form.is_active, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("active"))}</option><option${ssrRenderAttr("value", false)}${ssrIncludeBooleanAttr(Array.isArray(unref(transmissionTypeStore).form.is_active) ? ssrLooseContain(unref(transmissionTypeStore).form.is_active, false) : ssrLooseEqual(unref(transmissionTypeStore).form.is_active, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("inactive"))}</option></select>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(transmissionTypeStore).form.errors.is_active,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400"${_scopeId}><div class="flex justify-center gap-5 items-center"${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(unref(transmissionTypeStore).submitForm, ["prevent"])
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                      createVNode("div", null, [
                        createVNode("label", {
                          for: "code",
                          class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                        }, toDisplayString(_ctx.$t("code")), 1),
                        withDirectives(createVNode("input", {
                          type: "text",
                          ref: "code",
                          id: "code",
                          "onUpdate:modelValue": ($event) => unref(transmissionTypeStore).form.code = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                          placeholder: _ctx.$t("code")
                        }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(transmissionTypeStore).form.code]
                        ]),
                        createVNode(_sfc_main$1, {
                          message: unref(transmissionTypeStore).form.errors.code,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", {
                          for: "name",
                          class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                        }, toDisplayString(_ctx.$t("name")), 1),
                        withDirectives(createVNode("input", {
                          type: "text",
                          ref_key: "name",
                          ref: name,
                          id: "name",
                          "onUpdate:modelValue": ($event) => unref(transmissionTypeStore).form.name = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                          placeholder: _ctx.$t("name")
                        }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(transmissionTypeStore).form.name]
                        ]),
                        createVNode(_sfc_main$1, {
                          message: unref(transmissionTypeStore).form.errors.name,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ])
                    ]),
                    createVNode("div", { class: "mb-6" }, [
                      createVNode("label", {
                        for: "status",
                        class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      }, toDisplayString(_ctx.$t("select_status")), 1),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => unref(transmissionTypeStore).form.is_active = $event,
                        id: "status",
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500"
                      }, [
                        createVNode("option", { disabled: "" }, toDisplayString(_ctx.$t("select_status")), 1),
                        createVNode("option", { value: true }, toDisplayString(_ctx.$t("active")), 1),
                        createVNode("option", { value: false }, toDisplayString(_ctx.$t("inactive")), 1)
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, unref(transmissionTypeStore).form.is_active]
                      ]),
                      createVNode(_sfc_main$1, {
                        message: unref(transmissionTypeStore).form.errors.is_active,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 9, ["onClick"]),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 40, ["onSubmit"])
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/TransmissionTypes/AddOrEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AddOrEdit = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main
}, Symbol.toStringTag, { value: "Module" }));
export {
  AddOrEdit as A,
  _sfc_main as _,
  useTransmissionType as u
};
