import { reactive, ref, watch, computed, resolveComponent, withCtx, unref, createVNode, createTextVNode, withModifiers, withDirectives, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, vModelText, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./DefaultLayout-e-iQ3dSt.js";
import { useI18n } from "vue-i18n";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import "@vueuse/core";
import "pinia";
import "./events-Tj9gV-xT.js";
import "mitt";
import "./useHelpers-CWP_u-9_.js";
/* empty css                                                                  */
import "particlesjs";
const _sfc_main = {
  __name: "Create copy",
  __ssrInlineRender: true,
  props: {
    clients: Array
    // products: Array, // No longer directly passed, will be fetched via AJAX
  },
  setup(__props) {
    const { t } = useI18n();
    useMainStore();
    const breadcrumbs = reactive([
      { label: "Home", url: route("dashboard") },
      { label: t("stocks"), url: route("stocks.index") },
      { label: t("create"), url: null, is_active: true }
    ]);
    const form = useForm({
      client_id: "",
      items: [],
      payment_status: "unpaid",
      date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
      note: ""
    });
    const searchQuery = ref("");
    const selectedProduct = ref(null);
    const quantity = ref(1);
    const searchResults = ref([]);
    const showSearchResults = ref(false);
    let searchTimeout = null;
    watch(searchQuery, (newQuery) => {
      if (newQuery.length > 2) {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(fetchProducts, 300);
      } else {
        searchResults.value = [];
        showSearchResults.value = false;
      }
    });
    const fetchProducts = async () => {
      try {
        const response = await axios.get(route("admin.products.ajax-products"), {
          params: { query: searchQuery.value }
        });
        searchResults.value = response.data;
        showSearchResults.value = true;
      } catch (error) {
        console.error("Error fetching products:", error);
        searchResults.value = [];
        showSearchResults.value = false;
      }
    };
    const selectProduct = (product) => {
      selectedProduct.value = product;
      searchQuery.value = product.name;
      showSearchResults.value = false;
      addProduct();
    };
    const addProduct = () => {
      var _a;
      if (!selectedProduct.value || quantity.value < 1) return;
      const existingIndex = form.items.findIndex(
        (item) => item.product_id === selectedProduct.value.id
      );
      if (existingIndex >= 0) {
        form.items[existingIndex].quantity = parseFloat(form.items[existingIndex].quantity) + parseFloat(quantity.value);
      } else {
        form.items.push({
          product_id: selectedProduct.value.id,
          name: selectedProduct.value.name,
          code: selectedProduct.value.code,
          unit: (_a = selectedProduct.value.unit) == null ? void 0 : _a.name,
          price: parseFloat(selectedProduct.value.price) || 0,
          // Ensure price is a number
          quantity: parseFloat(quantity.value)
          // Ensure quantity is a number
        });
      }
      searchQuery.value = "";
      selectedProduct.value = null;
      quantity.value = 1;
      searchResults.value = [];
      showSearchResults.value = false;
    };
    const removeItem = (index) => {
      form.items.splice(index, 1);
    };
    const submit = () => {
      form.post(route("stocks.store"), {
        preserveScroll: true,
        onSuccess: () => form.reset()
      });
    };
    const subtotal = computed(() => {
      return form.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    });
    const grandTotal = computed(() => {
      return subtotal.value;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Bc = resolveComponent("Bc");
      const _component_InputError = resolveComponent("InputError");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Add Stock" }, null, _parent2, _scopeId));
            _push2(`<div class="content-header rounded-t-lg p-5 border-b bg-white dark:bg-gray-800 dark:border-gray-700 flex justify-between items-center" data-v-c1c412d6${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Bc, { crumbs: breadcrumbs }, null, _parent2, _scopeId));
            _push2(`<div class="flex gap-2" data-v-c1c412d6${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("stocks.index"),
              class: "btn-secondary"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<i class="fi fi-rr-arrow-left mr-2" data-v-c1c412d6${_scopeId2}></i> Back `);
                } else {
                  return [
                    createVNode("i", { class: "fi fi-rr-arrow-left mr-2" }),
                    createTextVNode(" Back ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="content-body p-5" data-v-c1c412d6${_scopeId}><div class="max-w-4xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden border border-gray-200 dark:border-gray-700" data-v-c1c412d6${_scopeId}><div class="p-6" data-v-c1c412d6${_scopeId}><h2 class="text-xl font-bold text-gray-800 dark:text-white mb-6" data-v-c1c412d6${_scopeId}> Add New Stock </h2><form class="space-y-6" data-v-c1c412d6${_scopeId}><div data-v-c1c412d6${_scopeId}><label class="form-label" data-v-c1c412d6${_scopeId}>Client <span class="text-red-500" data-v-c1c412d6${_scopeId}>*</span></label><select class="form-select" required data-v-c1c412d6${_scopeId}><option disabled value="" data-v-c1c412d6${ssrIncludeBooleanAttr(Array.isArray(unref(form).client_id) ? ssrLooseContain(unref(form).client_id, "") : ssrLooseEqual(unref(form).client_id, "")) ? " selected" : ""}${_scopeId}>Select Client</option><!--[-->`);
            ssrRenderList(__props.clients, (client) => {
              _push2(`<option${ssrRenderAttr("value", client.id)} class="dark:bg-gray-700" data-v-c1c412d6${_scopeId}>${ssrInterpolate(client.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            _push2(ssrRenderComponent(_component_InputError, {
              class: "mt-1",
              message: unref(form).errors.client_id
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="space-y-4" data-v-c1c412d6${_scopeId}><label class="form-label" data-v-c1c412d6${_scopeId}>Add Products</label><div class="relative" data-v-c1c412d6${_scopeId}><input${ssrRenderAttr("value", searchQuery.value)} type="text" class="form-input pr-10" placeholder="Search or scan product..." data-v-c1c412d6${_scopeId}><span class="absolute right-3 top-3 text-gray-400" data-v-c1c412d6${_scopeId}><i class="fi fi-rr-search" data-v-c1c412d6${_scopeId}></i></span>`);
            if (showSearchResults.value && searchResults.value.length) {
              _push2(`<div class="absolute z-10 mt-1 w-full bg-white dark:bg-gray-700 shadow-lg rounded-md border border-gray-200 dark:border-gray-600 max-h-60 overflow-auto" data-v-c1c412d6${_scopeId}><!--[-->`);
              ssrRenderList(searchResults.value, (product) => {
                var _a2;
                _push2(`<div class="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer" data-v-c1c412d6${_scopeId}><div class="font-medium" data-v-c1c412d6${_scopeId}>${ssrInterpolate(product.name)}</div><div class="text-sm text-gray-500 dark:text-gray-400" data-v-c1c412d6${_scopeId}>${ssrInterpolate(product.code)} • ${ssrInterpolate(product.price)} (${ssrInterpolate((_a2 = product.unit) == null ? void 0 : _a2.name)}) </div></div>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            if (selectedProduct.value) {
              _push2(`<div class="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg flex items-center justify-between" data-v-c1c412d6${_scopeId}><div data-v-c1c412d6${_scopeId}><div class="font-medium" data-v-c1c412d6${_scopeId}>${ssrInterpolate(selectedProduct.value.name)}</div><div class="text-sm text-gray-500 dark:text-gray-400" data-v-c1c412d6${_scopeId}> Price: ${ssrInterpolate(selectedProduct.value.price)} • Unit: ${ssrInterpolate((_a = selectedProduct.value.unit) == null ? void 0 : _a.name)}</div></div><div class="flex items-center space-x-2" data-v-c1c412d6${_scopeId}><input${ssrRenderAttr("value", quantity.value)} type="number" min="1" class="w-20 form-input text-center" data-v-c1c412d6${_scopeId}><button type="button" class="btn-primary py-1 px-3 text-sm" data-v-c1c412d6${_scopeId}> Add </button></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            if (unref(form).items.length) {
              _push2(`<div class="overflow-x-auto" data-v-c1c412d6${_scopeId}><table class="w-full text-sm text-left text-gray-500 dark:text-gray-400" data-v-c1c412d6${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" data-v-c1c412d6${_scopeId}><tr data-v-c1c412d6${_scopeId}><th class="px-4 py-3" data-v-c1c412d6${_scopeId}>Product</th><th class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}>Price</th><th class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}>Qty</th><th class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}>Total</th><th class="px-4 py-3" data-v-c1c412d6${_scopeId}></th></tr></thead><tbody data-v-c1c412d6${_scopeId}><!--[-->`);
              ssrRenderList(unref(form).items, (item, index) => {
                _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600" data-v-c1c412d6${_scopeId}><td class="px-4 py-3 font-medium text-gray-900 dark:text-white" data-v-c1c412d6${_scopeId}>${ssrInterpolate(item.name)} (${ssrInterpolate(item.code)}) </td><td class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}><input${ssrRenderAttr("value", item.price)} type="number" step="0.01" min="0" class="w-24 form-input text-right text-sm py-1" data-v-c1c412d6${_scopeId}></td><td class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}><input${ssrRenderAttr("value", item.quantity)} type="number" min="1" class="w-20 form-input text-right text-sm py-1" data-v-c1c412d6${_scopeId}></td><td class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}>${ssrInterpolate((item.price * item.quantity).toFixed(2))}</td><td class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}><button type="button" class="text-red-500 hover:text-red-700" data-v-c1c412d6${_scopeId}><i class="fi fi-rr-trash" data-v-c1c412d6${_scopeId}></i></button></td></tr>`);
              });
              _push2(`<!--]--></tbody><tfoot class="bg-gray-50 dark:bg-gray-700 font-medium" data-v-c1c412d6${_scopeId}><tr data-v-c1c412d6${_scopeId}><td colspan="3" class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}>Subtotal</td><td class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}>${ssrInterpolate(subtotal.value.toFixed(2))}</td><td data-v-c1c412d6${_scopeId}></td></tr><tr data-v-c1c412d6${_scopeId}><td colspan="3" class="px-4 py-3 text-right" data-v-c1c412d6${_scopeId}>Grand Total</td><td class="px-4 py-3 text-right text-lg font-bold text-purple-600 dark:text-purple-400" data-v-c1c412d6${_scopeId}>${ssrInterpolate(grandTotal.value.toFixed(2))}</td><td data-v-c1c412d6${_scopeId}></td></tr></tfoot></table></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-1 md:grid-cols-2 gap-6" data-v-c1c412d6${_scopeId}><div data-v-c1c412d6${_scopeId}><label class="form-label" data-v-c1c412d6${_scopeId}>Payment Status</label><select class="form-select" data-v-c1c412d6${_scopeId}><option value="unpaid" data-v-c1c412d6${ssrIncludeBooleanAttr(Array.isArray(unref(form).payment_status) ? ssrLooseContain(unref(form).payment_status, "unpaid") : ssrLooseEqual(unref(form).payment_status, "unpaid")) ? " selected" : ""}${_scopeId}>Unpaid</option><option value="paid" data-v-c1c412d6${ssrIncludeBooleanAttr(Array.isArray(unref(form).payment_status) ? ssrLooseContain(unref(form).payment_status, "paid") : ssrLooseEqual(unref(form).payment_status, "paid")) ? " selected" : ""}${_scopeId}>Paid</option><option value="partial" data-v-c1c412d6${ssrIncludeBooleanAttr(Array.isArray(unref(form).payment_status) ? ssrLooseContain(unref(form).payment_status, "partial") : ssrLooseEqual(unref(form).payment_status, "partial")) ? " selected" : ""}${_scopeId}>Partial Payment</option></select></div><div data-v-c1c412d6${_scopeId}><label class="form-label" data-v-c1c412d6${_scopeId}>Date</label><input type="date"${ssrRenderAttr("value", unref(form).date)} class="form-input" data-v-c1c412d6${_scopeId}></div><div class="md:col-span-2" data-v-c1c412d6${_scopeId}><label class="form-label" data-v-c1c412d6${_scopeId}>Notes</label><textarea class="form-textarea" rows="3" placeholder="Additional information..." data-v-c1c412d6${_scopeId}>${ssrInterpolate(unref(form).note)}</textarea></div></div><div class="flex justify-end pt-4" data-v-c1c412d6${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing || unref(form).items.length === 0) ? " disabled" : ""} class="${ssrRenderClass([{
              "opacity-50 cursor-not-allowed": unref(form).processing || unref(form).items.length === 0
            }, "btn-primary"])}" data-v-c1c412d6${_scopeId}>`);
            if (unref(form).processing) {
              _push2(`<span data-v-c1c412d6${_scopeId}><i class="fi fi-rr-spinner animate-spin mr-2" data-v-c1c412d6${_scopeId}></i> Processing... </span>`);
            } else {
              _push2(`<span data-v-c1c412d6${_scopeId}><i class="fi fi-rr-save mr-2" data-v-c1c412d6${_scopeId}></i> Save Stock Entry </span>`);
            }
            _push2(`</button></div></form></div></div></div>`);
          } else {
            return [
              createVNode(unref(Head), { title: "Add Stock" }),
              createVNode("div", { class: "content-header rounded-t-lg p-5 border-b bg-white dark:bg-gray-800 dark:border-gray-700 flex justify-between items-center" }, [
                createVNode(_component_Bc, { crumbs: breadcrumbs }, null, 8, ["crumbs"]),
                createVNode("div", { class: "flex gap-2" }, [
                  createVNode(unref(Link), {
                    href: _ctx.route("stocks.index"),
                    class: "btn-secondary"
                  }, {
                    default: withCtx(() => [
                      createVNode("i", { class: "fi fi-rr-arrow-left mr-2" }),
                      createTextVNode(" Back ")
                    ]),
                    _: 1
                  }, 8, ["href"])
                ])
              ]),
              createVNode("div", { class: "content-body p-5" }, [
                createVNode("div", { class: "max-w-4xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden border border-gray-200 dark:border-gray-700" }, [
                  createVNode("div", { class: "p-6" }, [
                    createVNode("h2", { class: "text-xl font-bold text-gray-800 dark:text-white mb-6" }, " Add New Stock "),
                    createVNode("form", {
                      onSubmit: withModifiers(submit, ["prevent"]),
                      class: "space-y-6"
                    }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "form-label" }, [
                          createTextVNode("Client "),
                          createVNode("span", { class: "text-red-500" }, "*")
                        ]),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => unref(form).client_id = $event,
                          class: "form-select",
                          required: ""
                        }, [
                          createVNode("option", {
                            disabled: "",
                            value: ""
                          }, "Select Client"),
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.clients, (client) => {
                            return openBlock(), createBlock("option", {
                              key: client.id,
                              value: client.id,
                              class: "dark:bg-gray-700"
                            }, toDisplayString(client.name), 9, ["value"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, unref(form).client_id]
                        ]),
                        createVNode(_component_InputError, {
                          class: "mt-1",
                          message: unref(form).errors.client_id
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode("label", { class: "form-label" }, "Add Products"),
                        createVNode("div", { class: "relative" }, [
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                            type: "text",
                            class: "form-input pr-10",
                            placeholder: "Search or scan product...",
                            onFocus: ($event) => showSearchResults.value = true
                          }, null, 40, ["onUpdate:modelValue", "onFocus"]), [
                            [vModelText, searchQuery.value]
                          ]),
                          createVNode("span", { class: "absolute right-3 top-3 text-gray-400" }, [
                            createVNode("i", { class: "fi fi-rr-search" })
                          ]),
                          showSearchResults.value && searchResults.value.length ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "absolute z-10 mt-1 w-full bg-white dark:bg-gray-700 shadow-lg rounded-md border border-gray-200 dark:border-gray-600 max-h-60 overflow-auto"
                          }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(searchResults.value, (product) => {
                              var _a2;
                              return openBlock(), createBlock("div", {
                                key: product.id,
                                class: "px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer",
                                onMousedown: withModifiers(($event) => selectProduct(product), ["prevent"])
                              }, [
                                createVNode("div", { class: "font-medium" }, toDisplayString(product.name), 1),
                                createVNode("div", { class: "text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(product.code) + " • " + toDisplayString(product.price) + " (" + toDisplayString((_a2 = product.unit) == null ? void 0 : _a2.name) + ") ", 1)
                              ], 40, ["onMousedown"]);
                            }), 128))
                          ])) : createCommentVNode("", true)
                        ]),
                        selectedProduct.value ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "bg-gray-50 dark:bg-gray-700 p-3 rounded-lg flex items-center justify-between"
                        }, [
                          createVNode("div", null, [
                            createVNode("div", { class: "font-medium" }, toDisplayString(selectedProduct.value.name), 1),
                            createVNode("div", { class: "text-sm text-gray-500 dark:text-gray-400" }, " Price: " + toDisplayString(selectedProduct.value.price) + " • Unit: " + toDisplayString((_b = selectedProduct.value.unit) == null ? void 0 : _b.name), 1)
                          ]),
                          createVNode("div", { class: "flex items-center space-x-2" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => quantity.value = $event,
                              type: "number",
                              min: "1",
                              class: "w-20 form-input text-center"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [
                                vModelText,
                                quantity.value,
                                void 0,
                                { number: true }
                              ]
                            ]),
                            createVNode("button", {
                              type: "button",
                              onClick: addProduct,
                              class: "btn-primary py-1 px-3 text-sm"
                            }, " Add ")
                          ])
                        ])) : createCommentVNode("", true)
                      ]),
                      unref(form).items.length ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "overflow-x-auto"
                      }, [
                        createVNode("table", { class: "w-full text-sm text-left text-gray-500 dark:text-gray-400" }, [
                          createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                            createVNode("tr", null, [
                              createVNode("th", { class: "px-4 py-3" }, "Product"),
                              createVNode("th", { class: "px-4 py-3 text-right" }, "Price"),
                              createVNode("th", { class: "px-4 py-3 text-right" }, "Qty"),
                              createVNode("th", { class: "px-4 py-3 text-right" }, "Total"),
                              createVNode("th", { class: "px-4 py-3" })
                            ])
                          ]),
                          createVNode("tbody", null, [
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(form).items, (item, index) => {
                              return openBlock(), createBlock("tr", {
                                key: index,
                                class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                              }, [
                                createVNode("td", { class: "px-4 py-3 font-medium text-gray-900 dark:text-white" }, toDisplayString(item.name) + " (" + toDisplayString(item.code) + ") ", 1),
                                createVNode("td", { class: "px-4 py-3 text-right" }, [
                                  withDirectives(createVNode("input", {
                                    "onUpdate:modelValue": ($event) => item.price = $event,
                                    type: "number",
                                    step: "0.01",
                                    min: "0",
                                    class: "w-24 form-input text-right text-sm py-1"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [
                                      vModelText,
                                      item.price,
                                      void 0,
                                      { number: true }
                                    ]
                                  ])
                                ]),
                                createVNode("td", { class: "px-4 py-3 text-right" }, [
                                  withDirectives(createVNode("input", {
                                    "onUpdate:modelValue": ($event) => item.quantity = $event,
                                    type: "number",
                                    min: "1",
                                    class: "w-20 form-input text-right text-sm py-1"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [
                                      vModelText,
                                      item.quantity,
                                      void 0,
                                      { number: true }
                                    ]
                                  ])
                                ]),
                                createVNode("td", { class: "px-4 py-3 text-right" }, toDisplayString((item.price * item.quantity).toFixed(2)), 1),
                                createVNode("td", { class: "px-4 py-3 text-right" }, [
                                  createVNode("button", {
                                    type: "button",
                                    onClick: ($event) => removeItem(index),
                                    class: "text-red-500 hover:text-red-700"
                                  }, [
                                    createVNode("i", { class: "fi fi-rr-trash" })
                                  ], 8, ["onClick"])
                                ])
                              ]);
                            }), 128))
                          ]),
                          createVNode("tfoot", { class: "bg-gray-50 dark:bg-gray-700 font-medium" }, [
                            createVNode("tr", null, [
                              createVNode("td", {
                                colspan: "3",
                                class: "px-4 py-3 text-right"
                              }, "Subtotal"),
                              createVNode("td", { class: "px-4 py-3 text-right" }, toDisplayString(subtotal.value.toFixed(2)), 1),
                              createVNode("td")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", {
                                colspan: "3",
                                class: "px-4 py-3 text-right"
                              }, "Grand Total"),
                              createVNode("td", { class: "px-4 py-3 text-right text-lg font-bold text-purple-600 dark:text-purple-400" }, toDisplayString(grandTotal.value.toFixed(2)), 1),
                              createVNode("td")
                            ])
                          ])
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }, [
                        createVNode("div", null, [
                          createVNode("label", { class: "form-label" }, "Payment Status"),
                          withDirectives(createVNode("select", {
                            "onUpdate:modelValue": ($event) => unref(form).payment_status = $event,
                            class: "form-select"
                          }, [
                            createVNode("option", { value: "unpaid" }, "Unpaid"),
                            createVNode("option", { value: "paid" }, "Paid"),
                            createVNode("option", { value: "partial" }, "Partial Payment")
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, unref(form).payment_status]
                          ])
                        ]),
                        createVNode("div", null, [
                          createVNode("label", { class: "form-label" }, "Date"),
                          withDirectives(createVNode("input", {
                            type: "date",
                            "onUpdate:modelValue": ($event) => unref(form).date = $event,
                            class: "form-input"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).date]
                          ])
                        ]),
                        createVNode("div", { class: "md:col-span-2" }, [
                          createVNode("label", { class: "form-label" }, "Notes"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => unref(form).note = $event,
                            class: "form-textarea",
                            rows: "3",
                            placeholder: "Additional information..."
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).note]
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-end pt-4" }, [
                        createVNode("button", {
                          type: "submit",
                          class: ["btn-primary", {
                            "opacity-50 cursor-not-allowed": unref(form).processing || unref(form).items.length === 0
                          }],
                          disabled: unref(form).processing || unref(form).items.length === 0
                        }, [
                          unref(form).processing ? (openBlock(), createBlock("span", { key: 0 }, [
                            createVNode("i", { class: "fi fi-rr-spinner animate-spin mr-2" }),
                            createTextVNode(" Processing... ")
                          ])) : (openBlock(), createBlock("span", { key: 1 }, [
                            createVNode("i", { class: "fi fi-rr-save mr-2" }),
                            createTextVNode(" Save Stock Entry ")
                          ]))
                        ], 10, ["disabled"])
                      ])
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Stocks/Create copy.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create_copy = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-c1c412d6"]]);
export {
  Create_copy as default
};
