import { ref, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./InputError-fLcttu_2.js";
import { useI18n } from "vue-i18n";
import { e as events } from "./events-Tj9gV-xT.js";
import { useForm } from "@inertiajs/vue3";
import "mitt";
const _sfc_main = {
  __name: "AddOrEdit",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const form = useForm({
      id: null,
      code: "",
      name: "",
      description: ""
    });
    const isVisible = ref(false);
    const name = ref(null);
    const modal_title = ref("steering.add");
    const event_type = ref("add");
    events.on("modal:open", (data) => {
      modal_title.value = data.modal_title || "steering.add";
      isVisible.value = true;
      modal_title.value = data.modal_title;
      event_type.value = data.event_type;
      form.reset("id", "name", "is_active");
      if (event_type.value === "edit") {
        form.id = data.item.id;
        form.code = data.item.code;
        form.name = data.item.name;
        form.description = data.item.description;
      }
      nextTick(() => {
        name.value.focus();
      });
    });
    const submitForm = () => {
      const routeName = event_type.value === "edit" ? "steerings.update" : "steerings.store";
      const routeParams = event_type.value === "edit" ? form.id : null;
      form.post(route(routeName, routeParams), {
        preserveScroll: true,
        onSuccess: () => {
          events.emit("modal:success");
          form.clearErrors();
        },
        onError: () => {
        }
      });
    };
    const closeModal = () => {
      events.emit("modal:close");
      isVisible.value = false;
      form.clearErrors();
    };
    events.on("modal:success", () => {
      isVisible.value = true;
      form.reset("id", "code", "name", "description");
      if (event_type.value === "edit") {
        isVisible.value = false;
      }
      form.clearErrors();
    });
    events.on("delete-items", (ids) => {
      var routeName = route("steerings.destroy.selected", {
        ids
      });
      form.post(routeName, {
        preserveScroll: true,
        onSuccess: () => {
          events.emit("confirm:cancel");
          events.emit("confirm:success");
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form${_scopeId}><div class="p-4 md:p-5"${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-2"${_scopeId}><div${_scopeId}><label for="code" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("code"))}</label><input type="text" id="code"${ssrRenderAttr("value", unref(form).code)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("code"))}${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.code,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div${_scopeId}><label for="name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("name"))}</label><input type="text" id="name"${ssrRenderAttr("value", unref(form).name)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("name"))}${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.name,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="md-6"${_scopeId}><label for="description" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white"${_scopeId}>${ssrInterpolate(_ctx.$t("description"))}</label><input type="text" id="description"${ssrRenderAttr("value", unref(form).description)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("description"))}${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                message: unref(form).errors.description,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400"${_scopeId}><div class="flex justify-center gap-5 items-center"${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(submitForm, ["prevent"])
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                      createVNode("div", null, [
                        createVNode("label", {
                          for: "code",
                          class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                        }, toDisplayString(_ctx.$t("code")), 1),
                        withDirectives(createVNode("input", {
                          type: "text",
                          ref: "code",
                          id: "code",
                          "onUpdate:modelValue": ($event) => unref(form).code = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                          placeholder: _ctx.$t("code")
                        }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(form).code]
                        ]),
                        createVNode(_sfc_main$1, {
                          message: unref(form).errors.code,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", {
                          for: "name",
                          class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                        }, toDisplayString(_ctx.$t("name")), 1),
                        withDirectives(createVNode("input", {
                          type: "text",
                          ref_key: "name",
                          ref: name,
                          id: "name",
                          "onUpdate:modelValue": ($event) => unref(form).name = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                          placeholder: _ctx.$t("name")
                        }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(form).name]
                        ]),
                        createVNode(_sfc_main$1, {
                          message: unref(form).errors.name,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ])
                    ]),
                    createVNode("div", { class: "md-6" }, [
                      createVNode("label", {
                        for: "description",
                        class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                      }, toDisplayString(_ctx.$t("description")), 1),
                      withDirectives(createVNode("input", {
                        type: "text",
                        ref: "description",
                        id: "description",
                        "onUpdate:modelValue": ($event) => unref(form).description = $event,
                        class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                        placeholder: _ctx.$t("description")
                      }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                        [vModelText, unref(form).description]
                      ]),
                      createVNode(_sfc_main$1, {
                        message: unref(form).errors.description,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 9, ["onClick"]),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 32)
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Steerings/AddOrEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
