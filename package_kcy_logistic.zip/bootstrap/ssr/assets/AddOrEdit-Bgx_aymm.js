import { ref, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderClass } from "vue/server-renderer";
import _ from "lodash";
import { _ as _sfc_main$1 } from "./Label-Dtk55Z_1.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { _ as _sfc_main$2 } from "./InputError-fLcttu_2.js";
import { useForm } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import { e as events } from "./events-Tj9gV-xT.js";
/* empty css                                                                  */
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import "pinia";
import "particlesjs";
import "@vueuse/core";
import "mitt";
const _sfc_main = {
  __name: "AddOrEdit",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    },
    brands: Array,
    // models: Array,
    categories: Array,
    fuel_types: Array,
    steerings: Array,
    locations: Array,
    drive_types: Array,
    passengers: Array
  },
  setup(__props) {
    const { t } = useI18n();
    const mainStore = useMainStore();
    const isVisible = ref(false);
    const modal_title = ref("slider.add");
    const event_type = ref("add");
    events.on("modal:success", () => {
      isVisible.value = false;
    });
    const models = ref([]);
    const selectedImage = ref(null);
    const code = ref(null);
    const form = useForm({
      id: null,
      code: "",
      name: "",
      brands: [],
      models: [],
      category: null,
      fuel_types: [],
      steerings: [],
      locations: [],
      drive_types: [],
      passengers: [],
      image_path: null
    });
    const closeModal = () => {
      isVisible.value = false;
      clearForm();
      events.emit("modal:close");
      isVisible.value = false;
    };
    events.on("modal:open", (data) => {
      console.log({ data });
      modal_title.value = data.modal_title || "slider.add";
      event_type.value = data.event_type;
      isVisible.value = true;
      nextTick(() => {
        code.value.focus();
      });
      form.errors = {};
      if (event_type.value === "edit" && data.item) {
        nextTick(() => {
          form.id = data.item.id;
          form.code = data.item.code;
          form.name = data.item.name;
          form.brands = data.item.brands;
          form.models = data.item.models;
          form.category = data.item.category;
          form.fuel_types = data.item.fuel_types;
          form.steerings = data.item.steerings;
          form.locations = data.item.locations;
          form.drive_types = data.item.drive_types;
          form.passengers = data.item.passengers;
          selectedImage.value = data.item.image_path;
          form.image_path = null;
          handleBrandChange();
        });
      } else {
        clearForm();
      }
      nextTick(() => {
        Array.from(document.querySelectorAll(".multiselect__tags")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
        Array.from(document.querySelectorAll(".multiselect__input")).forEach((element) => {
          element.classList.add(...mainStore.inputClasses);
        });
      });
    });
    const menuFormSubmit = () => {
      if (event_type.value === "edit") {
        form.post(route("frontend.page.menus.update", form), {
          onSuccess: () => {
            clearForm();
            isVisible.value = false;
            events.emit("modal:success");
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      } else {
        form.post(route("frontend.page.menus.store"), {
          onSuccess: () => {
            nextTick(() => {
              clearForm();
              events.emit("modal:success");
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      }
    };
    events.on("delete-items", (ids) => {
      var routeName = route("frontend.page.menus.destroy.selected", {
        ids
      });
      form.post(routeName, {
        preserveScroll: true,
        onSuccess: () => {
          events.emit("confirm:cancel");
          events.emit("confirm:success");
        }
      });
    });
    const clearForm = () => {
      form.id = null;
      form.code = "";
      form.name = "";
      form.brands = [];
      form.models = [];
      form.category = null;
      form.fuel_types = [];
      form.steerings = [];
      form.locations = [];
      form.drive_types = [];
      form.passengers = [];
      models.value = [];
      form.image_path = null;
      selectedImage.value = null;
    };
    const handleBrandChange = () => {
      models.value = [];
      if (event_type.value === "add") {
        form.models = [];
      }
      const ids = _.map(form.brands, "id");
      if (!_.isEmpty(ids)) {
        axios.get(route("models.by.brand", { ids })).then((res) => {
          models.value = res == null ? void 0 : res.data.models;
        });
      }
    };
    const handleBrandRemove = (brand) => {
      models.value = [];
      form.models = [];
      handleBrandChange();
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      const _component_MultiSelect = resolveComponent("MultiSelect");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "lg",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_2, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_2, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form enctype="multipart/form-data" data-v-f8aaeadb${_scopeId}><div class="p-4 md:p-5" data-v-f8aaeadb${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-2" data-v-f8aaeadb${_scopeId}><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                isRequired: true,
                for_id: "code"
              }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("code"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("code")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(`<input type="text" id="code"${ssrRenderAttr("value", unref(form).code)} class="${ssrRenderClass(unref(mainStore).inputClasses)}"${ssrRenderAttr("placeholder", _ctx.$t("code"))} data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.code,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                isRequired: true,
                for_id: "name"
              }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("name"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("name")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(`<input type="text" id="name"${ssrRenderAttr("value", unref(form).name)} class="${ssrRenderClass(unref(mainStore).inputClasses)}"${ssrRenderAttr("placeholder", _ctx.$t("name"))} data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.name,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="grid gap-6 mb-6 md:grid-cols-2" data-v-f8aaeadb${_scopeId}><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "brands" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("brands"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("brands")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "brands",
                modelValue: unref(form).brands,
                "onUpdate:modelValue": ($event) => unref(form).brands = $event,
                options: __props.brands,
                multiple: true,
                "track-by": "id",
                onSelect: handleBrandChange,
                onRemove: handleBrandRemove,
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.brands,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "category" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("category"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("category")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "category",
                modelValue: unref(form).category,
                "onUpdate:modelValue": ($event) => unref(form).category = $event,
                options: __props.categories,
                multiple: false,
                "track-by": "id",
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.category,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "models" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("models"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("models")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "models",
                modelValue: unref(form).models,
                "onUpdate:modelValue": ($event) => unref(form).models = $event,
                options: models.value,
                multiple: true,
                "track-by": "id",
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.models,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "fuel_types" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("fuel_types"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("fuel_types")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "fuel_types",
                modelValue: unref(form).fuel_types,
                "onUpdate:modelValue": ($event) => unref(form).fuel_types = $event,
                options: __props.fuel_types,
                multiple: true,
                "track-by": "id",
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.fuel_types,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "steerings" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("steerings"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("steerings")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "steerings",
                modelValue: unref(form).steerings,
                "onUpdate:modelValue": ($event) => unref(form).steerings = $event,
                options: __props.steerings,
                multiple: true,
                "track-by": "id",
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.steerings,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "drive_types" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("drive_types"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("drive_types")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "drive_types",
                modelValue: unref(form).drive_types,
                "onUpdate:modelValue": ($event) => unref(form).drive_types = $event,
                options: __props.drive_types,
                multiple: true,
                "track-by": "id",
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.drive_types,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "passengers" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("passengers"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("passengers")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "passengers",
                modelValue: unref(form).passengers,
                "onUpdate:modelValue": ($event) => unref(form).passengers = $event,
                options: __props.passengers,
                multiple: true,
                "track-by": "id",
                "custom-label": (option) => `${unref(t)("seat.count", { count: parseInt(option.name) })}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.passengers,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, { for_id: "locations" }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("locations"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("locations")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_component_MultiSelect, {
                id: "locations",
                modelValue: unref(form).locations,
                "onUpdate:modelValue": ($event) => unref(form).locations = $event,
                options: __props.locations,
                multiple: true,
                "track-by": "id",
                "custom-label": (option) => `${option.name}`
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.locations,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="gap-6 mb-6 relative" data-v-f8aaeadb${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                isRequired: true,
                for_id: "image_path",
                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              }, {
                default: withCtx((_3, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("image"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("image")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(FileUpload, {
                modelValue: unref(form).image_path,
                "onUpdate:modelValue": ($event) => unref(form).image_path = $event,
                target_input: "image_path",
                selectedFile: selectedImage.value
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.image_path,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" data-v-f8aaeadb${_scopeId}><div class="flex justify-center gap-5 items-center" data-v-f8aaeadb${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900" data-v-f8aaeadb${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" data-v-f8aaeadb${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(menuFormSubmit, ["prevent"]),
                  enctype: "multipart/form-data"
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          isRequired: true,
                          for_id: "code"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("code")), 1)
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode("input", {
                          type: "text",
                          id: "code",
                          ref_key: "code",
                          ref: code,
                          "onUpdate:modelValue": ($event) => unref(form).code = $event,
                          class: unref(mainStore).inputClasses,
                          placeholder: _ctx.$t("code")
                        }, null, 10, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(form).code]
                        ]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.code,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          isRequired: true,
                          for_id: "name"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("name")), 1)
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode("input", {
                          type: "text",
                          id: "name",
                          ref: "name",
                          "onUpdate:modelValue": ($event) => unref(form).name = $event,
                          class: unref(mainStore).inputClasses,
                          placeholder: _ctx.$t("name")
                        }, null, 10, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(form).name]
                        ]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.name,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ])
                    ]),
                    createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "brands" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("brands")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "brands",
                          modelValue: unref(form).brands,
                          "onUpdate:modelValue": ($event) => unref(form).brands = $event,
                          options: __props.brands,
                          multiple: true,
                          "track-by": "id",
                          onSelect: handleBrandChange,
                          onRemove: handleBrandRemove,
                          "custom-label": (option) => `${option.name}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.brands,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "category" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("category")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "category",
                          modelValue: unref(form).category,
                          "onUpdate:modelValue": ($event) => unref(form).category = $event,
                          options: __props.categories,
                          multiple: false,
                          "track-by": "id",
                          "custom-label": (option) => `${option.name}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.category,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "models" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("models")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "models",
                          modelValue: unref(form).models,
                          "onUpdate:modelValue": ($event) => unref(form).models = $event,
                          options: models.value,
                          multiple: true,
                          "track-by": "id",
                          "custom-label": (option) => `${option.name}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.models,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "fuel_types" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("fuel_types")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "fuel_types",
                          modelValue: unref(form).fuel_types,
                          "onUpdate:modelValue": ($event) => unref(form).fuel_types = $event,
                          options: __props.fuel_types,
                          multiple: true,
                          "track-by": "id",
                          "custom-label": (option) => `${option.name}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.fuel_types,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "steerings" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("steerings")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "steerings",
                          modelValue: unref(form).steerings,
                          "onUpdate:modelValue": ($event) => unref(form).steerings = $event,
                          options: __props.steerings,
                          multiple: true,
                          "track-by": "id",
                          "custom-label": (option) => `${option.name}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.steerings,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "drive_types" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("drive_types")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "drive_types",
                          modelValue: unref(form).drive_types,
                          "onUpdate:modelValue": ($event) => unref(form).drive_types = $event,
                          options: __props.drive_types,
                          multiple: true,
                          "track-by": "id",
                          "custom-label": (option) => `${option.name}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.drive_types,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "passengers" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("passengers")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "passengers",
                          modelValue: unref(form).passengers,
                          "onUpdate:modelValue": ($event) => unref(form).passengers = $event,
                          options: __props.passengers,
                          multiple: true,
                          "track-by": "id",
                          "custom-label": (option) => `${unref(t)("seat.count", { count: parseInt(option.name) })}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.passengers,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, { for_id: "locations" }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("locations")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(_component_MultiSelect, {
                          id: "locations",
                          modelValue: unref(form).locations,
                          "onUpdate:modelValue": ($event) => unref(form).locations = $event,
                          options: __props.locations,
                          multiple: true,
                          "track-by": "id",
                          "custom-label": (option) => `${option.name}`
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "custom-label"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.locations,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ])
                    ]),
                    createVNode("div", { class: "gap-6 mb-6 relative" }, [
                      createVNode(_sfc_main$1, {
                        isRequired: true,
                        for_id: "image_path",
                        class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("image")), 1)
                        ]),
                        _: 1
                      }),
                      createVNode(FileUpload, {
                        modelValue: unref(form).image_path,
                        "onUpdate:modelValue": ($event) => unref(form).image_path = $event,
                        target_input: "image_path",
                        selectedFile: selectedImage.value
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "selectedFile"]),
                      createVNode(_sfc_main$2, {
                        message: unref(form).errors.image_path,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 1),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 32)
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Frontend/Pages/Menus/AddOrEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AddOrEdit = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-f8aaeadb"]]);
export {
  AddOrEdit as default
};
