import { ref, nextTick, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./Label-Dtk55Z_1.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { _ as _sfc_main$3 } from "./Textarea-tXXc-i0G.js";
import { _ as _sfc_main$2 } from "./InputError-fLcttu_2.js";
import { useForm } from "@inertiajs/vue3";
import { useI18n } from "vue-i18n";
import { e as events } from "./events-Tj9gV-xT.js";
import { defineStore } from "pinia";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import "mitt";
const useSetting = defineStore("setting", () => {
  const countries = ref([]);
  const getCountries = async () => {
    return new Promise((resolve, reject) => {
      axios.get(route("settings.countries.all")).then((response) => {
        resolve(response);
        countries.value = response.data.countries;
      }).catch((error) => {
        reject(error);
        console.error("Error fetching countries:", error);
      });
    });
  };
  return {
    countries,
    getCountries
  };
});
const _sfc_main = {
  __name: "AddOrEdit",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const settingStore = useSetting();
    const isVisible = ref(false);
    const modal_title = ref("story.add");
    const event_type = ref("add");
    events.on("modal:success", () => {
      isVisible.value = false;
    });
    const selectedImage = ref(null);
    const title = ref(null);
    const form = useForm({
      id: null,
      title: "",
      youtube_link: "",
      facebook_link: "",
      description: "",
      is_active: true,
      image_path: null,
      country_id: null
    });
    const closeModal = () => {
      isVisible.value = false;
      resetForm();
      events.emit("modal:close");
      isVisible.value = false;
    };
    events.on("modal:open", (data) => {
      modal_title.value = data.modal_title || "story.add";
      event_type.value = data.event_type;
      isVisible.value = true;
      nextTick(() => {
        title.value.focus();
      });
      form.errors = {};
      if (event_type.value === "edit" && data.item) {
        nextTick(() => {
          form.id = data.item.id;
          form.title = data.item.title;
          form.is_active = data.item.is_active;
          selectedImage.value = data.item.image_path;
          form.image_path = null;
          form.country_id = data.item.country_id;
          form.description = data.item.description ?? "";
          form.youtube_link = data.item.youtube_link;
        });
      } else {
        resetForm();
      }
      settingStore.getCountries();
    });
    const resetForm = () => {
      form.title = "";
      form.is_active = true;
      form.youtube_link = "";
      form.facebook_link = "";
      form.description = "";
      form.country_id = null;
      form.image_path = null;
      selectedImage.value = null;
      form.clearErrors();
    };
    const storyFormSubmit = () => {
      if (event_type.value === "edit") {
        form.post(route("frontend.page.stories.update", form), {
          onSuccess: () => {
            nextTick(() => {
              form.reset();
              isVisible.value = false;
              events.emit("modal:success");
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      } else {
        form.post(route("frontend.page.stories.store"), {
          onSuccess: () => {
            nextTick(() => {
              form.title = "";
              form.description = "";
              form.is_active = true;
              form.image_path = "";
              selectedImage.value = null;
              isVisible.value = false;
              events.emit("modal:success");
            });
          },
          onError: () => {
            isVisible.value = true;
          }
        });
      }
    };
    events.on("delete-items", (ids) => {
      var routeName = route("frontend.page.stories.destroy.selected", {
        ids
      });
      form.post(routeName, {
        preserveScroll: true,
        onSuccess: () => {
          events.emit("confirm:cancel");
          events.emit("confirm:success");
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form enctype="multipart/form-data" data-v-42818ed1${_scopeId}><div class="p-4 md:p-5" data-v-42818ed1${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-2" data-v-42818ed1${_scopeId}><div data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                "is-required": true,
                for_id: "title",
                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("title"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("title")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(`<input type="text" id="title"${ssrRenderAttr("value", unref(form).title)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("title"))} data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.title,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                for_id: "is_active",
                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("select"))} ${ssrInterpolate(_ctx.$t("status"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("select")) + " " + toDisplayString(_ctx.$t("status")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(`<select id="is_active" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11" data-v-42818ed1${_scopeId}><option disabled data-v-42818ed1${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, null) : ssrLooseEqual(unref(form).is_active, null)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("select"))} ${ssrInterpolate(_ctx.$t("status"))}</option><option${ssrRenderAttr("value", true)} data-v-42818ed1${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, true) : ssrLooseEqual(unref(form).is_active, true)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("active"))}</option><option${ssrRenderAttr("value", false)} data-v-42818ed1${ssrIncludeBooleanAttr(Array.isArray(unref(form).is_active) ? ssrLooseContain(unref(form).is_active, false) : ssrLooseEqual(unref(form).is_active, false)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("inactive"))}</option></select>`);
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.is_active,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                for_id: "youtube_link",
                class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("youtube_link"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("youtube_link")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(`<input type="text" id="youtube_link"${ssrRenderAttr("value", unref(form).youtube_link)} class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"${ssrRenderAttr("placeholder", _ctx.$t("youtube_link"))} data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                for_id: "youtube_link",
                class: "block mb-2 text-xs font-normal text-gray-700 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(` Ex) https://www.youtube.com/watch?v=JZCwYaujhcQ&amp;t=250s`);
                  } else {
                    return [
                      createTextVNode(" Ex) https://www.youtube.com/watch?v=JZCwYaujhcQ&t=250s")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.youtube_link,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                for_id: "country",
                class: "block font-medium mb-1"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("country"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("country")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(`<select id="country" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11" data-v-42818ed1${_scopeId}><option${ssrRenderAttr("value", null)} disabled data-v-42818ed1${ssrIncludeBooleanAttr(Array.isArray(unref(form).country_id) ? ssrLooseContain(unref(form).country_id, null) : ssrLooseEqual(unref(form).country_id, null)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("select"))} ${ssrInterpolate(_ctx.$t("country"))}</option><!--[-->`);
              ssrRenderList(unref(settingStore).countries, (country, index) => {
                _push3(`<option${ssrRenderAttr("value", country.id)} data-v-42818ed1${_scopeId}>${ssrInterpolate(country.name)}</option>`);
              });
              _push3(`<!--]--></select>`);
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.country,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="mb-6" data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                for_id: "description",
                class: "block font-medium mb-1"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("description"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("description")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$3, {
                id: "description",
                modelValue: unref(form).description,
                "onUpdate:modelValue": ($event) => unref(form).description = $event
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.description,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div><div class="gap-6 mb-6 relative" data-v-42818ed1${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                "is-required": true,
                for_id: "image_path",
                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("image"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("image")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(FileUpload, {
                modelValue: unref(form).image_path,
                "onUpdate:modelValue": ($event) => unref(form).image_path = $event,
                target_input: "image_path",
                selectedFile: selectedImage.value
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.image_path,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" data-v-42818ed1${_scopeId}><div class="flex justify-center gap-5 items-center" data-v-42818ed1${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900" data-v-42818ed1${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" data-v-42818ed1${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(storyFormSubmit, ["prevent"]),
                  enctype: "multipart/form-data"
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-2" }, [
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          "is-required": true,
                          for_id: "title",
                          class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("title")), 1)
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode("input", {
                          type: "text",
                          id: "title",
                          ref_key: "title",
                          ref: title,
                          "onUpdate:modelValue": ($event) => unref(form).title = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                          placeholder: _ctx.$t("title")
                        }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(form).title]
                        ]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.title,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          for_id: "is_active",
                          class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("select")) + " " + toDisplayString(_ctx.$t("status")), 1)
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode("select", {
                          id: "is_active",
                          "onUpdate:modelValue": ($event) => unref(form).is_active = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"
                        }, [
                          createVNode("option", { disabled: "" }, toDisplayString(_ctx.$t("select")) + " " + toDisplayString(_ctx.$t("status")), 1),
                          createVNode("option", { value: true }, toDisplayString(_ctx.$t("active")), 1),
                          createVNode("option", { value: false }, toDisplayString(_ctx.$t("inactive")), 1)
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, unref(form).is_active]
                        ]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.is_active,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          for_id: "youtube_link",
                          class: "block mb-2 text-sm font-medium text-gray-700 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("youtube_link")), 1)
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode("input", {
                          type: "text",
                          id: "youtube_link",
                          ref: "youtube_link",
                          "onUpdate:modelValue": ($event) => unref(form).youtube_link = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11",
                          placeholder: _ctx.$t("youtube_link")
                        }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                          [vModelText, unref(form).youtube_link]
                        ]),
                        createVNode(_sfc_main$1, {
                          for_id: "youtube_link",
                          class: "block mb-2 text-xs font-normal text-gray-700 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Ex) https://www.youtube.com/watch?v=JZCwYaujhcQ&t=250s")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.youtube_link,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          for_id: "country",
                          class: "block font-medium mb-1"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("country")), 1)
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode("select", {
                          id: "country",
                          "onUpdate:modelValue": ($event) => unref(form).country_id = $event,
                          class: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"
                        }, [
                          createVNode("option", {
                            value: null,
                            disabled: ""
                          }, toDisplayString(_ctx.$t("select")) + " " + toDisplayString(_ctx.$t("country")), 1),
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(settingStore).countries, (country, index) => {
                            return openBlock(), createBlock("option", {
                              value: country.id,
                              key: index
                            }, toDisplayString(country.name), 9, ["value"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, unref(form).country_id]
                        ]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.country,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ])
                    ]),
                    createVNode("div", { class: "mb-6" }, [
                      createVNode(_sfc_main$1, {
                        for_id: "description",
                        class: "block font-medium mb-1"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("description")), 1)
                        ]),
                        _: 1
                      }),
                      createVNode(_sfc_main$3, {
                        id: "description",
                        modelValue: unref(form).description,
                        "onUpdate:modelValue": ($event) => unref(form).description = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_sfc_main$2, {
                        message: unref(form).errors.description,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", { class: "gap-6 mb-6 relative" }, [
                      createVNode(_sfc_main$1, {
                        "is-required": true,
                        for_id: "image_path",
                        class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("image")), 1)
                        ]),
                        _: 1
                      }),
                      createVNode(FileUpload, {
                        modelValue: unref(form).image_path,
                        "onUpdate:modelValue": ($event) => unref(form).image_path = $event,
                        target_input: "image_path",
                        selectedFile: selectedImage.value
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "selectedFile"]),
                      createVNode(_sfc_main$2, {
                        message: unref(form).errors.image_path,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 9, ["onClick"]),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 40, ["onSubmit"])
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Frontend/Pages/Stories/AddOrEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AddOrEdit = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-42818ed1"]]);
export {
  AddOrEdit as default
};
