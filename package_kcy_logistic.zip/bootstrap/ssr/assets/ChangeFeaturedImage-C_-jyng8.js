import { ref, resolveComponent, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderTeleport, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$2 } from "./InputError-fLcttu_2.js";
import { F as FileUpload } from "./FileUpload-B0kSA2rb.js";
import { _ as _sfc_main$1 } from "./Label-Dtk55Z_1.js";
import { useI18n } from "vue-i18n";
import { u as useCar } from "./car-j73Ni-JN.js";
import { e as events } from "./events-Tj9gV-xT.js";
import { useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "pinia";
import "mitt";
const _sfc_main = {
  __name: "ChangeFeaturedImage",
  __ssrInlineRender: true,
  props: {
    showModal: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const { t } = useI18n();
    const carStore = useCar();
    const form = useForm({
      featured_image: null
    });
    const isVisible = ref(false);
    const modal_title = ref("change_featured_image");
    events.on("modal:featuredimage:open", (data) => {
      modal_title.value = data.modal_title || "change_featured_image";
      isVisible.value = true;
      if (data.item) {
        carStore.getCarById(data.item.id);
      }
    });
    const closeModal = () => {
      events.emit("modal:close");
      isVisible.value = false;
      carStore.clearItem();
    };
    events.on("remove-gallery:success", () => {
    });
    const changeFeaturedImage = (e) => {
      axios.post(route("cars.updateFeaturedImage", { car: carStore.car.id }), form, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }).then((res) => {
        carStore.getCarById(carStore.car.id);
        events.emit("modal:success");
        form.featured_image = null;
        form.errors = {};
        events.emit("toaster", {
          type: "success",
          action: "update",
          message: `${t("featured_image")} ${t("successfully_updated")}`
        });
      }).catch((error) => {
        var _a;
        form.errors.featured_image = (_a = error.response) == null ? void 0 : _a.data.message;
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_modal = resolveComponent("modal");
      ssrRenderTeleport(_push, (_push2) => {
        _push2(ssrRenderComponent(_component_modal, {
          size: "md",
          show: isVisible.value,
          "show-footer": false,
          "show-confirm-button": true,
          "button-confirm-label": "save",
          onClose: closeModal
        }, {
          title: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`${ssrInterpolate(unref(t)(modal_title.value))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(t)(modal_title.value)), 1)
              ];
            }
          }),
          body: withCtx((_, _push3, _parent2, _scopeId) => {
            if (_push3) {
              _push3(`<form enctype="multipart/form-data"${_scopeId}><div class="p-4 md:p-5"${_scopeId}><div class="grid gap-6 mb-6 md:grid-cols-1"${_scopeId}><div${_scopeId}>`);
              _push3(ssrRenderComponent(_sfc_main$1, {
                for_id: "featured_image",
                class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              }, {
                default: withCtx((_2, _push4, _parent3, _scopeId2) => {
                  if (_push4) {
                    _push4(`${ssrInterpolate(_ctx.$t("featured_image"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("featured_image")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push3(ssrRenderComponent(FileUpload, {
                modelValue: unref(form).featured_image,
                "onUpdate:modelValue": ($event) => unref(form).featured_image = $event,
                target_input: "featured_image",
                selectedFile: unref(carStore).car.featured_image
              }, null, _parent2, _scopeId));
              _push3(ssrRenderComponent(_sfc_main$2, {
                message: unref(form).errors.featured_image,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push3(`</div></div></div><div class="modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400"${_scopeId}><div class="flex justify-center gap-5 items-center"${_scopeId}><button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"${_scopeId}>${ssrInterpolate(_ctx.$t("close"))}</button><button class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId}>${ssrInterpolate(_ctx.$t("save"))}</button></div></div></form>`);
            } else {
              return [
                createVNode("form", {
                  onSubmit: withModifiers(changeFeaturedImage, ["prevent"]),
                  enctype: "multipart/form-data"
                }, [
                  createVNode("div", { class: "p-4 md:p-5" }, [
                    createVNode("div", { class: "grid gap-6 mb-6 md:grid-cols-1" }, [
                      createVNode("div", null, [
                        createVNode(_sfc_main$1, {
                          for_id: "featured_image",
                          class: "block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("featured_image")), 1)
                          ]),
                          _: 1
                        }),
                        createVNode(FileUpload, {
                          modelValue: unref(form).featured_image,
                          "onUpdate:modelValue": ($event) => unref(form).featured_image = $event,
                          target_input: "featured_image",
                          selectedFile: unref(carStore).car.featured_image
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "selectedFile"]),
                        createVNode(_sfc_main$2, {
                          message: unref(form).errors.featured_image,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "modal-footer p-4 md:p-5 border-t border-gray-300 dark:border-gray-400" }, [
                    createVNode("div", { class: "flex justify-center gap-5 items-center" }, [
                      createVNode("button", {
                        onClick: closeModal,
                        type: "button",
                        class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-1 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                      }, toDisplayString(_ctx.$t("close")), 1),
                      createVNode("button", { class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-1 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900" }, toDisplayString(_ctx.$t("save")), 1)
                    ])
                  ])
                ], 32)
              ];
            }
          }),
          _: 1
        }, _parent));
      }, "body", false, _parent);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Cars/ChangeFeaturedImage.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
