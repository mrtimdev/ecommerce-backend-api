import { ref, mergeProps, unref, useSSRContext, withCtx, createVNode, toDisplayString, createTextVNode, openBlock, createBlock, onMounted, onBeforeUnmount } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderAttr, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderComponent, ssrRenderSlot, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { useStorage, onClickOutside } from "@vueuse/core";
import { defineStore } from "pinia";
import { u as useMainStore } from "./main-C8iUTWAB.js";
import { Link, usePage } from "@inertiajs/vue3";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import { e as events } from "./events-Tj9gV-xT.js";
import { u as useHelpers } from "./useHelpers-CWP_u-9_.js";
/* empty css                                                                  */
const useSidebarStore = defineStore("sidebar", () => {
  const isSidebarOpen = ref(false);
  const selected = useStorage("selected", ref("eCommerce"));
  const page = useStorage("page", ref("Dashboard"));
  function toggleSidebar() {
    isSidebarOpen.value = !isSidebarOpen.value;
  }
  return { isSidebarOpen, toggleSidebar, selected, page };
});
const _sfc_main$f = {
  __name: "DarkModeSwitcher",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useMainStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<label${ssrRenderAttrs(mergeProps({
        class: [{ "bg-purple-700": unref(store).darkMode, "bg-stroke": !unref(store).darkMode }, "relative m-0 block h-7.5 w-14 rounded-full"]
      }, _attrs))}><input type="checkbox" class="absolute top-0 z-50 m-0 h-full w-full cursor-pointer opacity-0"><span class="${ssrRenderClass([{ "right-1 translate-x-full": unref(store).darkMode }, "absolute top-1/2 left-1 flex h-6 w-6 -translate-y-1/2 translate-x-0 items-center justify-center rounded-full bg-white shadow-switcher duration-75 ease-linear"])}"><span class="dark:hidden"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.99992 12.6666C10.5772 12.6666 12.6666 10.5772 12.6666 7.99992C12.6666 5.42259 10.5772 3.33325 7.99992 3.33325C5.42259 3.33325 3.33325 5.42259 3.33325 7.99992C3.33325 10.5772 5.42259 12.6666 7.99992 12.6666Z" fill="#969AA1"></path><path d="M8.00008 15.3067C7.63341 15.3067 7.33342 15.0334 7.33342 14.6667V14.6134C7.33342 14.2467 7.63341 13.9467 8.00008 13.9467C8.36675 13.9467 8.66675 14.2467 8.66675 14.6134C8.66675 14.9801 8.36675 15.3067 8.00008 15.3067ZM12.7601 13.4267C12.5867 13.4267 12.4201 13.3601 12.2867 13.2334L12.2001 13.1467C11.9401 12.8867 11.9401 12.4667 12.2001 12.2067C12.4601 11.9467 12.8801 11.9467 13.1401 12.2067L13.2267 12.2934C13.4867 12.5534 13.4867 12.9734 13.2267 13.2334C13.1001 13.3601 12.9334 13.4267 12.7601 13.4267ZM3.24008 13.4267C3.06675 13.4267 2.90008 13.3601 2.76675 13.2334C2.50675 12.9734 2.50675 12.5534 2.76675 12.2934L2.85342 12.2067C3.11342 11.9467 3.53341 11.9467 3.79341 12.2067C4.05341 12.4667 4.05341 12.8867 3.79341 13.1467L3.70675 13.2334C3.58008 13.3601 3.40675 13.4267 3.24008 13.4267ZM14.6667 8.66675H14.6134C14.2467 8.66675 13.9467 8.36675 13.9467 8.00008C13.9467 7.63341 14.2467 7.33342 14.6134 7.33342C14.9801 7.33342 15.3067 7.63341 15.3067 8.00008C15.3067 8.36675 15.0334 8.66675 14.6667 8.66675ZM1.38675 8.66675H1.33341C0.966748 8.66675 0.666748 8.36675 0.666748 8.00008C0.666748 7.63341 0.966748 7.33342 1.33341 7.33342C1.70008 7.33342 2.02675 7.63341 2.02675 8.00008C2.02675 8.36675 1.75341 8.66675 1.38675 8.66675ZM12.6734 3.99341C12.5001 3.99341 12.3334 3.92675 12.2001 3.80008C11.9401 3.54008 11.9401 3.12008 12.2001 2.86008L12.2867 2.77341C12.5467 2.51341 12.9667 2.51341 13.2267 2.77341C13.4867 3.03341 13.4867 3.45341 13.2267 3.71341L13.1401 3.80008C13.0134 3.92675 12.8467 3.99341 12.6734 3.99341ZM3.32675 3.99341C3.15341 3.99341 2.98675 3.92675 2.85342 3.80008L2.76675 3.70675C2.50675 3.44675 2.50675 3.02675 2.76675 2.76675C3.02675 2.50675 3.44675 2.50675 3.70675 2.76675L3.79341 2.85342C4.05341 3.11342 4.05341 3.53341 3.79341 3.79341C3.66675 3.92675 3.49341 3.99341 3.32675 3.99341ZM8.00008 2.02675C7.63341 2.02675 7.33342 1.75341 7.33342 1.38675V1.33341C7.33342 0.966748 7.63341 0.666748 8.00008 0.666748C8.36675 0.666748 8.66675 0.966748 8.66675 1.33341C8.66675 1.70008 8.36675 2.02675 8.00008 2.02675Z" fill="#969AA1"></path></svg></span><span class="hidden dark:inline-block"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.3533 10.62C14.2466 10.44 13.9466 10.16 13.1999 10.2933C12.7866 10.3667 12.3666 10.4 11.9466 10.38C10.3933 10.3133 8.98659 9.6 8.00659 8.5C7.13993 7.53333 6.60659 6.27333 6.59993 4.91333C6.59993 4.15333 6.74659 3.42 7.04659 2.72666C7.33993 2.05333 7.13326 1.7 6.98659 1.55333C6.83326 1.4 6.47326 1.18666 5.76659 1.48C3.03993 2.62666 1.35326 5.36 1.55326 8.28666C1.75326 11.04 3.68659 13.3933 6.24659 14.28C6.85993 14.4933 7.50659 14.62 8.17326 14.6467C8.27993 14.6533 8.38659 14.66 8.49326 14.66C10.7266 14.66 12.8199 13.6067 14.1399 11.8133C14.5866 11.1933 14.4666 10.8 14.3533 10.62Z" fill="#969AA1"></path></svg></span></span></label>`);
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Header/DarkModeSwitcher.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const _imports_0 = "/build/assets/en-DrvOrqix.png";
const _imports_1 = "/build/assets/kh-DHX8EB8y.png";
const _sfc_main$e = {
  __name: "LangSwitcher",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useMainStore();
    const dropdownOpen = ref(false);
    const target = ref(null);
    onClickOutside(target, () => {
      dropdownOpen.value = false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "relative inline-block text-left text-black dark:text-white",
        ref_key: "target",
        ref: target
      }, _attrs))}><div><button type="button" class="inline-flex justify-center items-center w-full rounded-md bg-stroke hover:bg-gray-200 dark:bg-meta-4 shadow-sm h-8.5 px-1 text-sm font-medium text-gray-700 dark:text-white focus:outline-none">`);
      if (unref(store).locale === "en") {
        _push(`<img${ssrRenderAttr("src", _imports_0)} class="mr-2 h-5 w-5">`);
      } else {
        _push(`<img${ssrRenderAttr("src", _imports_1)} class="mr-2 h-5 w-5">`);
      }
      _push(` ${ssrInterpolate(unref(store).locale === "en" ? "English" : "Khmer")} <svg class="${ssrRenderClass([{ "transform rotate-180": dropdownOpen.value }, "transition ease-in-out duration-300 -mr-1 ml-2 h-5 w-5"])}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 011.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg></button></div>`);
      if (dropdownOpen.value) {
        _push(`<div class="absolute -right-0 mt-2 flex w-full flex-col rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark sm:right-0 sm:w-40"><div><button class="block px-4 py-2 text-sm text-gray-700 dark:text-white hover:bg-gray-100 w-full text-left dark:hover:bg-meta-4"><img${ssrRenderAttr("src", _imports_0)} class="inline h-4 w-4 mr-2"> English </button><button class="border-t border-stroke dark:border-strokedark block px-4 py-2 text-sm text-gray-700 dark:text-white w-full text-left hover:bg-gray-2 dark:hover:bg-meta-4"><img${ssrRenderAttr("src", _imports_1)} class="inline h-4 w-4 mr-2"> Khmer </button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Header/LangSwitcher.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const _sfc_main$d = {
  __name: "DropdownNotification",
  __ssrInlineRender: true,
  setup(__props) {
    const target = ref(null);
    const dropdownOpen = ref(false);
    const notifying = ref(true);
    onClickOutside(target, () => {
      dropdownOpen.value = false;
    });
    const notificationItems = ref([
      {
        route: "#",
        title: "Edit your information in a swipe",
        details: "Sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim.",
        time: "12 May, 2025"
      },
      {
        route: "#",
        title: "It is a long established fact",
        details: "that a reader will be distracted by the readable.",
        time: "24 Feb, 2025"
      },
      {
        route: "#",
        title: "There are many variations",
        details: "of passages of Lorem Ipsum available, but the majority have suffered",
        time: "04 Jan, 2025"
      },
      {
        route: "#",
        title: "There are many variations",
        details: "of passages of Lorem Ipsum available, but the majority have suffered",
        time: "01 Dec, 2024"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(mergeProps({
        class: "relative",
        ref_key: "target",
        ref: target
      }, _attrs))}><a class="relative flex h-8.5 w-8.5 items-center justify-center rounded-full border-[0.5px] border-stroke bg-gray hover:text-primary dark:border-strokedark dark:bg-meta-4 dark:text-white"><span class="${ssrRenderClass([!notifying.value && "hidden", "absolute -top-0.5 right-0 z-1 h-2 w-2 rounded-full bg-meta-1"])}"><span class="absolute -z-1 inline-flex h-full w-full animate-ping rounded-full bg-meta-1 opacity-75"></span></span><svg class="fill-current duration-300 ease-in-out" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.1999 14.9343L15.6374 14.0624C15.5249 13.8937 15.4687 13.7249 15.4687 13.528V7.67803C15.4687 6.01865 14.7655 4.47178 13.4718 3.31865C12.4312 2.39053 11.0812 1.7999 9.64678 1.6874V1.1249C9.64678 0.787402 9.36553 0.478027 8.9999 0.478027C8.6624 0.478027 8.35303 0.759277 8.35303 1.1249V1.65928C8.29678 1.65928 8.24053 1.65928 8.18428 1.6874C4.92178 2.05303 2.4749 4.66865 2.4749 7.79053V13.528C2.44678 13.8093 2.39053 13.9499 2.33428 14.0343L1.7999 14.9343C1.63115 15.2155 1.63115 15.553 1.7999 15.8343C1.96865 16.0874 2.2499 16.2562 2.55928 16.2562H8.38115V16.8749C8.38115 17.2124 8.6624 17.5218 9.02803 17.5218C9.36553 17.5218 9.6749 17.2405 9.6749 16.8749V16.2562H15.4687C15.778 16.2562 16.0593 16.0874 16.228 15.8343C16.3968 15.553 16.3968 15.2155 16.1999 14.9343ZM3.23428 14.9905L3.43115 14.653C3.5999 14.3718 3.68428 14.0343 3.74053 13.6405V7.79053C3.74053 5.31553 5.70928 3.23428 8.3249 2.95303C9.92803 2.78428 11.503 3.2624 12.6562 4.2749C13.6687 5.1749 14.2312 6.38428 14.2312 7.67803V13.528C14.2312 13.9499 14.3437 14.3437 14.5968 14.7374L14.7655 14.9905H3.23428Z" fill=""></path></svg></a><div style="${ssrRenderStyle(dropdownOpen.value ? null : { display: "none" })}" class="absolute -right-27 mt-2.5 flex h-90 w-75 flex-col rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark sm:right-0 sm:w-80"><div class="px-4.5 py-3"><h5 class="text-sm font-medium text-bodydark2">Notification</h5></div><ul class="flex h-auto flex-col overflow-y-auto"><!--[-->`);
      ssrRenderList(notificationItems.value, (item, index) => {
        _push(`<li>`);
        _push(ssrRenderComponent(unref(Link), {
          class: "flex flex-col gap-2.5 border-t border-stroke px-4.5 py-3 hover:bg-gray-2 dark:border-strokedark dark:hover:bg-meta-4",
          href: item.route
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<p class="text-sm"${_scopeId}><span class="text-black dark:text-white"${_scopeId}>${ssrInterpolate(item.title)}</span> ${ssrInterpolate(item.details)}</p><p class="text-xs"${_scopeId}>${ssrInterpolate(item.time)}</p>`);
            } else {
              return [
                createVNode("p", { class: "text-sm" }, [
                  createVNode("span", { class: "text-black dark:text-white" }, toDisplayString(item.title), 1),
                  createTextVNode(" " + toDisplayString(item.details), 1)
                ]),
                createVNode("p", { class: "text-xs" }, toDisplayString(item.time), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div></li>`);
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Header/DropdownNotification.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const _sfc_main$c = {
  __name: "DropdownUser",
  __ssrInlineRender: true,
  setup(__props) {
    const target = ref(null);
    const dropdownOpen = ref(false);
    onClickOutside(target, () => {
      dropdownOpen.value = false;
    });
    const user = usePage().props.auth.user;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "relative",
        ref_key: "target",
        ref: target
      }, _attrs))}><a class="flex items-center gap-4" href="#"><img${ssrRenderAttr("src", unref(user).avatar_full_path)} class="w-12 h-12 object-cover rounded-full border border-purple-300"><svg class="${ssrRenderClass([dropdownOpen.value && "rotate-180", "hidden fill-current sm:block"])}" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.410765 0.910734C0.736202 0.585297 1.26384 0.585297 1.58928 0.910734L6.00002 5.32148L10.4108 0.910734C10.7362 0.585297 11.2638 0.585297 11.5893 0.910734C11.9147 1.23617 11.9147 1.76381 11.5893 2.08924L6.58928 7.08924C6.26384 7.41468 5.7362 7.41468 5.41077 7.08924L0.410765 2.08924C0.0853277 1.76381 0.0853277 1.23617 0.410765 0.910734Z" fill=""></path></svg></a><div style="${ssrRenderStyle(dropdownOpen.value ? null : { display: "none" })}" class="absolute right-0 mt-4 flex w-62.5 flex-col rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark"><div class="flex flex-col gap-5 border-b border-stroke px-2 py-2 dark:border-strokedark"><div class="flex flex-row gap-5"><div class="w-[30%]"><img${ssrRenderAttr("src", unref(user).avatar_full_path)} class="w-12 h-12 object-cover rounded-full border border-purple-300"></div><div class="w-[70%] flex flex-col"><span class="text-sm font-medium">${ssrInterpolate(unref(user).name)}</span><span class="text-sm text-gray-400">${ssrInterpolate(unref(user).email)}</span></div></div></div><ul class="flex flex-col gap-5 border-b border-stroke px-2 py-2 dark:border-strokedark"><li>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("profile.edit"),
        class: "flex items-center gap-3.5 text-sm font-medium duration-300 ease-in-out hover:text-purple-700 lg:text-base"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg class="fill-current" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M11 9.62499C8.42188 9.62499 6.35938 7.59687 6.35938 5.12187C6.35938 2.64687 8.42188 0.618744 11 0.618744C13.5781 0.618744 15.6406 2.64687 15.6406 5.12187C15.6406 7.59687 13.5781 9.62499 11 9.62499ZM11 2.16562C9.28125 2.16562 7.90625 3.50624 7.90625 5.12187C7.90625 6.73749 9.28125 8.07812 11 8.07812C12.7188 8.07812 14.0938 6.73749 14.0938 5.12187C14.0938 3.50624 12.7188 2.16562 11 2.16562Z" fill=""${_scopeId}></path><path d="M17.7719 21.4156H4.2281C3.5406 21.4156 2.9906 20.8656 2.9906 20.1781V17.0844C2.9906 13.7156 5.7406 10.9656 9.10935 10.9656H12.925C16.2937 10.9656 19.0437 13.7156 19.0437 17.0844V20.1781C19.0094 20.8312 18.4594 21.4156 17.7719 21.4156ZM4.53748 19.8687H17.4969V17.0844C17.4969 14.575 15.4344 12.5125 12.925 12.5125H9.07498C6.5656 12.5125 4.5031 14.575 4.5031 17.0844V19.8687H4.53748Z" fill=""${_scopeId}></path></svg> ${ssrInterpolate(_ctx.$t("my_profile"))}`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                class: "fill-current",
                width: "22",
                height: "22",
                viewBox: "0 0 22 22",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M11 9.62499C8.42188 9.62499 6.35938 7.59687 6.35938 5.12187C6.35938 2.64687 8.42188 0.618744 11 0.618744C13.5781 0.618744 15.6406 2.64687 15.6406 5.12187C15.6406 7.59687 13.5781 9.62499 11 9.62499ZM11 2.16562C9.28125 2.16562 7.90625 3.50624 7.90625 5.12187C7.90625 6.73749 9.28125 8.07812 11 8.07812C12.7188 8.07812 14.0938 6.73749 14.0938 5.12187C14.0938 3.50624 12.7188 2.16562 11 2.16562Z",
                  fill: ""
                }),
                createVNode("path", {
                  d: "M17.7719 21.4156H4.2281C3.5406 21.4156 2.9906 20.8656 2.9906 20.1781V17.0844C2.9906 13.7156 5.7406 10.9656 9.10935 10.9656H12.925C16.2937 10.9656 19.0437 13.7156 19.0437 17.0844V20.1781C19.0094 20.8312 18.4594 21.4156 17.7719 21.4156ZM4.53748 19.8687H17.4969V17.0844C17.4969 14.575 15.4344 12.5125 12.925 12.5125H9.07498C6.5656 12.5125 4.5031 14.575 4.5031 17.0844V19.8687H4.53748Z",
                  fill: ""
                })
              ])),
              createTextVNode(" " + toDisplayString(_ctx.$t("my_profile")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("logout"),
        method: "post",
        as: "button",
        class: "flex items-center gap-3.5 py-4 px-2 text-sm font-medium duration-300 ease-in-out hover:text-purple-700 lg:text-base"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg class="fill-current" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M15.5375 0.618744H11.6531C10.7594 0.618744 10.0031 1.37499 10.0031 2.26874V4.64062C10.0031 5.05312 10.3469 5.39687 10.7594 5.39687C11.1719 5.39687 11.55 5.05312 11.55 4.64062V2.23437C11.55 2.16562 11.5844 2.13124 11.6531 2.13124H15.5375C16.3625 2.13124 17.0156 2.78437 17.0156 3.60937V18.3562C17.0156 19.1812 16.3625 19.8344 15.5375 19.8344H11.6531C11.5844 19.8344 11.55 19.8 11.55 19.7312V17.3594C11.55 16.9469 11.2062 16.6031 10.7594 16.6031C10.3125 16.6031 10.0031 16.9469 10.0031 17.3594V19.7312C10.0031 20.625 10.7594 21.3812 11.6531 21.3812H15.5375C17.2219 21.3812 18.5625 20.0062 18.5625 18.3562V3.64374C18.5625 1.95937 17.1875 0.618744 15.5375 0.618744Z" fill=""${_scopeId}></path><path d="M6.05001 11.7563H12.2031C12.6156 11.7563 12.9594 11.4125 12.9594 11C12.9594 10.5875 12.6156 10.2438 12.2031 10.2438H6.08439L8.21564 8.07813C8.52501 7.76875 8.52501 7.2875 8.21564 6.97812C7.90626 6.66875 7.42501 6.66875 7.11564 6.97812L3.67814 10.4844C3.36876 10.7938 3.36876 11.275 3.67814 11.5844L7.11564 15.0906C7.25314 15.2281 7.45939 15.3312 7.66564 15.3312C7.87189 15.3312 8.04376 15.2625 8.21564 15.125C8.52501 14.8156 8.52501 14.3344 8.21564 14.025L6.05001 11.7563Z" fill=""${_scopeId}></path></svg> ${ssrInterpolate(_ctx.$t("logout"))}`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                class: "fill-current",
                width: "22",
                height: "22",
                viewBox: "0 0 22 22",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M15.5375 0.618744H11.6531C10.7594 0.618744 10.0031 1.37499 10.0031 2.26874V4.64062C10.0031 5.05312 10.3469 5.39687 10.7594 5.39687C11.1719 5.39687 11.55 5.05312 11.55 4.64062V2.23437C11.55 2.16562 11.5844 2.13124 11.6531 2.13124H15.5375C16.3625 2.13124 17.0156 2.78437 17.0156 3.60937V18.3562C17.0156 19.1812 16.3625 19.8344 15.5375 19.8344H11.6531C11.5844 19.8344 11.55 19.8 11.55 19.7312V17.3594C11.55 16.9469 11.2062 16.6031 10.7594 16.6031C10.3125 16.6031 10.0031 16.9469 10.0031 17.3594V19.7312C10.0031 20.625 10.7594 21.3812 11.6531 21.3812H15.5375C17.2219 21.3812 18.5625 20.0062 18.5625 18.3562V3.64374C18.5625 1.95937 17.1875 0.618744 15.5375 0.618744Z",
                  fill: ""
                }),
                createVNode("path", {
                  d: "M6.05001 11.7563H12.2031C12.6156 11.7563 12.9594 11.4125 12.9594 11C12.9594 10.5875 12.6156 10.2438 12.2031 10.2438H6.08439L8.21564 8.07813C8.52501 7.76875 8.52501 7.2875 8.21564 6.97812C7.90626 6.66875 7.42501 6.66875 7.11564 6.97812L3.67814 10.4844C3.36876 10.7938 3.36876 11.275 3.67814 11.5844L7.11564 15.0906C7.25314 15.2281 7.45939 15.3312 7.66564 15.3312C7.87189 15.3312 8.04376 15.2625 8.21564 15.125C8.52501 14.8156 8.52501 14.3344 8.21564 14.025L6.05001 11.7563Z",
                  fill: ""
                })
              ])),
              createTextVNode(" " + toDisplayString(_ctx.$t("logout")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Header/DropdownUser.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const _sfc_main$b = {
  __name: "HeaderArea",
  __ssrInlineRender: true,
  setup(__props) {
    useSidebarStore();
    const sidebarStore = useSidebarStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "sticky top-0 z-40 flex w-full dark:bg-[#1a2035] bg-[#f9fbfd]" }, _attrs))}><div class="flex flex-grow items-center justify-end py-2 px-4 shadow-2 md:px-6 2xl:px-11"><div class="flex items-center gap-2 sm:gap-4 lg:hidden"><button class="z-99999 block rounded-sm border border-stroke bg-white p-1.5 shadow-sm dark:border-strokedark dark:bg-boxdark lg:hidden"><span class="relative block h-5.5 w-5.5 cursor-pointer"><span class="block absolute right-0 h-full w-full"><span class="${ssrRenderClass([{ "!w-full delay-300": !unref(sidebarStore).isSidebarOpen }, "relative top-0 left-0 my-1 block h-0.5 w-0 rounded-sm bg-black delay-[0] duration-200 ease-in-out dark:bg-white"])}"></span><span class="${ssrRenderClass([{ "!w-full delay-400": !unref(sidebarStore).isSidebarOpen }, "relative top-0 left-0 my-1 block h-0.5 w-0 rounded-sm bg-black delay-150 duration-200 ease-in-out dark:bg-white"])}"></span><span class="${ssrRenderClass([{ "!w-full delay-500": !unref(sidebarStore).isSidebarOpen }, "relative top-0 left-0 my-1 block h-0.5 w-0 rounded-sm bg-black delay-200 duration-200 ease-in-out dark:bg-white"])}"></span></span><span class="block absolute right-0 h-full w-full rotate-45"><span class="${ssrRenderClass([{ "!h-0 delay-[0]": !unref(sidebarStore).isSidebarOpen }, "absolute left-2.5 top-0 block h-full w-0.5 rounded-sm bg-black delay-300 duration-200 ease-in-out dark:bg-white"])}"></span><span class="${ssrRenderClass([{ "!h-0 delay-200": !unref(sidebarStore).isSidebarOpen }, "delay-400 absolute left-0 top-2.5 block h-0.5 w-full rounded-sm bg-black duration-200 ease-in-out dark:bg-white"])}"></span></span></span></button>`);
      _push(ssrRenderComponent(unref(Link), {
        href: "/",
        class: "block flex-shrink-0 lg:hidden",
        to: "/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img src="" alt="Logo"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: "",
                alt: "Logo"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex items-center gap-3 2xsm:gap-7"><ul class="flex items-center gap-2 2xsm:gap-4"><li>`);
      _push(ssrRenderComponent(_sfc_main$f, null, null, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_sfc_main$e, null, null, _parent));
      _push(`</li>`);
      _push(ssrRenderComponent(_sfc_main$d, null, null, _parent));
      _push(`</ul>`);
      _push(ssrRenderComponent(_sfc_main$c, null, null, _parent));
      _push(`</div></div></header>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Header/HeaderArea.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const _sfc_main$a = {
  __name: "SidebarDropdown",
  __ssrInlineRender: true,
  props: ["items", "page"],
  setup(__props) {
    const sidebarStore = useSidebarStore();
    const props = __props;
    const items = ref(props.items);
    const handleItemClick = (index) => {
      const pageName = sidebarStore.selected === props.items[index].label ? "" : props.items[index].label;
      sidebarStore.selected = pageName;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ul${ssrRenderAttrs(mergeProps({ class: "mt-4 mb-5.5 flex flex-col gap-2.5 pl-6" }, _attrs))}><!--[-->`);
      ssrRenderList(items.value, (childItem, index) => {
        _push(`<li>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route(childItem.routeName),
          onClick: ($event) => handleItemClick(index),
          class: ["group relative flex items-center gap-2.5 rounded-md px-4 font-normal duration-300 ease-in-out text-gray-500 hover:text-purple-700 hover:font-extrabold dark:text-gray-400 hover:dark:text-gray-200", {
            "!text-purple-600 font-extrabold": childItem.label === unref(sidebarStore).selected,
            "!bg-purple-600": childItem.is_in_route === true
          }]
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span${_scopeId}>${childItem.icon ?? ""}</span> ${ssrInterpolate(childItem.label)}`);
            } else {
              return [
                createVNode("span", {
                  innerHTML: childItem.icon
                }, null, 8, ["innerHTML"]),
                createTextVNode(" " + toDisplayString(childItem.label), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Sidebar/SidebarDropdown.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const _sfc_main$9 = {
  __name: "SidebarItem",
  __ssrInlineRender: true,
  props: ["item", "currentRoute", "index"],
  setup(__props) {
    const sidebarStore = useSidebarStore();
    const props = __props;
    const handleItemClick = () => {
      const pageName = sidebarStore.page === props.item.label ? "" : props.item.label;
      sidebarStore.page = pageName;
      if (props.item.children) {
        return props.item.children.some((child) => sidebarStore.selected === child.label);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(_attrs)} data-v-6eb8e295>`);
      if (__props.item.children) {
        _push(`<a class="${ssrRenderClass([{ "bg-gray-600 bg-active": unref(sidebarStore).page === __props.item.label }, "group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-gray-500 hover:text-gray-200 dark:text-gray-400 hover:dark:text-gray-200 hover:bg-gray-600 dark:hover:bg-gray-600"])}"${ssrRenderAttr("aria-expanded", unref(sidebarStore).page === __props.item.label)} data-v-6eb8e295><span class="menu-icon flex items-center" data-v-6eb8e295>${__props.item.icon ?? ""}</span><span class="menu-label" data-v-6eb8e295>${ssrInterpolate(__props.item.label)}</span><svg class="${ssrRenderClass([{ "rotate-180": unref(sidebarStore).page === __props.item.label }, "menu-icon absolute right-4 top-1/2 -translate-y-1/2 fill-current"])}" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-6eb8e295><path fill-rule="evenodd" clip-rule="evenodd" d="M4.41107 6.9107C4.73651 6.58527 5.26414 6.58527 5.58958 6.9107L10.0003 11.3214L14.4111 6.91071C14.7365 6.58527 15.2641 6.58527 15.5896 6.91071C15.915 7.23614 15.915 7.76378 15.5896 8.08922L10.5896 13.0892C10.2641 13.4147 9.73651 13.4147 9.41107 13.0892L4.41107 8.08922C4.08563 7.76378 4.08563 7.23614 4.41107 6.9107Z" fill="currentColor" data-v-6eb8e295></path></svg></a>`);
      } else {
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route(__props.item.routeName),
          class: ["group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-gray-500 hover:text-gray-200 dark:text-gray-400 hover:dark:text-gray-200 hover:bg-gray-600 dark:hover:bg-gray-600", { "bg-gray-600 bg-active": unref(sidebarStore).page === __props.item.label }],
          onClick: handleItemClick
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="menu-icon flex items-center" data-v-6eb8e295${_scopeId}>${__props.item.icon ?? ""}</span><span class="menu-label" data-v-6eb8e295${_scopeId}>${ssrInterpolate(__props.item.label)}</span>`);
            } else {
              return [
                createVNode("span", {
                  class: "menu-icon flex items-center",
                  innerHTML: __props.item.icon
                }, null, 8, ["innerHTML"]),
                createVNode("span", { class: "menu-label" }, toDisplayString(__props.item.label), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      }
      _push(`<div class="translate transform overflow-hidden" style="${ssrRenderStyle(unref(sidebarStore).page === __props.item.label ? null : { display: "none" })}" data-v-6eb8e295>`);
      if (__props.item.children) {
        _push(ssrRenderComponent(_sfc_main$a, {
          items: __props.item.children,
          page: __props.item.label
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></li>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Sidebar/SidebarItem.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const SidebarItem = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-6eb8e295"]]);
const _sfc_main$8 = {
  name: "LoadingIcon",
  props: {
    size: {
      type: Number,
      default: 50
      // Default size is 50x50
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<svg${ssrRenderAttrs(mergeProps({
    class: "loading-icon",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 50 50",
    width: $props.size,
    height: $props.size
  }, _attrs))} data-v-790b65c9><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5" data-v-790b65c9></circle></svg>`);
}
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/LoadingIcon.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const LoadingIcon = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-790b65c9"]]);
const _sfc_main$7 = {
  __name: "SidebarArea",
  __ssrInlineRender: true,
  setup(__props) {
    const mainStore = useMainStore();
    const target = ref(null);
    const sidebarStore = useSidebarStore();
    const page = usePage();
    ref(false);
    onClickOutside(target, () => {
      sidebarStore.isSidebarOpen = false;
    });
    events.on("refresh-settings", () => {
      mainStore.loadSetting();
    });
    onMounted(() => {
      mainStore.loadSetting();
    });
    const { isRole, isPermission } = useHelpers();
    const menuGroups = ref([
      {
        name: "MENU",
        menuItems: [
          ...isRole("owner") ? [
            {
              icon: `<i class="mt-[5px] fi fi-tr-dashboard-monitor"></i>`,
              label: "Dashboard",
              routeName: "dashboard"
            }
          ] : [],
          ...isRole("owner") || isRole("admin") || isPermission(["item-specifications"]) ? [
            {
              icon: `<i class="mt-[5px] fi fi-ts-workflow-setting-alt"></i>`,
              label: "Item Specifications",
              is_in_route: route().current("categories.*") ? true : false,
              children: [
                ...isRole("owner") || isRole("admin") || isPermission(["item-categories"]) ? [
                  {
                    icon: `<i class="fa-sharp fa-circle-dot"></i>`,
                    label: "Categories",
                    routeName: "categories.index"
                  }
                ] : [],
                ...isRole("owner") || isRole("admin") || isPermission(["brands"]) ? [
                  {
                    icon: `<i class="fa-sharp fa-circle-dot"></i>`,
                    label: "Brands",
                    routeName: "brands.index"
                  }
                ] : [],
                ...isRole("owner") || isRole("admin") || isPermission(["models"]) ? [
                  {
                    icon: `<i class="fa-sharp fa-circle-dot"></i>`,
                    label: "Models",
                    routeName: "models.index"
                  }
                ] : [],
                ...isRole("owner") || isRole("admin") || isPermission(["colors"]) ? [
                  {
                    icon: `<i class="fa-sharp fa-circle-dot"></i>`,
                    label: "Colors",
                    routeName: "colors.index"
                  }
                ] : []
              ]
            }
          ] : [],
          ...isRole("owner") ? [
            {
              icon: `<i class="mt-[5px] fi fi-rr-user-gear"></i>`,
              label: "Products",
              routeName: "products.index",
              is_in_route: route().current("products.*") ? true : false
            },
            {
              icon: `<i class="mt-[5px] fi fi-rr-user-gear"></i>`,
              label: "Stocks",
              routeName: "stocks.index",
              is_in_route: route().current("stocks.*") ? true : false
            },
            {
              icon: `<i class="mt-[5px] fi fi-rr-user-gear"></i>`,
              label: "Users",
              routeName: "users.index",
              is_in_route: route().current("users.*") ? true : false
            },
            {
              icon: `<i class="mt-[5px] fi fi-rr-users-alt"></i>`,
              label: "Clients",
              routeName: "clients.index",
              is_in_route: route().current("clients.*") ? true : false
            },
            {
              icon: `<i class="mt-[5px] fi fi-rr-users"></i>`,
              label: "Drivers",
              routeName: "clients.index",
              is_in_route: route().current("clients.*") ? true : false
            },
            {
              icon: `<i class="mt-[5px] fi fi-tr-plan"></i>`,
              label: "Permissions",
              routeName: "permissions.index",
              is_in_route: route().current("permissions.*") ? true : false
            },
            {
              icon: `<i class="mt-[5px] fi fi-ts-plan-strategy"></i>`,
              label: "Roles",
              routeName: "roles.index",
              is_in_route: route().current("roles.*") ? true : false
            }
          ] : [],
          ...isRole("owner") || isRole("admin") || isPermission(["settings"]) ? [
            {
              icon: `<i class="mt-[5px] fi fi-tr-customize"></i>`,
              label: "Settings",
              routeName: "settings.index",
              is_in_route: route().current("settings.*") ? true : false
            }
          ] : []
        ]
      }
    ]);
    console.log({ menuGroups });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<aside${ssrRenderAttrs(mergeProps({
        class: ["absolute left-0 top-0 z-40 flex h-screen w-72.5 flex-col overflow-y-hidden duration-300 ease-linear dark:bg-boxdark-1 bg-[#ffffff] lg:static lg:translate-x-0", {
          "translate-x-0": unref(sidebarStore).isSidebarOpen,
          "-translate-x-full": !unref(sidebarStore).isSidebarOpen
        }],
        ref_key: "target",
        ref: target
      }, _attrs))}><div class="py-1 shadow-2"><div class="flex flex-grow items-center justify-between py-[3px] px-4 md:px-6 2xl:px-11"><a${ssrRenderAttr(
        "href",
        unref(mainStore).setting.site_link ? unref(mainStore).setting.site_link : "https://ftdevs.net"
      )} target="_blank" class="flex gap-2 items-center justify-between">`);
      if (unref(mainStore).setting.site_logo === void 0) {
        _push(ssrRenderComponent(LoadingIcon, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(mainStore).setting && unref(mainStore).setting.site_logo) {
        _push(`<img${ssrRenderAttr("src", "/storage/" + unref(mainStore).setting.site_logo)} alt="Site Logo" class="w-[50px] h-[50px] object-cover rounded-full border border-purple-300">`);
      } else {
        _push(`<!---->`);
      }
      _push(`<span>${ssrInterpolate(unref(mainStore).setting.site_name)}</span></a><button class="block lg:hidden"><svg class="fill-current" width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19 8.175H2.98748L9.36248 1.6875C9.69998 1.35 9.69998 0.825 9.36248 0.4875C9.02498 0.15 8.49998 0.15 8.16248 0.4875L0.399976 8.3625C0.0624756 8.7 0.0624756 9.225 0.399976 9.5625L8.16248 17.4375C8.31248 17.5875 8.53748 17.7 8.76248 17.7C8.98748 17.7 9.17498 17.625 9.36248 17.475C9.69998 17.1375 9.69998 16.6125 9.36248 16.275L3.02498 9.8625H19C19.45 9.8625 19.825 9.4875 19.825 9.0375C19.825 8.55 19.45 8.175 19 8.175Z" fill=""></path></svg></button></div></div><div class="no-scrollbar flex flex-col overflow-y-auto duration-300 ease-linear"><nav class="mt-5 py-4 px-4 lg:mt-9 lg:px-6"><!--[-->`);
      ssrRenderList(menuGroups.value, (menuGroup, index) => {
        _push(`<div><h3 class="mb-4 ml-4 text-sm font-medium text-bodydark2">${ssrInterpolate(menuGroup.name)}</h3><ul class="mb-6 flex flex-col gap-1.5"><!--[-->`);
        ssrRenderList(menuGroup.menuItems, (menuItem, index2) => {
          _push(ssrRenderComponent(SidebarItem, {
            item: menuItem,
            key: index2,
            index: index2,
            currentRoute: unref(page).url
          }, null, _parent));
        });
        _push(`<!--]--></ul></div>`);
      });
      _push(`<!--]--></nav></div></aside>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Sidebar/SidebarArea.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "PopupWrapper",
  __ssrInlineRender: true,
  props: {
    name: String,
    backdropClick: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const target = ref(null);
    const isVisible = ref(false);
    onClickOutside(target, () => {
      if (props.backdropClick) {
        isVisible.value = true;
      } else {
        isVisible.value = false;
      }
    });
    const isMobile = () => {
      return window.innerWidth <= 960;
    };
    onMounted(() => {
      events.on("popup:open", (data) => {
        isVisible.value = true;
      });
      events.on("confirm:open", (data) => {
        isVisible.value = true;
      });
      events.on("confirm:cancel", (data) => {
        isVisible.value = false;
      });
      events.on("popup:close", () => isVisible.value = false);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<template>`);
      if (isVisible.value) {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: [{ "is-mobile-view popup-wrapper p-2": isMobile(), "p-10": !isMobile() }, "custom-backdrop-blur popup fixed top-0 left-0 right-0 bottom-0 z-50 grid h-full overflow-y-auto lg:absolute"]
        }, _attrs))} data-v-0c23d3f6><div class="${ssrRenderClass([{ "mobile-popup-body rounded-md": isMobile() }, "fixed top-0 bottom-0 left-0 right-0 z-10 m-auto w-full bg-white shadow-xl dark:bg-dark-foreground md:relative md:w-[490px] md:rounded-xl"])}" data-v-0c23d3f6>`);
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</template>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/Popups/Components/PopupWrapper.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const PopupWrapper = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-0c23d3f6"]]);
const _sfc_main$5 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "popup-action absolute bottom-0 left-0 right-0 flex items-center space-x-4 px-6 py-4 pb-6 md:relative" }, _attrs))}>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/Popups/Components/PopupActions.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const PopupActions = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$4 = {
  __name: "ConfirmPopup",
  __ssrInlineRender: true,
  setup(__props) {
    const mainStore = useMainStore();
    const item = ref([]);
    const action_label = ref("delete");
    const close = () => {
      item.value = [];
      events.emit("confirm:cancel");
      window.removeEventListener("keydown", handleEnter);
      mainStore.clearSelectedRows();
    };
    const confirm = () => {
      if (!item.value) return;
      events.emit("confirm:confirmed", item.value);
    };
    const handleEnter = (event) => {
      if (event.key === "Enter") {
        confirm();
      }
    };
    const handleEscape = (e) => {
      if (e.key === "Escape") {
        close();
      }
    };
    onMounted(() => {
      events.on("confirm:open", (data, action) => {
        console.log({ data, action });
        item.value = data;
        if (action) {
          action_label.value = action;
        }
      });
      window.addEventListener("keydown", handleEscape);
    });
    onBeforeUnmount(() => {
      window.removeEventListener("keydown", handleEscape);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(PopupWrapper, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex h-full transform items-center justify-center px-8 text-center md:translate-y-0"${_scopeId}>`);
            if (item.value) {
              _push2(`<div${_scopeId}><h1 class="mt-5 mb-2 text-2xl font-bold"${_scopeId}>${ssrInterpolate(_ctx.$t("a_u_sure"))}</h1><p class="mb-4 text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t(action_label.value))} - ${ssrInterpolate(_ctx.$t("selected.count", { count: item.value.length }))}</p></div>`);
            } else {
              _push2(`<div${_scopeId}><h1 class="mt-5 mb-2 text-2xl font-bold"${_scopeId}>${ssrInterpolate(_ctx.$t("item_not_found"))}</h1><p class="mb-4 text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("please_try_again"))}</p></div>`);
            }
            _push2(`</div>`);
            _push2(ssrRenderComponent(PopupActions, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<button type="button" class="w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"${_scopeId2}>${ssrInterpolate(_ctx.$t("cancel"))}</button><button${ssrIncludeBooleanAttr(!item.value) ? " disabled" : ""} type="button" class="w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 mb-2 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"${_scopeId2}>${ssrInterpolate(_ctx.$t("yes_iam_sure"))}</button>`);
                } else {
                  return [
                    createVNode("button", {
                      onClick: close,
                      type: "button",
                      class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                    }, toDisplayString(_ctx.$t("cancel")), 1),
                    createVNode("button", {
                      onClick: confirm,
                      disabled: !item.value,
                      type: "button",
                      class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 mb-2 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"
                    }, toDisplayString(_ctx.$t("yes_iam_sure")), 9, ["disabled"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "flex h-full transform items-center justify-center px-8 text-center md:translate-y-0" }, [
                item.value ? (openBlock(), createBlock("div", { key: 0 }, [
                  createVNode("h1", { class: "mt-5 mb-2 text-2xl font-bold" }, toDisplayString(_ctx.$t("a_u_sure")), 1),
                  createVNode("p", { class: "mb-4 text-sm" }, toDisplayString(_ctx.$t(action_label.value)) + " - " + toDisplayString(_ctx.$t("selected.count", { count: item.value.length })), 1)
                ])) : (openBlock(), createBlock("div", { key: 1 }, [
                  createVNode("h1", { class: "mt-5 mb-2 text-2xl font-bold" }, toDisplayString(_ctx.$t("item_not_found")), 1),
                  createVNode("p", { class: "mb-4 text-sm" }, toDisplayString(_ctx.$t("please_try_again")), 1)
                ]))
              ]),
              createVNode(PopupActions, null, {
                default: withCtx(() => [
                  createVNode("button", {
                    onClick: close,
                    type: "button",
                    class: "w-full focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-2 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900"
                  }, toDisplayString(_ctx.$t("cancel")), 1),
                  createVNode("button", {
                    onClick: confirm,
                    disabled: !item.value,
                    type: "button",
                    class: "w-full focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-2 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 mb-2 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"
                  }, toDisplayString(_ctx.$t("yes_iam_sure")), 9, ["disabled"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/Popups/ConfirmPopup.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "ToasterWrapper",
  __ssrInlineRender: true,
  props: {
    barColor: String
  },
  setup(__props) {
    const isActive = ref(true);
    onMounted(() => {
      setTimeout(() => isActive.value = false, 6e3);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<template>`);
      if (isActive.value) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative" }, _attrs))} data-v-0da18cb0><div class="absolute z-[20] right-0 top-[-5px] cursor-pointer p-2" data-v-0da18cb0><i class="fi fi-rs-cross text-xs !text-black opacity-1" data-v-0da18cb0></i></div>`);
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
        _push(`<div class="absolute bottom-0 left-0 right-0 z-20" data-v-0da18cb0><span class="${ssrRenderClass([__props.barColor, "bar-animation block h-1 w-0"])}" data-v-0da18cb0></span></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</template>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/Toaster/ToasterWrapper.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const ToasterWrapper = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-0da18cb0"]]);
const _sfc_main$2 = {
  __name: "Toaster",
  __ssrInlineRender: true,
  props: {
    item: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      _push(`<template><div${ssrRenderAttrs(mergeProps({
        class: ["relative w-full overflow-hidden rounded-md bg-opacity-80 p-4 shadow-lg backdrop-blur-2xl", {
          "bg-rose-50 dark:bg-2x-dark-foreground": __props.item.type === "danger",
          "bg-green-50 dark:bg-2x-dark-foreground": __props.item.type === "success"
        }]
      }, _attrs))}><div class="flex items-center justify-between"><div class="flex items-start">`);
      if (!((_a = __props.item) == null ? void 0 : _a.action) && __props.item.type === "success") {
        _push(`<i class="mt-[3px] text-sm fi fi-sr-check dark:text-green-600 text-green-600"></i>`);
      } else {
        _push(`<!---->`);
      }
      if (!((_b = __props.item) == null ? void 0 : _b.action) && __props.item.type === "danger") {
        _push(`<i class="mt-[3px] text-sm fi fi-rs-cross dark:text-rose-600 text-rose-600"></i>`);
      } else {
        _push(`<!---->`);
      }
      if (((_c = __props.item) == null ? void 0 : _c.action) === "delete") {
        _push(`<i class="mt-[3px] text-sm fi fi-rs-trash dark:text-purple-600 text-purple-600"></i>`);
      } else {
        _push(`<!---->`);
      }
      if (((_d = __props.item) == null ? void 0 : _d.action) === "create") {
        _push(`<i class="mt-[3px] text-sm fi fi-rs-pen-clip dark:text-purple-600 text-purple-600"></i>`);
      } else {
        _push(`<!---->`);
      }
      if (((_e = __props.item) == null ? void 0 : _e.action) === "update") {
        _push(`<i class="mt-[3px] text-sm fi fi-rs-refresh dark:text-purple-600 text-purple-600"></i>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<p class="${ssrRenderClass([{
        "text-green-600": __props.item.type === "success",
        "text-rose-600": __props.item.type === "danger"
      }, "px-4 font-bold"])}">${ssrInterpolate(__props.item.message)}</p></div></div></div></template>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/Toaster/Toaster.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "ToasterNotifications",
  __ssrInlineRender: true,
  setup(__props) {
    const toasters = ref([]);
    ref([]);
    onMounted(() => {
      events.on("toaster", (toaster) => toasters.value.push(toaster));
    });
    const getToasterColor = (toaster) => {
      return {
        danger: "bg-red-400",
        success: "bg-green-400"
      }[toaster.type];
    };
    return (_ctx, _push, _parent, _attrs) => {
      if (toasters.value.length) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed bottom-4 right-4 left-4 z-[55] sm:w-[360px] sm:left-auto lg:bottom-8 lg:right-8" }, _attrs))}><!--[-->`);
        ssrRenderList(toasters.value, (toaster, i) => {
          _push(ssrRenderComponent(ToasterWrapper, {
            key: i,
            class: "mt-4 overflow-hidden rounded-xl shadow-xl",
            "bar-color": getToasterColor(toaster)
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_sfc_main$2, { item: toaster }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(_sfc_main$2, { item: toaster }, null, 8, ["item"])
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Others/Toaster/ToasterNotifications.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "DefaultLayout",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex h-screen overflow-hidden" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, null, null, _parent));
      _push(ssrRenderComponent(_sfc_main$7, null, null, _parent));
      _push(`<div class="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">`);
      _push(ssrRenderComponent(_sfc_main$b, null, null, _parent));
      _push(`<main><div class="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10 bg-gray-200 dark:bg-[#1a2035]"><div class="content dark:bg-boxdark-1 bg-white">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div></main></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/DefaultLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
