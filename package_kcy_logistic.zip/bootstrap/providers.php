<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FirebaseServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
];
