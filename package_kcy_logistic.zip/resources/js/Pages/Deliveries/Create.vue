<template>
  <div>
    <!-- Your component HTML here -->
    Create Delivery Page
  </div>
</template>

<script setup>
// Your script logic here (optional)
</script>
