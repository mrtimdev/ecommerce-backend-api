<template>
    <DefaultLayout>
    <Head :title="$t('brands')" />
    <div class="container">
      <div class="content-header rounded-tl-md rounded-tr-md p-5 border-b bg-white dark:border-gray-700 dark:bg-boxdark-1 flex flex-grow items-center justify-between">
        <Bc :crumbs="breadcrumbs" />
      </div>

      <div class="content-body p-5">
        <div class="relative">
            <form @submit.prevent=" handleSubmit " enctype="multipart/form-data">
                <div class="grid gap-6 mb-6 md:grid-cols-2">
                  <div>
                    <label for="code" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white">{{
                      $t('code') }}</label>
                    <input autofocus type="text" ref="code" id="code" v-model=" form.code "
                      class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"
                      :placeholder=" $t('brand.code') " />
                    <InputError :message=" form.errors.code " class="mt-2" />
                  </div>
  
                  <div>
                    <label for="name" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white">{{
                      $t('name') }}</label>
                    <input type="text" ref="name" id="name" v-model=" form.name "
                      class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"
                      :placeholder=" $t('brand.name') " />
                    <InputError :message=" form.errors.name " class="mt-2" />
                  </div>
                </div>
                <div class="grid gap-6 mb-6 md:grid-cols-2">
                  
  
                  <div>
                    <div>
                      <label for="slug" class="block mb-2 text-sm font-medium text-gray-700 dark:text-white">{{
                        $t('slug') }}</label>
                      <input type="text" ref="slug" id="slug" v-model=" form.slug "
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500 dark:bg-tim-11"
                        :placeholder=" $t('brand.slug') " />
                      <InputError :message=" form.errors.slug " class="mt-2" />
                    </div>
                  </div>
  
                  <div>
                    <label for="status" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{{ $t('select_status') }}</label>
                    <select v-model=" form.is_active "
                      id="status"
                      class="bg-gray-50 border  border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 dark:bg-boxdark-1 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-purple-500 dark:focus:border-purple-500">
                      <option disabled>{{ $t('select_status') }}</option>
                      <option :value="true">{{ $t('active') }}</option>
                      <option :value="false">{{ $t('inactive') }}</option>
                    </select>
                    <InputError :message=" form.errors.is_active " class="mt-2" />
                  </div>
                  <div>
                    <FileUpload :multiple="false" v-model="form.image_path"/>
                    <InputError :message=" form.errors.image_path " class="mt-2" />
                  </div>
                </div>
                <div class="modal-footer">
                  <div class="flex justify-start gap-5 items-center">
                    <Link :href="route('brands.index')"
                      class="focus:outline-none text-white bg-rose-700 hover:bg-rose-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-rose-600 dark:hover:bg-rose-700 dark:focus:ring-rose-900">{{
                      $t('cancel') }}</Link>
                      <input
                        type="submit"
                        :value="$t('save')"
                        @click="form.is_save_and_more = false"
                        class="focus:outline-none text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-4 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 dark:focus:ring-emerald-900"
                      />
                      <input
                        type="submit"
                        :value="$t('save_and_more')"
                        @click="form.is_save_and_more = true"
                        class="focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"
                      />
                    
                  </div>
                </div>
              </form>
        </div>
      </div>  
    </div>
    </DefaultLayout>
</template>


<script setup>
  import DefaultLayout from '@/Layouts/DefaultLayout.vue';
  import FileUpload from '@/Components/Others/FileUpload.vue';
  import { Head, useForm, Link, usePage } from '@inertiajs/vue3';
  import { reactive, ref, watch } from 'vue'
  import { useI18n } from 'vue-i18n';
  const { t } = useI18n();
  import useHelper from '@/composables/useHelper'
  const { generateSlug } = useHelper()
  const page = usePage()
  const breadcrumbs = reactive([
    {  label: 'Home', url: route('dashboard') },
    {  label: t('brands'), url: '/admin/brands' }, 
    {  label: t('create'), url: null, is_active: true } 
  ])
  const form = useForm({
      code: '',
      name: '',
      slug: '',
      image_path: null,
      is_active: true,
      is_save_and_more: false,
  })
  watch([() => form.name, () => form.code], ([newName, newCode]) => {
    form.slug = generateSlug(newCode, newName);
  });
  const handleSubmit = () => {
      form.post(route('brands.store'), {
        _token: page.props.csrf_token,
        preserveScroll: true,
        onSuccess: (res) => {
          console.log({res})
          form.reset('code', 'name')
        },
        onError: () => {
        }
      })
    
  }
</script>
